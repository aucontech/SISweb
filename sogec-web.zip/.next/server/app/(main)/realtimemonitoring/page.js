(() => {
var exports = {};
exports.id = 507;
exports.ids = [507];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 76563:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'realtimemonitoring',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27426)), "D:\\sogec\\sogec-web\\app\\(main)\\realtimemonitoring\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\realtimemonitoring\\page.tsx"];
    
    const originalPathname = "/(main)/realtimemonitoring/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 63943:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 12765))

/***/ }),

/***/ 12765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/chartjs-adapter-luxon/dist/chartjs-adapter-luxon.esm.js + 27 modules
var chartjs_adapter_luxon_esm = __webpack_require__(86686);
// EXTERNAL MODULE: ./node_modules/chartjs-plugin-streaming/dist/chartjs-plugin-streaming.js
var chartjs_plugin_streaming = __webpack_require__(80892);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./layout/context/layoutcontext.tsx
var layoutcontext = __webpack_require__(6538);
// EXTERNAL MODULE: ./service/Utils.ts
var Utils = __webpack_require__(31130);
// EXTERNAL MODULE: ./node_modules/primereact/chart/chart.cjs.js
var chart_cjs = __webpack_require__(16259);
;// CONCATENATED MODULE: ./components/CommonChart.ts
const getChartOptions = ()=>{
    if (typeof document === "undefined" || !document.body) {
        return {};
    }
    if (!document || !document.body) {
        return {};
    }
    let body = document.body;
    const textColor = getComputedStyle(body).getPropertyValue("--text-color") || "rgba(0, 0, 0, 0.87)";
    const gridLinesColor = getComputedStyle(body).getPropertyValue("--divider-color") || "rgba(160, 167, 181, .3)";
    const fontFamily = getComputedStyle(body).getPropertyValue("--font-family");
    return {
        animation: false,
        maintainAspectRatio: false,
        aspectRatio: 0.8,
        interaction: {
            mode: "index",
            intersect: false
        },
        legend: {
            display: true,
            labels: {
                fontFamily,
                fontColor: textColor,
                fontSize: 8
            }
        },
        responsive: true,
        scales: {
            yAxes: [
                {
                    ticks: {
                        fontFamily,
                        fontColor: "textColor"
                    },
                    gridLines: {
                        color: gridLinesColor
                    }
                }
            ],
            xAxes: [
                {
                    ticks: {
                        fontFamily,
                        fontColor: textColor,
                        maxRotation: 40,
                        minRotation: 30
                    },
                    gridLines: {
                        color: "red"
                    }
                }
            ]
        }
    };
};

;// CONCATENATED MODULE: ./components/ChartRealtime.tsx







let chartOptions = getChartOptions();
const ChartRealtime = ({ tag, deviceId })=>{
    const ws = (0,react_.useRef)(null);
    // const [chartOptions, setChartOptions] = useState({});
    const [chartData, setChartData] = (0,react_.useState)({});
    const { layoutConfig } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const [loading, setLoading] = (0,react_.useState)(true);
    const sendData = (0,react_.useCallback)((data)=>{
        if (ws.current && ws.current.readyState === WebSocket.OPEN) {
            ws.current.send(data);
        }
    }, []);
    const updateChartData = (0,react_.useCallback)((message)=>{
        let dataReceives = message.update[0].timeseries[tag];
        setChartData((currentData)=>{
            let newLabels = [
                ...currentData.labels
            ];
            let newData = [
                ...currentData.datasets[0].data
            ];
            dataReceives.forEach((item)=>{
                newLabels.push(Utils/* Utils */.c.formatUnixTimeToString(item["ts"], "HH:mm:ss"));
                newData.push(item["value"]);
            });
            if (newLabels.length > 10) {
                newLabels = newLabels.slice(-10);
            }
            if (newData.length > 10) {
                newData = newData.slice(-10);
            }
            return {
                ...currentData,
                labels: newLabels,
                datasets: [
                    {
                        ...currentData.datasets[0],
                        data: newData
                    }
                ]
            };
        });
    }, []); // Add dependencies inside this array if there are any
    const connectWebSocket = (0,react_.useCallback)((token)=>{
        ws.current = new WebSocket(`${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins"}/telemetry?token=${token}`);
        ws.current.onopen = ()=>{
            setLoading(false);
            let data = {
                entityDataCmds: [
                    {
                        query: {
                            entityFilter: {
                                type: "singleEntity",
                                singleEntity: {
                                    entityType: "DEVICE",
                                    id: deviceId
                                }
                            },
                            pageLink: {
                                pageSize: 1024,
                                page: 0,
                                sortOrder: {
                                    key: {
                                        type: "ENTITY_FIELD",
                                        key: "createdTime"
                                    },
                                    direction: "DESC"
                                }
                            },
                            entityFields: [
                                {
                                    type: "ENTITY_FIELD",
                                    key: "name"
                                },
                                {
                                    type: "ENTITY_FIELD",
                                    key: "label"
                                },
                                {
                                    type: "ENTITY_FIELD",
                                    key: "additionalInfo"
                                }
                            ],
                            latestValues: []
                        },
                        cmdId: 1
                    }
                ]
            };
            sendData(JSON.stringify(data));
        };
        ws.current.onmessage = (evt)=>{
            //console.log(Utils.getUnixTimeMilliseconds());
            let data1 = {
                entityDataCmds: [
                    {
                        cmdId: 1,
                        tsCmd: {
                            keys: [
                                tag
                            ],
                            startTs: Utils/* Utils */.c.getUnixTimeMilliseconds(),
                            timeWindow: 61000,
                            interval: 10000,
                            limit: 61,
                            agg: "AVG"
                        }
                    }
                ]
            };
            let message = JSON.parse(evt.data);
            if (message.data) {
                sendData(JSON.stringify(data1));
            } else {
                console.log(JSON.parse(evt.data));
                updateChartData(JSON.parse(evt.data));
            }
        };
        ws.current.onclose = ()=>{
            console.log("WebSocket connection closed. Trying to reconnect...");
            setTimeout(connectWebSocket, 10000); // Thử kết nối lại sau 5 giây
        };
        ws.current.onerror = (error)=>{
            console.error("WebSocket error:", error);
        // UIUtils.showError({});
        };
    }, [
        sendData
    ]);
    (0,react_.useEffect)(()=>{
        const initChart = ()=>{
            // const documentStyle = getComputedStyle(document.documentElement);
            // const textColor = documentStyle.getPropertyValue("--text-color");
            // const textColorSecondary = documentStyle.getPropertyValue(
            //     "--text-color-secondary"
            // );
            // const surfaceBorder =
            //     documentStyle.getPropertyValue("--surface-border");
            const data = {
                labels: [],
                datasets: [
                    {
                        label: tag,
                        data: [],
                        fill: true,
                        borderColor: "#6366f1",
                        tension: 0.4,
                        backgroundColor: "rgba(99,102,220,0.2)"
                    }
                ]
            };
            // const options: ChartOptions = {
            //     animation: false,
            //     responsive: true,
            //     plugins: {
            //         legend: {
            //             labels: {
            //                 color: textColor,
            //             },
            //         },
            //         tooltip: {},
            //     },
            //     scales: {
            //         x: {
            //             ticks: {
            //                 color: textColorSecondary,
            //             },
            //             grid: {
            //                 color: surfaceBorder,
            //             },
            //         },
            //         y: {
            //             ticks: {
            //                 color: textColorSecondary,
            //             },
            //             grid: {
            //                 color: surfaceBorder,
            //             },
            //         },
            //     },
            // };
            setChartData(data);
        };
        initChart();
    }, [
        layoutConfig
    ]);
    (0,react_.useEffect)(()=>{
        let token = null;
        if (false) {}
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: loading ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: "Loading..."
        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "col-12 xl:col-8",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "card",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-900 text-xl font-semibold mb-3",
                        children: "Overview"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(chart_cjs/* Chart */.k, {
                        type: "line",
                        data: chartData,
                        options: chartOptions
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const components_ChartRealtime = (ChartRealtime);

;// CONCATENATED MODULE: ./app/(main)/realtimemonitoring/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const plugins = [
    chartjs_plugin_streaming.StreamingPlugin
];
const RealtimeMonitoring = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ jsx_runtime_.jsx(components_ChartRealtime, {
                tag: "Flow_Rate_AI",
                deviceId: "28e76d70-a3ce-11ee-9ca1-8f006c3fce43"
            })
        })
    });
};
/* harmony default export */ const page = (RealtimeMonitoring);


/***/ }),

/***/ 27426:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\realtimemonitoring\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,4230,6259,2879,6065,2547,4972,1130], () => (__webpack_exec__(76563)));
module.exports = __webpack_exports__;

})();