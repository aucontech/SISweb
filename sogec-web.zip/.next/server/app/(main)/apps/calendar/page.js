(() => {
var exports = {};
exports.id = 730;
exports.ids = [730];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 24733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'apps',
        {
        children: [
        'calendar',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 81812)), "D:\\sogec\\sogec-web\\app\\(main)\\apps\\calendar\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\apps\\calendar\\page.tsx"];
    
    const originalPathname = "/(main)/apps/calendar/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 81542:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 80672))

/***/ }),

/***/ 80672:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/@fullcalendar/react/dist/index.js
var dist = __webpack_require__(48498);
// EXTERNAL MODULE: ./node_modules/@fullcalendar/daygrid/index.js
var daygrid = __webpack_require__(18793);
// EXTERNAL MODULE: ./node_modules/@fullcalendar/interaction/index.js
var interaction = __webpack_require__(98877);
// EXTERNAL MODULE: ./node_modules/@fullcalendar/timegrid/index.js + 1 modules
var timegrid = __webpack_require__(24158);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/calendar/calendar.cjs.js
var calendar_cjs = __webpack_require__(52186);
// EXTERNAL MODULE: ./node_modules/primereact/dialog/dialog.cjs.js
var dialog_cjs = __webpack_require__(6120);
// EXTERNAL MODULE: ./node_modules/primereact/dropdown/dropdown.cjs.js
var dropdown_cjs = __webpack_require__(1042);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
// EXTERNAL MODULE: ./node_modules/primereact/inputtextarea/inputtextarea.cjs.js
var inputtextarea_cjs = __webpack_require__(43285);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
;// CONCATENATED MODULE: ./demo/service/EventService.ts
const EventService = {
    getEvents () {
        return fetch("/demo/data/scheduleevents.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    }
};

;// CONCATENATED MODULE: ./app/(main)/apps/calendar/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 
// fullcalendar core import












const CalendarDemo = ()=>{
    const [events, setEvents] = (0,react_.useState)([]);
    const [tags, setTags] = (0,react_.useState)([]);
    const [showDialog, setShowDialog] = (0,react_.useState)(false);
    const [view, setView] = (0,react_.useState)("");
    const [changedEvent, setChangedEvent] = (0,react_.useState)({
        title: "",
        start: "",
        end: "",
        allDay: false,
        location: "",
        borderColor: "",
        textColor: "",
        description: "",
        tag: {
            name: "Company A",
            color: "#FFB6B6"
        }
    });
    const onEventClick = (e)=>{
        const { start, end } = e.event;
        let plainEvent = e.event.toPlainObject({
            collapseExtendedProps: true,
            collapseColor: true
        });
        setView("display");
        setShowDialog(true);
        setChangedEvent((prevChangeState)=>({
                ...prevChangeState,
                ...plainEvent,
                start: start,
                end: end ? end : start
            }));
    };
    (0,react_.useEffect)(()=>{
        EventService.getEvents().then((data)=>{
            setEvents(data);
            const _tags = [];
            data.forEach((event)=>{
                _tags.push(event.tag);
            });
            setTags(_tags);
        });
    }, []);
    const handleSave = ()=>{
        if (!validate()) {
            return;
        } else {
            const _clickedEvent = {
                ...changedEvent,
                backgroundColor: changedEvent.tag?.color ?? "#fff",
                borderColor: changedEvent.tag?.color ?? "#fff",
                textColor: "#212121"
            };
            setShowDialog(false);
            if (_clickedEvent.id) {
                const _events = events.map((i)=>i.id?.toString() === _clickedEvent.id?.toString() ? i = _clickedEvent : i);
                setEvents(_events);
            } else {
                setEvents((prevState)=>[
                        ...prevState,
                        {
                            ..._clickedEvent,
                            id: Math.floor(Math.random() * 10000).toString()
                        }
                    ]);
            }
        }
    };
    const validate = ()=>{
        let { start, end, title } = changedEvent;
        return start && end && title;
    };
    const onEditClick = ()=>{
        setView("edit");
    };
    const onDateSelect = (e)=>{
        setView("new");
        setShowDialog(true);
        setChangedEvent({
            ...e,
            title: "",
            location: "",
            borderColor: "",
            textColor: "",
            description: "",
            tag: {
                name: "Company A",
                color: "#FFB6B6"
            }
        });
    };
    const selectedItemTemplate = ()=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex align-items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex-shrink-0 w-1rem h-1rem mr-2 border-circle",
                    style: {
                        backgroundColor: changedEvent.tag?.color || "#FFB6B6"
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: changedEvent.tag?.name || "Company A"
                })
            ]
        });
    };
    const itemOptionTemplate = (tag)=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex align-items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex-shrink-0 w-1rem h-1rem mr-2 border-circle",
                    style: {
                        backgroundColor: tag?.color
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: tag?.name
                })
            ]
        });
    };
    const footer = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            view === "display" ? /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                type: "button",
                label: "Edit",
                icon: "pi pi-pencil",
                onClick: onEditClick
            }) : null,
            view === "new" || view === "edit" ? /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                type: "button",
                label: "Save",
                icon: "pi pi-check",
                disabled: !changedEvent.start || !changedEvent.end,
                onClick: handleSave
            }) : null
        ]
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "col-12",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "card",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                        children: "Calendar"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(dist/* default */.Z, {
                        events: events,
                        eventClick: onEventClick,
                        select: onDateSelect,
                        initialDate: "2022-05-11",
                        initialView: "dayGridMonth",
                        height: 720,
                        plugins: [
                            daygrid/* default */.Z,
                            timegrid/* default */.Z,
                            interaction/* default */.ZP
                        ],
                        headerToolbar: {
                            left: "prev,next today",
                            center: "title",
                            right: "dayGridMonth,timeGridWeek,timeGridDay"
                        },
                        editable: true,
                        selectable: true,
                        selectMirror: true,
                        dayMaxEvents: true
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(dialog_cjs.Dialog, {
                        visible: showDialog,
                        style: {
                            width: "36rem"
                        },
                        modal: true,
                        headerClassName: "text-900 font-semibold text-xl",
                        header: view === "display" ? changedEvent.title : view === "new" ? "New Event" : "Edit Event",
                        breakpoints: {
                            "960px": "75vw",
                            "640px": "90vw"
                        },
                        footer: footer,
                        closable: true,
                        onHide: ()=>setShowDialog(false),
                        children: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: view === "display" ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-900 font-semibold block mb-2",
                                        children: "Description"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "block mb-3",
                                        children: changedEvent.description
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "grid",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-900 font-semibold mb-2",
                                                        children: "Start"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "flex align-items-center m-0",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "pi pi-fw pi-clock text-700 mr-2"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: changedEvent.start?.toString().slice(0, 10)
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-900 font-semibold mb-2",
                                                        children: "End"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "flex align-items-center m-0",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "pi pi-fw pi-clock text-700 mr-2"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: changedEvent.end?.toString().slice(0, 10)
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-900 font-semibold mb-2",
                                                        children: "Location"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "flex align-items-center m-0",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "pi pi-fw pi-clock text-700 mr-2"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: changedEvent.location
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "col-12",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-900 font-semibold mb-2",
                                                        children: "Color"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "flex align-items-center m-0",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "inline-flex flex-shrink-0 w-1rem h-1rem mr-2 border-circle",
                                                                style: {
                                                                    backgroundColor: changedEvent.tag?.color
                                                                }
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                children: changedEvent.tag?.name
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid p-fluid formgrid",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-12 md:col-6 field",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "title",
                                                className: "text-900 font-semibold",
                                                children: "Title"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "p-input-icon-left",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-pencil"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                                        id: "title",
                                                        value: changedEvent.title,
                                                        onChange: (e)=>setChangedEvent((prevState)=>({
                                                                    ...prevState,
                                                                    title: e.target.value
                                                                })),
                                                        type: "text",
                                                        placeholder: "Title"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-12 md:col-6 field",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "location",
                                                className: "text-900 font-semibold",
                                                children: "Location"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "p-input-icon-left",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-map-marker"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                                        id: "location",
                                                        value: changedEvent.location,
                                                        onChange: (e)=>setChangedEvent((prevState)=>({
                                                                    ...prevState,
                                                                    location: e.target.value
                                                                })),
                                                        type: "text",
                                                        placeholder: "Location"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-12 field",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "description",
                                                className: "text-900 font-semibold",
                                                children: "Event Description"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(inputtextarea_cjs/* InputTextarea */.g, {
                                                id: "description",
                                                rows: 5,
                                                value: changedEvent.description,
                                                onChange: (e)=>setChangedEvent((prevState)=>({
                                                            ...prevState,
                                                            description: e.target.value
                                                        })),
                                                style: {
                                                    resize: "none"
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-12 md:col-6 field",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "start",
                                                className: "text-900 font-semibold",
                                                children: "Start Date"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(calendar_cjs/* Calendar */.f, {
                                                id: "start",
                                                maxDate: changedEvent.end,
                                                value: changedEvent.start,
                                                onChange: (e)=>setChangedEvent((prevState)=>({
                                                            ...prevState,
                                                            start: e.value
                                                        })),
                                                showTime: true,
                                                required: true
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-12 md:col-6 field",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "end",
                                                className: "text-900 font-semibold",
                                                children: "End Date"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(calendar_cjs/* Calendar */.f, {
                                                id: "end",
                                                minDate: changedEvent.start,
                                                value: changedEvent.end,
                                                onChange: (e)=>setChangedEvent((prevState)=>({
                                                            ...prevState,
                                                            end: e.value
                                                        })),
                                                showTime: true,
                                                required: true
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col-12 field",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                htmlFor: "company-color",
                                                className: "text-900 font-semibold",
                                                children: "Color"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(dropdown_cjs.Dropdown, {
                                                inputId: "company-color",
                                                value: changedEvent.tag,
                                                options: tags,
                                                onChange: (e)=>setChangedEvent((prevState)=>({
                                                            ...prevState,
                                                            tag: e.value
                                                        })),
                                                optionLabel: "name",
                                                placeholder: "Select a Tag",
                                                valueTemplate: selectedItemTemplate,
                                                itemTemplate: itemOptionTemplate
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const page = (CalendarDemo);


/***/ }),

/***/ 81812:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\calendar\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5665,7978,1042,6120,590,3285,6946,2186,1009,6065,2547,4972], () => (__webpack_exec__(24733)));
module.exports = __webpack_exports__;

})();