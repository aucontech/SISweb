(() => {
var exports = {};
exports.id = 8655;
exports.ids = [8655,1859];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 4200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'apps',
        {
        children: [
        '(mail)',
        {
        children: [
        'mail',
        {
        children: [
        'spam',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51236)), "D:\\sogec\\sogec-web\\app\\(main)\\apps\\(mail)\\mail\\spam\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 77421)), "D:\\sogec\\sogec-web\\app\\(main)\\apps\\(mail)\\layout.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\apps\\(mail)\\mail\\spam\\page.tsx"];
    
    const originalPathname = "/(main)/apps/(mail)/mail/spam/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 23031:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23667))

/***/ }),

/***/ 87695:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 91003))

/***/ }),

/***/ 23667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AppLayout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/ripple/ripple.cjs.js
var ripple_cjs = __webpack_require__(26412);
// EXTERNAL MODULE: ./node_modules/primereact/utils/utils.cjs.js
var utils_cjs = __webpack_require__(7666);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./demo/components/apps/mail/context/mailcontext.tsx
var mailcontext = __webpack_require__(68496);
;// CONCATENATED MODULE: ./demo/components/apps/mail/AppMailSidebar.tsx







function AppMailSidebar() {
    const [items, setItems] = (0,react_.useState)([]);
    const router = (0,navigation.useRouter)();
    const pathname = (0,navigation.usePathname)();
    const { mails } = (0,react_.useContext)(mailcontext/* MailContext */.u);
    const navigate = (item)=>{
        if (item.to) {
            router.push(item.to);
        }
    };
    const getBadgeValues = (data)=>{
        let inbox = [], starred = [], spam = [], important = [], archived = [], trash = [], sent = [];
        for(let i = 0; i < data.length; i++){
            let mail = data[i];
            if (!mail.archived && !mail.trash && !mail.spam && !mail.hasOwnProperty("sent")) {
                inbox.push(mail);
            }
            if (mail.starred) {
                starred.push(mail);
            }
            if (mail.spam) {
                spam.push(mail);
            }
            if (mail.important) {
                important.push(mail);
            }
            if (mail.archived) {
                archived.push(mail);
            }
            if (mail.trash) {
                trash.push(mail);
            }
            if (mail.sent) {
                sent.push(mail);
            }
        }
        const badgeValues = {
            inbox: inbox.length,
            starred: starred.length,
            spam: spam.length,
            important: important.length,
            archived: archived.length,
            trash: trash.length,
            sent: sent.length
        };
        setItems([
            {
                label: "Inbox",
                icon: "pi pi-inbox",
                badge: badgeValues.inbox,
                to: "/apps/mail/inbox"
            },
            {
                label: "Starred",
                icon: "pi pi-star",
                badge: badgeValues.starred,
                to: "/apps/mail/starred"
            },
            {
                label: "Spam",
                icon: "pi pi-ban",
                badge: badgeValues.spam,
                to: "/apps/mail/spam"
            },
            {
                label: "Important",
                icon: "pi pi-bookmark",
                badge: badgeValues.important,
                to: "/apps/mail/important"
            },
            {
                label: "Sent",
                icon: "pi pi-send",
                badge: badgeValues.sent,
                to: "/apps/mail/sent"
            },
            {
                label: "Archived",
                icon: "pi pi-book",
                badge: badgeValues.archived,
                to: "/apps/mail/archived"
            },
            {
                label: "Trash",
                icon: "pi pi-trash",
                badge: badgeValues.trash,
                to: "/apps/mail/trash"
            }
        ]);
    };
    (0,react_.useEffect)(()=>{
        getBadgeValues(mails);
    }, [
        mails
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx((react_default()).Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                    label: "Compose New",
                    className: "mb-5 w-full",
                    outlined: true,
                    onClick: (e)=>router.push("/apps/mail/compose")
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "overflow-auto",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "flex flex-row md:flex-column gap-1 md:gap-2 list-none m-0 p-0 overflow-auto",
                        children: items.map((item, i)=>{
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: (0,utils_cjs.classNames)("p-ripple cursor-pointer select-none p-3 transition-duration-150 border-round flex align-items-center justify-content-center md:justify-content-start md:flex-1 flex-auto", {
                                    "bg-primary": pathname === item.to,
                                    "hover:surface-hover": pathname !== item.to
                                }),
                                onClick: ()=>navigate(item),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: (0,utils_cjs.classNames)("md:mr-3 text-600 transition-duration-150 text-lg", item.icon || "", {
                                            "text-primary-50": pathname === item.to
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (0,utils_cjs.classNames)("text-900 font-medium hidden md:inline", {
                                            "text-primary-50": pathname === item.to
                                        }),
                                        children: item.label
                                    }),
                                    item.badge ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "ml-auto text-sm font-semibold bg-primary-50 text-primary-900 px-2 py-1 hidden md:inline",
                                        style: {
                                            borderRadius: "2rem"
                                        },
                                        children: item.badge
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "ml-auto text-sm font-semibold bg-primary-50 text-primary-900 px-2 py-1 hidden md:inline",
                                        style: {
                                            borderRadius: "2rem"
                                        },
                                        children: "0"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ripple_cjs.Ripple, {})
                                ]
                            }, i);
                        })
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const mail_AppMailSidebar = (AppMailSidebar);

;// CONCATENATED MODULE: ./demo/components/apps/mail/AppMailLayout.tsx



const AppMailLayout = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(mailcontext/* MailProvider */.N, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "card",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-column md:flex-row gap-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-3 xl:w-2 xl:p-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(mail_AppMailSidebar, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "md:w-9 xl:w-10 xl:p-3",
                        children: children
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const mail_AppMailLayout = (AppMailLayout);

;// CONCATENATED MODULE: ./app/(main)/apps/(mail)/layout.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

function AppLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(mail_AppMailLayout, {
        children: children
    });
}


/***/ }),

/***/ 91003:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _demo_components_apps_mail_AppMailTable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(68869);
/* harmony import */ var _demo_components_apps_mail_context_mailcontext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(68496);
/* __next_internal_client_entry_do_not_use__ default auto */ 



const MailSpam = ()=>{
    const [spamMails, setSpamMails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { mails } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_demo_components_apps_mail_context_mailcontext__WEBPACK_IMPORTED_MODULE_3__/* .MailContext */ .u);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const _mails = mails.filter((d)=>d.spam && !d.archived && !d.trash && !d.hasOwnProperty("sent"));
        setSpamMails(_mails);
    }, [
        mails
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_demo_components_apps_mail_AppMailTable__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            mails: spamMails
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MailSpam);


/***/ }),

/***/ 68869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ mail_AppMailTable)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/primereact/api/api.cjs.js
var api_cjs = __webpack_require__(90284);
// EXTERNAL MODULE: ./node_modules/primereact/avatar/avatar.cjs.js
var avatar_cjs = __webpack_require__(77088);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/column/column.cjs.js
var column_cjs = __webpack_require__(59210);
// EXTERNAL MODULE: ./node_modules/primereact/datatable/datatable.cjs.js
var datatable_cjs = __webpack_require__(14760);
// EXTERNAL MODULE: ./node_modules/primereact/dialog/dialog.cjs.js
var dialog_cjs = __webpack_require__(6120);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
// EXTERNAL MODULE: ./node_modules/primereact/menu/menu.cjs.js
var menu_cjs = __webpack_require__(29126);
// EXTERNAL MODULE: ./node_modules/primereact/toast/toast.cjs.js
var toast_cjs = __webpack_require__(11459);
// EXTERNAL MODULE: ./node_modules/primereact/utils/utils.cjs.js
var utils_cjs = __webpack_require__(7666);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/primereact/editor/editor.cjs.js
var editor_cjs = __webpack_require__(53869);
// EXTERNAL MODULE: ./node_modules/primereact/tooltip/tooltip.cjs.js
var tooltip_cjs = __webpack_require__(64935);
// EXTERNAL MODULE: ./demo/components/apps/mail/context/mailcontext.tsx
var mailcontext = __webpack_require__(68496);
;// CONCATENATED MODULE: ./demo/components/apps/mail/AppMailReply.tsx







function AppMailReply(props) {
    const content = props.content;
    const [newMail, setNewMail] = (0,react_.useState)({
        id: 0,
        from: content?.from ?? "",
        to: content?.to ?? "",
        email: "",
        image: "",
        title: content?.title ?? "",
        message: "",
        date: "",
        important: false,
        starred: false,
        trash: false,
        spam: false,
        archived: false,
        sent: true
    });
    const [displayMessage, setDisplayMessage] = (0,react_.useState)(false);
    const { onSend, toastRef } = (0,react_.useContext)(mailcontext/* MailContext */.u);
    const sendMail = ()=>{
        let { image, from, title } = content;
        setNewMail((prevState)=>({
                ...prevState,
                to: from,
                title: title,
                image: image
            }));
        onSend(newMail);
        toastRef.current?.show({
            severity: "success",
            summary: "Success",
            detail: "Mail sent"
        });
        props.hide();
    };
    const toggleMessage = ()=>{
        setDisplayMessage((prevState)=>!prevState);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx((react_default()).Fragment, {
        children: content ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "p-0 m-0",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "surface-section grid grid-nogutter formgrid flex-column md:flex-row gap-6 p-5 border-round",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "to",
                                    className: "block text-900 font-semibold mb-3",
                                    children: "To"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "p-input-icon-left w-full",
                                    style: {
                                        height: "3.5rem"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "pi pi-user",
                                            style: {
                                                left: "1.5rem"
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                            id: "to",
                                            type: "text",
                                            value: newMail.from,
                                            onChange: (e)=>setNewMail((prevState)=>({
                                                        ...prevState,
                                                        from: e.target.value
                                                    })),
                                            className: "w-full pl-7 text-900 font-semibold",
                                            style: {
                                                height: "3.5rem"
                                            }
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    htmlFor: "Subject",
                                    className: "block text-900 font-semibold mb-3",
                                    children: "Subject"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                    className: "p-input-icon-left w-full",
                                    style: {
                                        height: "3.5rem"
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "pi pi-pencil",
                                            style: {
                                                left: "1.5rem"
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                            id: "subject",
                                            type: "text",
                                            value: newMail.title,
                                            onChange: (e)=>setNewMail((prevState)=>({
                                                        ...prevState,
                                                        title: e.target.value
                                                    })),
                                            placeholder: "Subject",
                                            className: "w-full pl-7 text-900 font-semibold",
                                            style: {
                                                height: "3.5rem"
                                            }
                                        })
                                    ]
                                })
                            ]
                        }),
                        displayMessage ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "border-1 surface-border border-round p-4",
                            children: content.message
                        }) : null,
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-12 field",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(tooltip_cjs.Tooltip, {
                                    target: ".toggle-content",
                                    content: displayMessage ? "Hide Content" : "Show Content"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "toggle-content surface-ground cursor-pointer border-round px-2",
                                    onClick: toggleMessage,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "pi pi-ellipsis-h"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(editor_cjs/* Editor */.M, {
                                    style: {
                                        height: "250px"
                                    },
                                    className: "mt-3",
                                    value: newMail.message,
                                    onTextChange: (e)=>setNewMail((prevState)=>({
                                                ...prevState,
                                                message: e.htmlValue ?? ""
                                            }))
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex column-gap-3 justify-content-end p-5 border-top-1 surface-border",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                            type: "button",
                            outlined: true,
                            icon: "pi pi-image"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                            type: "button",
                            outlined: true,
                            icon: "pi pi-paperclip"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                            type: "button",
                            className: "h-3rem",
                            icon: "pi pi-send",
                            label: "Send",
                            onClick: sendMail
                        })
                    ]
                })
            ]
        }) : null
    });
}
/* harmony default export */ const mail_AppMailReply = (AppMailReply);

;// CONCATENATED MODULE: ./demo/components/apps/mail/AppMailTable.tsx















function AppMailTable(props) {
    const [mail, setMail] = (0,react_.useState)(null);
    const [selectedMails, setSelectedMails] = (0,react_.useState)([]);
    const [filters, setFilters] = (0,react_.useState)({});
    const [globalFilterValue, setGlobalFilterValue] = (0,react_.useState)("");
    const [dialogVisible, setDialogVisible] = (0,react_.useState)(false);
    const { onStar, onArchive, onBookmark, onTrash, onDelete, onDeleteMultiple, onSpamMultiple, onArchiveMultiple, clearMailActions } = (0,react_.useContext)(mailcontext/* MailContext */.u);
    const menu = (0,react_.useRef)(null);
    const dt = (0,react_.useRef)(null);
    const toast = (0,react_.useRef)(null);
    const router = (0,navigation.useRouter)();
    const onGlobalFilterChange = (e)=>{
        const value = e.target.value;
        let _filters = {
            ...filters
        };
        _filters["global"].value = value;
        setFilters(_filters);
        setGlobalFilterValue(value);
    };
    const initFilters = ()=>{
        setFilters({
            global: {
                value: null,
                matchMode: api_cjs.FilterMatchMode.CONTAINS
            },
            name: {
                operator: api_cjs.FilterOperator.AND,
                constraints: [
                    {
                        value: null,
                        matchMode: api_cjs.FilterMatchMode.STARTS_WITH
                    }
                ]
            },
            "country.name": {
                operator: api_cjs.FilterOperator.AND,
                constraints: [
                    {
                        value: null,
                        matchMode: api_cjs.FilterMatchMode.STARTS_WITH
                    }
                ]
            },
            representative: {
                value: null,
                matchMode: api_cjs.FilterMatchMode.IN
            },
            date: {
                operator: api_cjs.FilterOperator.AND,
                constraints: [
                    {
                        value: null,
                        matchMode: api_cjs.FilterMatchMode.DATE_IS
                    }
                ]
            },
            balance: {
                operator: api_cjs.FilterOperator.AND,
                constraints: [
                    {
                        value: null,
                        matchMode: api_cjs.FilterMatchMode.EQUALS
                    }
                ]
            },
            status: {
                operator: api_cjs.FilterOperator.OR,
                constraints: [
                    {
                        value: null,
                        matchMode: api_cjs.FilterMatchMode.EQUALS
                    }
                ]
            },
            activity: {
                value: null,
                matchMode: api_cjs.FilterMatchMode.BETWEEN
            },
            verified: {
                value: null,
                matchMode: api_cjs.FilterMatchMode.EQUALS
            }
        });
        setGlobalFilterValue("");
    };
    const menuItems = [
        {
            label: "Archive",
            icon: "pi pi-fw pi-file",
            command: ()=>handleArchiveMultiple()
        },
        {
            label: "Spam",
            icon: "pi pi-fw pi-ban",
            command: ()=>handleSpamMultiple()
        },
        {
            label: "Delete",
            icon: "pi pi-fw pi-trash",
            command: ()=>handleDeleteMultiple()
        }
    ];
    const onRowSelect = (id)=>{
        router.push("/apps/mail/detail/" + id);
    };
    const handleStar = (event, id)=>{
        event.stopPropagation();
        onStar(id);
    };
    const handleArchive = (event, id)=>{
        event.stopPropagation();
        onArchive(id);
        toast.current?.show({
            severity: "info",
            summary: "Info",
            detail: "Mail archived",
            life: 3000
        });
    };
    const handleBookmark = (event, id)=>{
        event.stopPropagation();
        onBookmark(id);
    };
    const handleDelete = (id)=>{
        onDelete(id);
        toast.current?.show({
            severity: "info",
            summary: "Info",
            detail: "Mail deleted",
            life: 3000
        });
    };
    const handleDeleteMultiple = ()=>{
        let _selectedMails = [
            ...selectedMails
        ];
        if (_selectedMails && _selectedMails.length > 0) {
            for (const _mail of _selectedMails){
                clearMailActions(_mail);
            }
            onDeleteMultiple(selectedMails);
            toast.current?.show({
                severity: "info",
                summary: "Info",
                detail: "Moved to deleted",
                life: 3000
            });
        }
    };
    const handleSpamMultiple = ()=>{
        let _selectedMails = [
            ...selectedMails
        ];
        if (_selectedMails && _selectedMails.length > 0) {
            for (const _mail of _selectedMails){
                clearMailActions(_mail);
            }
            onSpamMultiple(selectedMails);
            toast.current?.show({
                severity: "info",
                summary: "Info",
                detail: "Moved to spam",
                life: 3000
            });
        }
    };
    const handleArchiveMultiple = ()=>{
        let _selectedMails = [
            ...selectedMails
        ];
        if (_selectedMails && _selectedMails.length > 0) {
            for (const _mail of _selectedMails){
                clearMailActions(_mail);
            }
            onArchiveMultiple(selectedMails);
            toast.current?.show({
                severity: "info",
                summary: "Info",
                detail: "Moved to archive",
                life: 3000
            });
        }
    };
    (0,react_.useEffect)(()=>{
        initFilters();
    }, []);
    const handleTrash = (event, mail)=>{
        event.stopPropagation();
        if (mail.trash) {
            handleDelete(mail.id);
        }
        onTrash(mail.id);
    };
    const handleReply = (event, mail)=>{
        event.stopPropagation();
        setMail(mail);
        setDialogVisible(true);
    };
    const actionHeaderTemplate = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex -ml-2",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                type: "button",
                icon: "pi pi-refresh",
                rounded: true,
                text: true,
                className: "p-button-plain"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                type: "button",
                icon: "pi pi-ellipsis-v",
                rounded: true,
                text: true,
                className: "p-button-plain ml-3",
                onClick: (event)=>menu.current?.toggle(event)
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(menu_cjs/* Menu */.v, {
                ref: menu,
                popup: true,
                model: menuItems
            })
        ]
    });
    const actionsBodyTemplate = (mail)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: !mail.trash && !mail.spam ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        style: {
                            width: "4rem"
                        },
                        onClick: (e)=>handleStar(e, mail.id),
                        onTouchEnd: (e)=>handleStar(e, mail.id),
                        className: "cursor-pointer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: (0,utils_cjs.classNames)("pi pi-fw text-xl", {
                                "pi-star-fill": mail.starred,
                                "pi-star": !mail.starred
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        onClick: (e)=>handleBookmark(e, mail.id),
                        onTouchEnd: (e)=>handleBookmark(e, mail.id),
                        className: "cursor-pointer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: (0,utils_cjs.classNames)("pi pi-fw text-xl", {
                                "pi-bookmark-fill": mail.important,
                                "pi-bookmark": !mail.important
                            })
                        })
                    })
                ]
            }) : null
        });
    };
    const avatarBodyTemplate = (mail)=>{
        const folder = mail.image ? "demo" : "layout";
        const imageName = mail.image ? mail.image : "avatar.png";
        return /*#__PURE__*/ jsx_runtime_.jsx(avatar_cjs/* Avatar */.q, {
            image: `/${folder}/images/avatar/${imageName}`,
            onClick: (e)=>onRowSelect(mail.id)
        });
    };
    const authorBodyTemplate = (mail)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "text-900 font-semibold",
            onClick: (e)=>onRowSelect(mail.id),
            style: {
                minWidth: "12rem"
            },
            children: mail.from || mail.to
        });
    };
    const titleBodyTemplate = (mail)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("span", {
            className: "font-medium white-space-nowrap overflow-hidden text-overflow-ellipsis block",
            onClick: (e)=>onRowSelect(mail.id),
            style: {
                maxWidth: "30rem",
                minWidth: "12rem"
            },
            children: mail.title
        });
    };
    const onRowMouseEnter = (event)=>{
        event.originalEvent.preventDefault();
        const id = event.index;
        const dateEl = document.getElementById(`${id}-date`);
        const optsEl = document.getElementById(`${id}-options`);
        optsEl.style.display = "flex";
        dateEl.style.display = "none";
    };
    const onRowMouseLeave = (event)=>{
        event.originalEvent.preventDefault();
        const id = event.index;
        const dateEl = document.getElementById(`${id}-date`);
        const optsEl = document.getElementById(`${id}-options`);
        optsEl.style.display = "none";
        dateEl.style.display = "flex";
    };
    const dateHeaderTemplate = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
        className: "p-input-icon-left",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                className: "pi pi-search"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                id: "search",
                placeholder: "Search Mail",
                className: "w-full sm:w-auto",
                value: globalFilterValue,
                onChange: onGlobalFilterChange
            })
        ]
    });
    const dateBodyTemplate = (mail, columnOptions)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "cursor-pointer",
            style: {
                minWidth: "10rem"
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-content-end w-full px-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        id: columnOptions.rowIndex.toString() + "-date",
                        className: "text-700 font-semibold white-space-nowrap",
                        children: mail.date
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        id: columnOptions.rowIndex.toString() + "-options",
                        style: {
                            display: "none"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                type: "button",
                                tooltip: "Archive",
                                tooltipOptions: {
                                    position: "top"
                                },
                                icon: "pi pi-inbox",
                                className: "h-2rem w-2rem mr-2",
                                onClick: (event)=>handleArchive(event, mail.id)
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                type: "button",
                                tooltip: "Reply",
                                tooltipOptions: {
                                    position: "top"
                                },
                                icon: "pi pi-reply",
                                severity: "secondary",
                                className: "h-2rem w-2rem mr-2",
                                onClick: (event)=>handleReply(event, mail)
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                type: "button",
                                tooltip: "Trash",
                                tooltipOptions: {
                                    position: "top"
                                },
                                icon: "pi pi-trash",
                                severity: "danger",
                                className: "h-2rem w-2rem",
                                onClick: (event)=>handleTrash(event, mail)
                            })
                        ]
                    })
                ]
            })
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(toast_cjs/* Toast */.F, {
                ref: toast
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(datatable_cjs/* DataTable */.w, {
                ref: dt,
                value: props.mails,
                filters: filters,
                globalFilterFields: [
                    "from",
                    "to",
                    "title"
                ],
                emptyMessage: "No mails found.",
                responsiveLayout: "scroll",
                onRowMouseEnter: onRowMouseEnter,
                onRowMouseLeave: onRowMouseLeave,
                rows: 10,
                paginator: true,
                rowHover: true,
                rowsPerPageOptions: [
                    10,
                    20,
                    30
                ],
                selection: selectedMails,
                onSelectionChange: (e)=>setSelectedMails(e.value),
                selectionMode: "checkbox",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        selectionMode: "multiple",
                        style: {
                            width: "4rem"
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        header: actionHeaderTemplate,
                        body: actionsBodyTemplate,
                        style: {
                            width: "8rem"
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        style: {
                            minWidth: "4rem"
                        },
                        body: avatarBodyTemplate
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        body: authorBodyTemplate
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        style: {
                            minWidth: "12rem"
                        },
                        body: titleBodyTemplate
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        header: dateHeaderTemplate,
                        field: "date",
                        body: dateBodyTemplate
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(dialog_cjs.Dialog, {
                header: "New Message",
                visible: dialogVisible,
                onHide: ()=>setDialogVisible(false),
                closable: true,
                modal: true,
                className: "mx-3 sm:mx-0 sm:w-full md:w-8 lg:w-6",
                contentClassName: "border-round-bottom border-top-1 surface-border p-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(mail_AppMailReply, {
                    content: mail,
                    hide: ()=>setDialogVisible(false)
                })
            })
        ]
    });
}
/* harmony default export */ const mail_AppMailTable = (AppMailTable);


/***/ }),

/***/ 68496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ MailProvider),
/* harmony export */   u: () => (/* binding */ MailContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11459);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const MailContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({});
const MailProvider = (props)=>{
    const [mails, setMails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const toastRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const getMails = ()=>{
        return fetch("/demo/data/mail.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getMails().then((data)=>setMails(data));
    }, []);
    const updateMails = (data)=>{
        setMails(data);
    };
    const clearMailActions = (mail)=>{
        Object.keys(mail).forEach((key)=>{
            if (mail[key] === true) {
                mail[key] = false;
            }
        });
    };
    const onStar = (id)=>{
        let _mails = mails.map((m)=>m.id === id ? {
                ...m,
                starred: !m.starred
            } : m);
        setMails(_mails);
    };
    const onArchive = (id)=>{
        let _mails = mails.map((m)=>m.id === id ? {
                ...m,
                archived: !m.archived
            } : m);
        setMails(_mails);
    };
    const onBookmark = (id)=>{
        let _mails = mails.map((m)=>m.id === id ? {
                ...m,
                important: !m.important
            } : m);
        setMails(_mails);
    };
    const onDelete = (id)=>{
        let _mails = mails.splice(mails.findIndex((m)=>m.id === id), 1);
        setMails(_mails);
    };
    const onDeleteMultiple = (mailArray)=>{
        const idArray = mailArray.map((m)=>Number(m.id));
        const updatedMails = mails.map((mail)=>{
            if (idArray.indexOf(mail.id) === -1) {
                return mail;
            } else {
                return {
                    ...mail,
                    trash: true
                };
            }
        });
        setMails(updatedMails);
    };
    const onArchiveMultiple = (mailArray)=>{
        const idArray = mailArray.map((m)=>m.id);
        const updatedMails = mails.map((mail)=>{
            if (idArray.indexOf(mail.id) !== -1) {
                return {
                    ...mail,
                    archived: true
                };
            } else {
                return mail;
            }
        });
        setMails(updatedMails);
    };
    const onSpamMultiple = (mailArray)=>{
        const idArray = mailArray.map((m)=>m.id);
        const updatedMails = mails.map((mail)=>{
            if (idArray.indexOf(mail.id) !== -1) {
                return {
                    ...mail,
                    spam: true,
                    important: false,
                    starred: false,
                    archived: false
                };
            } else {
                return mail;
            }
        });
        setMails(updatedMails);
    };
    const onTrash = (id)=>{
        let _mails = mails.map((m)=>m.id === id ? {
                ...m,
                trash: true,
                spam: false,
                important: false,
                starred: false,
                archived: false
            } : m);
        setMails(_mails);
    };
    const onSend = (mail)=>{
        let _mails = mails;
        if (!mail.title) {
            mail.title = "Untitled";
        }
        _mails.push(mail);
        setMails(_mails);
    };
    const value = {
        mails,
        toastRef,
        updateMails,
        clearMailActions,
        onStar,
        onArchive,
        onBookmark,
        onDelete,
        onDeleteMultiple,
        onArchiveMultiple,
        onSpamMultiple,
        onTrash,
        onSend
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_toast__WEBPACK_IMPORTED_MODULE_2__/* .Toast */ .F, {
                ref: toastRef
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MailContext.Provider, {
                value: value,
                children: props.children
            })
        ]
    });
};


/***/ }),

/***/ 77421:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\(mail)\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 51236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\(mail)\mail\spam\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,7933,1042,6903,4719,4524,5129,1501,6408,1003,1993,1459,4760,6120,9126,3869,7088,6065,2547,4972], () => (__webpack_exec__(4200)));
module.exports = __webpack_exports__;

})();