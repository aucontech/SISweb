(() => {
var exports = {};
exports.id = 8164;
exports.ids = [8164];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 98045:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'apps',
        {
        children: [
        'chat',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5203)), "D:\\sogec\\sogec-web\\app\\(main)\\apps\\chat\\page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 59745)), "D:\\sogec\\sogec-web\\app\\(main)\\apps\\chat\\layout.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\apps\\chat\\page.tsx"];
    
    const originalPathname = "/(main)/apps/chat/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 63132:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98757))

/***/ }),

/***/ 8570:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 70369))

/***/ }),

/***/ 98757:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ChatLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _demo_components_apps_chat_context_chatcontext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(68708);
/* __next_internal_client_entry_do_not_use__ default auto */ 

function ChatLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_demo_components_apps_chat_context_chatcontext__WEBPACK_IMPORTED_MODULE_1__/* .ChatProvider */ .a, {
        children: children
    });
}


/***/ }),

/***/ 70369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
// EXTERNAL MODULE: ./node_modules/primereact/overlaypanel/overlaypanel.cjs.js
var overlaypanel_cjs = __webpack_require__(98063);
// EXTERNAL MODULE: ./node_modules/primereact/utils/utils.cjs.js
var utils_cjs = __webpack_require__(7666);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./demo/components/apps/chat/context/chatcontext.tsx
var chatcontext = __webpack_require__(68708);
;// CONCATENATED MODULE: ./demo/components/apps/chat/UserCard.tsx




function UserCard(props) {
    const [lastMessage, setLastMessage] = (0,react_.useState)(null);
    const { changeActiveChat } = (0,react_.useContext)(chatcontext/* ChatContext */.p);
    const changeView = (user)=>{
        changeActiveChat(user);
    };
    const handleKeyDown = (e)=>{
        if (e.key === "Enter") changeView(props.user);
    };
    (0,react_.useEffect)(()=>{
        let filtered = props.user.messages.filter((m)=>m.ownerId !== 123);
        setLastMessage(filtered[filtered.length - 1]);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-nowrap justify-content-between align-items-center border-1 surface-border border-round p-3 cursor-pointer select-none hover:surface-hover transition-colors transition-duration-150",
        onKeyDown: handleKeyDown,
        onClick: ()=>changeView(props.user),
        tabIndex: 0,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex align-items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative md:mr-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: `/demo/images/avatar/${props.user.image}`,
                                alt: "props.user",
                                className: "w-3rem h-3rem border-circle shadow-4"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: (0,utils_cjs.classNames)("w-1rem h-1rem border-circle border-2 surface-border absolute", {
                                    "bg-green-400": props.user.status === "active",
                                    "bg-red-400": props.user.status === "busy",
                                    "bg-yellow-400": "away"
                                }),
                                style: {
                                    bottom: "2px",
                                    right: "2px"
                                }
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex-column hidden md:flex",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-900 font-semibold block",
                                children: props.user.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "block text-600 text-overflow-ellipsis overflow-hidden white-space-nowrap w-10rem text-sm",
                                children: lastMessage?.text
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "text-700 font-semibold ml-auto hidden md:inline",
                children: props.user.lastSeen
            })
        ]
    });
}
/* harmony default export */ const chat_UserCard = (UserCard);

;// CONCATENATED MODULE: ./app/(main)/apps/chat/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const ChatSidebar = ()=>{
    const [filteredUsers, setFilteredUsers] = (0,react_.useState)([]);
    const [searchValue, setSearchValue] = (0,react_.useState)("");
    const { getChatData, users, setUsers } = (0,react_.useContext)(chatcontext/* ChatContext */.p);
    const filter = (e)=>{
        let filtered = [];
        setSearchValue(e.target.value);
        for(let i = 0; i < users.length; i++){
            let user = users[i];
            if (user && user.name.toLowerCase().indexOf(searchValue.toLowerCase()) == 0) {
                filtered.push(user);
            }
        }
        if (e.target.value === "") {
            setFilteredUsers(users);
        } else setFilteredUsers([
            ...filtered
        ]);
    };
    (0,react_.useEffect)(()=>{
        getChatData().then((data)=>{
            setUsers(data);
            setFilteredUsers(data);
        });
    }, [
        getChatData,
        setUsers
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-column align-items-center border-bottom-1 surface-border p-6",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/demo/images/avatar/circle/avatar-f-1@2x.png",
                        className: "w-6rem h-6rem border-circle shadow-4",
                        alt: "Asiya Javayant"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-900 text-xl font-semibold mt-4",
                        children: "Asiya Javayant"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full flex row-gap-4 flex-column surface-border p-4",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "p-input-icon-left w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "pi pi-search"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                id: "search",
                                type: "text",
                                placeholder: "Search",
                                className: "w-full",
                                value: searchValue,
                                onChange: filter
                            })
                        ]
                    }),
                    filteredUsers ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-row gap-4 md:flex-column overflow-auto",
                        children: filteredUsers.map((user, i)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx(chat_UserCard, {
                                user: user
                            }, i);
                        })
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: "No User Found."
                    })
                ]
            })
        ]
    });
};
const ChatBox = (props)=>{
    const [textContent, setTextContent] = (0,react_.useState)("");
    const { sendMessage, users } = (0,react_.useContext)(chatcontext/* ChatContext */.p);
    const op = (0,react_.useRef)(null);
    const chatWindow = (0,react_.useRef)(null);
    const user = props.user;
    const defaultUserId = 123;
    //prettier-ignore
    const emojis = [
        "\uD83D\uDE00",
        "\uD83D\uDE03",
        "\uD83D\uDE04",
        "\uD83D\uDE01",
        "\uD83D\uDE06",
        "\uD83D\uDE05",
        "\uD83D\uDE02",
        "\uD83E\uDD23",
        "\uD83D\uDE07",
        "\uD83D\uDE09",
        "\uD83D\uDE0A",
        "\uD83D\uDE42",
        "\uD83D\uDE43",
        "\uD83D\uDE0B",
        "\uD83D\uDE0C",
        "\uD83D\uDE0D",
        "\uD83E\uDD70",
        "\uD83D\uDE18",
        "\uD83D\uDE17",
        "\uD83D\uDE19",
        "\uD83D\uDE1A",
        "\uD83E\uDD2A",
        "\uD83D\uDE1C",
        "\uD83D\uDE1D",
        "\uD83D\uDE1B",
        "\uD83E\uDD11",
        "\uD83D\uDE0E",
        "\uD83E\uDD13",
        "\uD83E\uDDD0",
        "\uD83E\uDD20",
        "\uD83E\uDD73",
        "\uD83E\uDD17",
        "\uD83E\uDD21",
        "\uD83D\uDE0F",
        "\uD83D\uDE36",
        "\uD83D\uDE10",
        "\uD83D\uDE11",
        "\uD83D\uDE12",
        "\uD83D\uDE44",
        "\uD83E\uDD28",
        "\uD83E\uDD14",
        "\uD83E\uDD2B",
        "\uD83E\uDD2D",
        "\uD83E\uDD25",
        "\uD83D\uDE33",
        "\uD83D\uDE1E",
        "\uD83D\uDE1F",
        "\uD83D\uDE20",
        "\uD83D\uDE21",
        "\uD83E\uDD2C",
        "\uD83D\uDE14",
        "\uD83D\uDE1F",
        "\uD83D\uDE20",
        "\uD83D\uDE21",
        "\uD83E\uDD2C",
        "\uD83D\uDE14",
        "\uD83D\uDE15",
        "\uD83D\uDE41",
        "\uD83D\uDE2C",
        "\uD83E\uDD7A",
        "\uD83D\uDE23",
        "\uD83D\uDE16",
        "\uD83D\uDE2B",
        "\uD83D\uDE29",
        "\uD83E\uDD71",
        "\uD83D\uDE24",
        "\uD83D\uDE2E",
        "\uD83D\uDE31",
        "\uD83D\uDE28",
        "\uD83D\uDE30",
        "\uD83D\uDE2F",
        "\uD83D\uDE26",
        "\uD83D\uDE27",
        "\uD83D\uDE22",
        "\uD83D\uDE25",
        "\uD83D\uDE2A",
        "\uD83E\uDD24"
    ];
    const _sendMessage = ()=>{
        if (textContent == "" || textContent === " ") {
            return;
        } else {
            let message = {
                text: textContent,
                ownerId: 123,
                createdAt: new Date().getTime()
            };
            sendMessage(message);
            setTextContent("");
        }
    };
    const handleInputTextKeyDown = (e)=>{
        if (e.key === "Enter") _sendMessage();
    };
    const onEmojiSelect = (emoji)=>{
        setTextContent((prevState)=>prevState += emoji);
    };
    const parseDate = (timestamp)=>{
        return new Date(timestamp).toTimeString().split(":").slice(0, 2).join(":");
    };
    (0,react_.useEffect)(()=>{
        if (chatWindow.current) {
            chatWindow.current.addEventListener("DOMNodeInserted", (event)=>{
                const target = event.currentTarget;
                if (target) {
                    target.scroll({
                        top: target.scrollHeight
                    });
                }
            });
        }
    }, [
        users
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-column h-full",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex align-items-center border-bottom-1 surface-border p-3 lg:p-6",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "relative flex align-items-center mr-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: `/demo/images/avatar/${props.user.image}`,
                                        alt: props.user.name,
                                        className: "w-4rem h-4rem border-circle shadow-4"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (0,utils_cjs.classNames)("w-1rem h-1rem border-circle border-2 surface-border absolute bottom-0 right-0", {
                                            "bg-green-400": props.user.status === "active",
                                            "bg-red-400": props.user.status === "busy",
                                            "bg-yellow-400": props.user.status === "away"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mr-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-900 font-semibold block",
                                        children: props.user.name
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-700",
                                        children: "Last active 1 hour ago"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex align-items-center ml-auto",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        type: "button",
                                        icon: "pi pi-phone",
                                        rounded: true,
                                        outlined: true,
                                        severity: "secondary",
                                        className: "mr-3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        type: "button",
                                        icon: "pi pi-ellipsis-v",
                                        rounded: true,
                                        outlined: true,
                                        severity: "secondary"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        ref: chatWindow,
                        className: "p-3 md:px-4 lg:px-6 lg:py-4 mt-2 overflow-y-auto",
                        style: {
                            maxHeight: "53vh"
                        },
                        children: props.user.messages.map((message, i)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: message.ownerId === defaultUserId ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "grid grid-nogutter mb-4",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "col mt-3 text-right",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "inline-block text-left font-medium border-1 surface-border bg-primary-100 text-primary-900 p-3 white-space-normal border-round",
                                                style: {
                                                    wordBreak: "break-word",
                                                    maxWidth: "80%"
                                                },
                                                children: message.text
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-700 mt-3",
                                                children: [
                                                    parseDate(message.createdAt),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-check ml-2 text-green-400"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "grid grid-nogutter mb-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "mr-3 mt-1",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: `/demo/images/avatar/${user.image}`,
                                                alt: user.name,
                                                className: "w-3rem h-3rem border-circle shadow-4"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "col mt-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-900 font-semibold mb-3",
                                                    children: user.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-700 inline-block font-medium border-1 surface-border p-3 white-space-normal border-round",
                                                    style: {
                                                        wordBreak: "break-word",
                                                        maxWidth: "80%"
                                                    },
                                                    children: message.text
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                    className: "text-700 mt-3",
                                                    children: [
                                                        parseDate(message.createdAt),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "pi pi-check ml-2 text-green-400"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }, i);
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-3 md:p-4 lg:p-6 flex flex-column sm:flex-row align-items-center mt-auto border-top-1 surface-border gap-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                id: "message",
                                type: "text",
                                placeholder: "Type a message",
                                className: "flex-1 w-full sm:w-auto border-round",
                                value: textContent,
                                onChange: (e)=>setTextContent(e.target.value),
                                onKeyDown: handleInputTextKeyDown
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex w-full sm:w-auto gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        className: "w-full sm:w-auto justify-content-center text-xl",
                                        severity: "secondary",
                                        onClick: (event)=>op.current?.toggle(event),
                                        children: "\uD83D\uDE00"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        label: "Send",
                                        icon: "pi pi-send",
                                        className: "w-full sm:w-auto",
                                        onClick: ()=>_sendMessage()
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(overlaypanel_cjs/* OverlayPanel */.T, {
                ref: op,
                className: "w-full sm:w-30rem",
                children: emojis.map((emoji, i)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                        onClick: ()=>{
                            op.current?.hide();
                            onEmojiSelect(emoji);
                        },
                        type: "button",
                        label: emoji,
                        text: true,
                        className: "p-2 text-2xl"
                    }, i);
                })
            })
        ]
    });
};
const Chat = ()=>{
    const { activeUser } = (0,react_.useContext)(chatcontext/* ChatContext */.p);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-column md:flex-row gap-5",
        style: {
            minHeight: "81vh"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "md:w-25rem card p-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ChatSidebar, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex-1 card p-0",
                children: /*#__PURE__*/ jsx_runtime_.jsx(ChatBox, {
                    user: activeUser
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Chat);


/***/ }),

/***/ 68708:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ ChatProvider),
/* harmony export */   p: () => (/* binding */ ChatContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ChatContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({});
const ChatProvider = (props)=>{
    const [users, setUsers] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [activeUser, setActiveUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        id: 1,
        name: "Ioni Bowcher",
        image: "ionibowcher.png",
        status: "active",
        messages: [
            {
                text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit",
                ownerId: 1,
                createdAt: 1652646338240
            },
            {
                text: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
                ownerId: 1,
                createdAt: 1652646368718
            },
            {
                text: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua",
                ownerId: 123,
                createdAt: 1652646368718
            }
        ],
        lastSeen: "2d"
    });
    const getChatData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        return fetch("/demo/data/chat.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    }, []);
    const changeActiveChat = (user)=>{
        setActiveUser(user);
    };
    const sendMessage = (message)=>{
        const _users = [
            ...users
        ];
        _users.map((user)=>user.id === activeUser.id ? user.messages.push(message) : null);
        setActiveUser((prevState)=>({
                ...prevState,
                messages: [
                    ...prevState.messages,
                    message
                ]
            }));
        setUsers(_users);
    };
    const value = {
        users,
        setUsers,
        activeUser,
        setActiveUser,
        getChatData,
        changeActiveChat,
        sendMessage
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ChatContext.Provider, {
        value: value,
        children: props.children
    });
};


/***/ }),

/***/ 59745:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\chat\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 5203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\chat\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,6065,2547,4972], () => (__webpack_exec__(98045)));
module.exports = __webpack_exports__;

})();