(() => {
var exports = {};
exports.id = 4716;
exports.ids = [4716];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 47398:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'apps',
        {
        children: [
        'tasklist',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 13247)), "D:\\sogec\\sogec-web\\app\\(main)\\apps\\tasklist\\page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4399)), "D:\\sogec\\sogec-web\\app\\(main)\\apps\\tasklist\\layout.tsx"],
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\apps\\tasklist\\page.tsx"];
    
    const originalPathname = "/(main)/apps/tasklist/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 24591:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 54037))

/***/ }),

/***/ 15296:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52057))

/***/ }),

/***/ 54037:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ AppLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _demo_components_apps_tasklist_context_taskcontext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3875);
/* __next_internal_client_entry_do_not_use__ default auto */ 

function AppLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_demo_components_apps_tasklist_context_taskcontext__WEBPACK_IMPORTED_MODULE_1__/* .TaskProvider */ .o, {
        children: children
    });
}


/***/ }),

/***/ 52057:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/primereact/autocomplete/autocomplete.cjs.js
var autocomplete_cjs = __webpack_require__(37);
// EXTERNAL MODULE: ./node_modules/primereact/calendar/calendar.cjs.js
var calendar_cjs = __webpack_require__(52186);
// EXTERNAL MODULE: ./node_modules/primereact/dialog/dialog.cjs.js
var dialog_cjs = __webpack_require__(6120);
// EXTERNAL MODULE: ./node_modules/primereact/editor/editor.cjs.js
var editor_cjs = __webpack_require__(53869);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
// EXTERNAL MODULE: ./node_modules/primereact/toast/toast.cjs.js
var toast_cjs = __webpack_require__(11459);
// EXTERNAL MODULE: ./demo/components/apps/tasklist/context/taskcontext.tsx
var taskcontext = __webpack_require__(3875);
;// CONCATENATED MODULE: ./demo/components/apps/tasklist/CreateTask.tsx










function CreateTask() {
    const [task, setTask] = (0,react_.useState)(null);
    const [filteredMembers, setFilteredMembers] = (0,react_.useState)([]);
    const toast = (0,react_.useRef)(null);
    const { addTask, editTask, closeDialog, dialogConfig, selectedTask, members } = (0,react_.useContext)(taskcontext/* TaskContext */.V);
    const filterMembers = (event)=>{
        let filtered = [];
        let query = event.query;
        for(let i = 0; i < members.length; i++){
            let member = members[i];
            if (member.name.toLowerCase().indexOf(query.toLowerCase()) == 0) {
                filtered.push(member);
            }
        }
        setFilteredMembers(filtered);
    };
    const onMemberChange = (e)=>{
        setTask((prevState)=>({
                ...prevState,
                members: [
                    ...e.value
                ]
            }));
    };
    const save = ()=>{
        if (dialogConfig.newTask) {
            toast.current?.show({
                severity: "success",
                summary: "Success",
                detail: `Task "${task?.name}" created successfully.`
            });
            addTask(task);
        } else if (selectedTask && JSON.stringify(selectedTask) !== JSON.stringify(task)) {
            toast.current?.show({
                severity: "success",
                summary: "Edited",
                detail: `Task "${selectedTask?.name}" edited successfully.`
            });
            editTask(task);
        }
        closeDialog();
    };
    const resetTask = ()=>{
        const taskId = Math.floor(Math.random() * 1000).toString();
        setTask({
            id: parseFloat(taskId),
            name: "",
            description: "",
            status: "Waiting"
        });
    };
    const itemTemplate = (member)=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex align-items-center border-round",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: `/demo/images/avatar/${member.image}`,
                    alt: member.name,
                    className: "h-2rem w-2rem mr-2"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-900 font-medium",
                    children: member.name
                })
            ]
        });
    };
    const selectedItemTemplate = (member)=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex align-items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    src: `/demo/images/avatar/${member.image}`,
                    alt: member.name,
                    className: "h-2rem w-2rem mr-2"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "text-900 font-medium",
                    children: member.name
                })
            ]
        });
    };
    (0,react_.useEffect)(()=>{
        resetTask();
    }, []);
    (0,react_.useEffect)(()=>{
        if (dialogConfig.newTask === false) setTask(selectedTask);
        if (dialogConfig.newTask) resetTask();
    }, [
        dialogConfig
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(toast_cjs/* Toast */.F, {
                ref: toast
            }, "Task Toast"),
            /*#__PURE__*/ jsx_runtime_.jsx(dialog_cjs.Dialog, {
                header: dialogConfig.header || "",
                visible: dialogConfig.visible,
                modal: true,
                dismissableMask: true,
                className: "mx-3 sm:mx-0 sm:w-full md:w-8 lg:w-6",
                contentClassName: "border-round-bottom border-top-1 surface-border p-0",
                onHide: closeDialog,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "p-4",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "grid p-fluid formgrid",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-12 field",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "name",
                                        className: "text-900 font-semibold",
                                        children: "Task Name"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                        id: "name",
                                        type: "text",
                                        placeholder: "Title",
                                        value: task?.name,
                                        onChange: (e)=>setTask((prevState)=>({
                                                    ...prevState,
                                                    name: e.target.value
                                                }))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-12 field",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "description",
                                        className: "text-900 font-semibold",
                                        children: "Description"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(editor_cjs/* Editor */.M, {
                                        value: task?.description,
                                        onTextChange: (e)=>setTask((prevState)=>({
                                                    ...prevState,
                                                    description: e.htmlValue ?? ""
                                                })),
                                        style: {
                                            height: "150px"
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-6 field mt-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "start",
                                        className: "text-900 font-semibold",
                                        children: "Start Date"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(calendar_cjs/* Calendar */.f, {
                                        dateFormat: "yy-mm-dd",
                                        showTime: false,
                                        inputId: "start",
                                        placeholder: "Start Date",
                                        value: task?.startDate,
                                        onChange: (e)=>setTask((prevState)=>({
                                                    ...prevState,
                                                    startDate: e.value?.toString()
                                                }))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-6 field mt-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "end",
                                        className: "text-900 font-semibold",
                                        children: "Due Date"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(calendar_cjs/* Calendar */.f, {
                                        dateFormat: "yy-mm-dd",
                                        showTime: false,
                                        inputId: "end",
                                        placeholder: "End Date",
                                        value: task?.endDate,
                                        onChange: (e)=>setTask((prevState)=>({
                                                    ...prevState,
                                                    endDate: e.value?.toString()
                                                }))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-12 field",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "members",
                                        className: "text-900 font-semibold",
                                        children: "Add Team Member"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(autocomplete_cjs/* AutoComplete */.Q, {
                                        itemTemplate: itemTemplate,
                                        selectedItemTemplate: selectedItemTemplate,
                                        inputId: "members",
                                        id: "autocomplete",
                                        value: task?.members,
                                        onChange: onMemberChange,
                                        placeholder: "Choose team members",
                                        suggestions: filteredMembers,
                                        completeMethod: filterMembers,
                                        field: "name",
                                        multiple: true,
                                        "aria-label": "Members",
                                        dropdownAriaLabel: "Members",
                                        inputStyle: {
                                            height: "2.5rem"
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-12 flex justify-content-end mt-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        className: "w-8rem mr-3",
                                        outlined: true,
                                        icon: "pi pi-times",
                                        label: "Cancel",
                                        onClick: closeDialog
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        className: "w-8rem",
                                        icon: "pi pi-check",
                                        label: "Save",
                                        onClick: ()=>save()
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const tasklist_CreateTask = (CreateTask);

// EXTERNAL MODULE: ./node_modules/primereact/avatar/avatar.cjs.js
var avatar_cjs = __webpack_require__(77088);
// EXTERNAL MODULE: ./node_modules/primereact/avatargroup/avatargroup.cjs.js
var avatargroup_cjs = __webpack_require__(96835);
// EXTERNAL MODULE: ./node_modules/primereact/checkbox/checkbox.cjs.js
var checkbox_cjs = __webpack_require__(27636);
// EXTERNAL MODULE: ./node_modules/primereact/menu/menu.cjs.js
var menu_cjs = __webpack_require__(29126);
// EXTERNAL MODULE: ./node_modules/primereact/utils/utils.cjs.js
var utils_cjs = __webpack_require__(7666);
;// CONCATENATED MODULE: ./demo/components/apps/tasklist/TaskList.tsx









function TaskList(props) {
    const [clickedTask, setClickedTask] = (0,react_.useState)({});
    const { markAsCompleted, removeTask, onTaskSelect, showDialog } = (0,react_.useContext)(taskcontext/* TaskContext */.V);
    const menu = (0,react_.useRef)(null);
    const menuItems = [
        {
            label: "Edit",
            icon: "pi pi-pencil",
            command: ()=>onEdit()
        },
        {
            label: "Delete",
            icon: "pi pi-trash",
            command: ()=>handleDelete()
        }
    ];
    const onCheckboxChange = (event, task)=>{
        event.originalEvent?.stopPropagation();
        task.completed = event.checked;
        markAsCompleted(task);
    };
    const parseDate = (date)=>{
        let d = new Date(date);
        return d.toUTCString().split(" ").slice(1, 3).join(" ");
    };
    const handleDelete = ()=>{
        removeTask(clickedTask?.id);
    };
    const toggleMenu = (event, task)=>{
        setClickedTask(task);
        menu.current?.toggle(event);
    };
    const onEdit = ()=>{
        onTaskSelect(clickedTask);
        showDialog("Edit Task", false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-900 font-semibold text-lg mt-5 mb-3 border-bottom-1 surface-border py-3",
                children: props.title
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "list-none p-0 m-0",
                children: props.taskList.map((task, i)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: "flex flex-column gap-3 md:flex-row md:align-items-center p-2 border-bottom-1 surface-border",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex align-items-center flex-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(checkbox_cjs/* Checkbox */.X, {
                                        onChange: (event)=>onCheckboxChange(event, task),
                                        checked: task.completed,
                                        inputId: task.id?.toString()
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: task.id?.toString(),
                                        className: (0,utils_cjs.classNames)("font-medium white-space-nowrap text-overflow-ellipsis overflow-hidden ml-2", {
                                            "line-through": task.completed
                                        }),
                                        style: {
                                            maxWidth: "300px"
                                        },
                                        children: task.name
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-1 gap-3 flex-column sm:flex-row sm:justify-content-between",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex align-items-center",
                                        children: [
                                            task.comments && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "flex align-items-center font-semibold mr-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-comment mr-2"
                                                    }),
                                                    task.comments
                                                ]
                                            }),
                                            task.attachments && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "flex align-items-center font-semibold mr-3",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-paperclip mr-2"
                                                    }),
                                                    task.attachments
                                                ]
                                            }),
                                            task.startDate && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "flex align-items-center font-semibold white-space-nowrap",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-clock mr-2"
                                                    }),
                                                    parseDate(task.startDate)
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex align-items-center sm:justify-content-end",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(avatargroup_cjs/* AvatarGroup */.H, {
                                                className: "mr-3",
                                                children: [
                                                    task.members && task.members.map((member, i)=>{
                                                        return /*#__PURE__*/ jsx_runtime_.jsx(avatar_cjs/* Avatar */.q, {
                                                            image: `/demo/images/avatar/${member.image}`,
                                                            size: "large",
                                                            shape: "circle"
                                                        }, i);
                                                    }),
                                                    task && task.members && task.members.length > 4 && /*#__PURE__*/ jsx_runtime_.jsx(avatar_cjs/* Avatar */.q, {
                                                        image: `/demo/images/avatar/amyelsner.png`,
                                                        size: "large",
                                                        shape: "circle",
                                                        label: `+${task.members.length - 4}`,
                                                        style: {
                                                            backgroundColor: "#ffffff",
                                                            color: "#212121",
                                                            border: "2px solid var(--surface-border)"
                                                        }
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                type: "button",
                                                icon: "pi pi-ellipsis-v",
                                                className: "z-3 ml-auto sm:ml-0",
                                                rounded: true,
                                                text: true,
                                                onClick: (e)=>toggleMenu(e, task)
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(menu_cjs/* Menu */.v, {
                                                ref: menu,
                                                popup: true,
                                                model: menuItems,
                                                className: "w-8rem"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }, i);
                })
            })
        ]
    });
}
/* harmony default export */ const tasklist_TaskList = (TaskList);

;// CONCATENATED MODULE: ./app/(main)/apps/tasklist/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const TaskListDemo = ()=>{
    const [todo, setTodo] = (0,react_.useState)([]);
    const [completed, setCompleted] = (0,react_.useState)([]);
    const { showDialog, tasks } = (0,react_.useContext)(taskcontext/* TaskContext */.V);
    (0,react_.useEffect)(()=>{
        setTodo(tasks.filter((t)=>t.completed !== true));
        setCompleted(tasks.filter((t)=>t.completed));
    }, [
        tasks
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "card",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex justify-content-between align-items-center mb-5",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-900 text-xl font-semibold",
                                children: "Task List"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                className: "font-semibold",
                                outlined: true,
                                icon: "pi pi-plus",
                                label: "Create Task",
                                onClick: ()=>showDialog("Create Task", true)
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(tasklist_TaskList, {
                        taskList: todo,
                        title: "ToDo"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(tasklist_TaskList, {
                        taskList: completed,
                        title: "Completed"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(tasklist_CreateTask, {})
        ]
    });
};
/* harmony default export */ const page = (TaskListDemo);


/***/ }),

/***/ 3875:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ TaskContext),
/* harmony export */   o: () => (/* binding */ TaskProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const TaskContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({});
const TaskProvider = (props)=>{
    const [tasks, setTasks] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [members, setMembers] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectedTask, setSelectedTask] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [dialogConfig, setDialogConfig] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        visible: false,
        header: "",
        newTask: false
    });
    const getTasks = ()=>{
        return fetch("/demo/data/tasks.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    };
    const getMembers = ()=>{
        return fetch("/demo/data/members.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getTasks().then((data)=>setTasks(data));
        getMembers().then((members)=>setMembers(members));
    }, []);
    const addTask = (task)=>{
        const _task = {
            ...task
        };
        _task.attachments = Math.floor(Math.random() * 10).toString();
        _task.comments = Math.floor(Math.random() * 10).toString();
        setTasks((prevState)=>[
                ...prevState,
                _task
            ]);
    };
    const editTask = (task)=>{
        const _tasks = tasks.map((t)=>t.id === task.id ? task : t);
        setTasks(_tasks);
    };
    const removeTask = (id)=>{
        const _tasks = tasks.filter((t)=>t.id !== id);
        setTasks(_tasks);
    };
    const onTaskSelect = (task)=>{
        setSelectedTask(task);
    };
    const markAsCompleted = (task)=>{
        const _tasks = tasks.map((t)=>t.id === task.id ? task : t);
        setTasks(_tasks);
    };
    const showDialog = (header, newTask)=>{
        setDialogConfig({
            visible: true,
            header,
            newTask
        });
    };
    const closeDialog = ()=>{
        setDialogConfig((prevState)=>({
                ...prevState,
                visible: false
            }));
    };
    const value = {
        dialogConfig,
        selectedTask,
        tasks,
        members,
        setTasks,
        setMembers,
        setDialogConfig,
        setSelectedTask,
        getTasks,
        getMembers,
        addTask,
        editTask,
        removeTask,
        onTaskSelect,
        showDialog,
        closeDialog,
        markAsCompleted
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TaskContext.Provider, {
        value: value,
        children: props.children
    });
};


/***/ }),

/***/ 4399:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\tasklist\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 13247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\tasklist\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,6903,6408,1459,6120,9126,590,3869,7088,6946,2186,7636,37,6835,6065,2547,4972], () => (__webpack_exec__(47398)));
module.exports = __webpack_exports__;

})();