(() => {
var exports = {};
exports.id = 6156;
exports.ids = [6156];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 90503:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'apps',
        {
        children: [
        'files',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7743)), "D:\\sogec\\sogec-web\\app\\(main)\\apps\\files\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\apps\\files\\page.tsx"];
    
    const originalPathname = "/(main)/apps/files/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 79804:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 68826))

/***/ }),

/***/ 68826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/chart/chart.cjs.js
var chart_cjs = __webpack_require__(16259);
// EXTERNAL MODULE: ./node_modules/primereact/column/column.cjs.js
var column_cjs = __webpack_require__(59210);
// EXTERNAL MODULE: ./node_modules/primereact/datatable/datatable.cjs.js
var datatable_cjs = __webpack_require__(14760);
// EXTERNAL MODULE: ./node_modules/primereact/fileupload/fileupload.cjs.js
var fileupload_cjs = __webpack_require__(18629);
// EXTERNAL MODULE: ./node_modules/primereact/menu/menu.cjs.js
var menu_cjs = __webpack_require__(29126);
// EXTERNAL MODULE: ./node_modules/primereact/toast/toast.cjs.js
var toast_cjs = __webpack_require__(11459);
// EXTERNAL MODULE: ./node_modules/primereact/utils/utils.cjs.js
var utils_cjs = __webpack_require__(7666);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
;// CONCATENATED MODULE: ./demo/service/FileService.ts
const FileService = {
    getFiles () {
        return fetch("/demo/data/file-management.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.files);
    },
    getMetrics () {
        return fetch("/demo/data/file-management.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.metrics);
    },
    getFoldersSmall () {
        return fetch("/demo/data/file-management.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.folders_small);
    },
    getFoldersLarge () {
        return fetch("/demo/data/file-management.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.folders_large);
    }
};

// EXTERNAL MODULE: ./layout/context/layoutcontext.tsx
var layoutcontext = __webpack_require__(6538);
;// CONCATENATED MODULE: ./app/(main)/apps/files/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 











function Files() {
    const [files, setFiles] = (0,react_.useState)([]);
    const [metrics, setMetrics] = (0,react_.useState)([]);
    const [folders, setFolders] = (0,react_.useState)([]);
    const [chartData, setChartData] = (0,react_.useState)(null);
    const [chartOptions, setChartOptions] = (0,react_.useState)(null);
    const [chartPlugin, setChartPlugin] = (0,react_.useState)({});
    const layoutConfig = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const fileUploader = (0,react_.useRef)(null);
    const toast = (0,react_.useRef)(null);
    const menu = (0,react_.useRef)(null);
    const dt = (0,react_.useRef)(null);
    const menuItems = [
        {
            label: "View",
            icon: "pi pi-search"
        },
        {
            label: "Refresh",
            icon: "pi pi-refresh"
        }
    ];
    const nameBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex align-items-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                    className: "text-xl text-primary mr-2 " + rowData.icon
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: rowData.name
                })
            ]
        });
    };
    const dateBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("span", {
            children: rowData.date
        });
    };
    const fileSizeBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("span", {
            children: rowData.fileSize
        });
    };
    const uploadBodyCenter = ()=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "text-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                    icon: "pi pi-times",
                    rounded: true,
                    text: true,
                    severity: "danger",
                    className: "mr-2"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                    icon: "pi pi-search",
                    rounded: true,
                    text: true
                })
            ]
        });
    };
    const onFileUploadClick = ()=>{
        const inputEl = fileUploader.current?.getInput();
        inputEl?.click();
    };
    const itemTemplate = (file, props)=>{
        const buttonEl = /*#__PURE__*/ react_default().createRef();
        const fileObject = file;
        const onImageMouseOver = (button)=>{
            if (button.current) {
                button.current.style.display = "flex";
            }
        };
        const onImageMouseLeave = (button)=>{
            if (button.current) {
                button.current.style.display = "none";
            }
        };
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-full py-3",
            style: {
                cursor: "copy"
            },
            onClick: onFileUploadClick,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "h-full relative w-7rem h-7rem border-3 border-transparent border-round hover:bg-primary transition-duration-100 cursor-auto",
                onMouseEnter: ()=>onImageMouseOver(buttonEl),
                onMouseLeave: ()=>onImageMouseLeave(buttonEl),
                style: {
                    padding: "1px"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: fileObject.objectURL,
                        alt: fileObject.name,
                        className: "w-full h-full border-round shadow-2"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                        ref: buttonEl,
                        id: fileObject.name,
                        type: "button",
                        icon: "pi pi-times",
                        rounded: true,
                        className: "hover:flex text-sm absolute justify-content-center align-items-center cursor-pointer",
                        style: {
                            top: "-10px",
                            right: "-10px",
                            display: "none"
                        },
                        onClick: (event)=>{
                            event.stopPropagation();
                            props.onRemove(event);
                        }
                    })
                ]
            })
        });
    };
    const emptyTemplate = ()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-full py-3",
            style: {
                cursor: "copy"
            },
            onClick: onFileUploadClick,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "h-full flex flex-column justify-content-center align-items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "pi pi-upload text-900 text-2xl mb-3"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-bold text-900 text-xl mb-3",
                        children: "Upload Files"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "font-medium text-600 text-md text-center",
                        children: "Drop or select files"
                    })
                ]
            })
        });
    };
    (0,react_.useEffect)(()=>{
        FileService.getFiles().then((files)=>setFiles(files));
        FileService.getMetrics().then((metrics)=>setMetrics(metrics));
        FileService.getFoldersLarge().then((folders)=>setFolders(folders));
        const documentStyle = getComputedStyle(document.documentElement);
        const textColor = documentStyle.getPropertyValue("--text-color") || "#1e293b";
        const chartPlugin = {
            id: "chartPlugin",
            beforeDraw: function(chart) {
                let ctx = chart.ctx;
                let width = chart.width;
                let height = chart.height;
                let fontSize = 1.5;
                let oldFill = ctx.fillStyle;
                ctx.restore();
                ctx.font = fontSize + "rem sans-serif";
                ctx.textBaseline = "middle";
                let text = "Free Space";
                let text2 = 50 + "GB / " + 80 + "GB";
                let textX = Math.round((width - ctx.measureText(text).width) / 2);
                let textY = (height + chart.chartArea.top) / 2.25;
                let text2X = Math.round((width - ctx.measureText(text).width) / 2.1);
                let text2Y = (height + chart.chartArea.top) / 1.75;
                ctx.fillStyle = chart.config.data.datasets[0].backgroundColor[0];
                ctx.fillText(text, textX, textY);
                ctx.fillText(text2, text2X, text2Y);
                ctx.fillStyle = oldFill;
                ctx.save();
            }
        };
        const fileChart = {
            datasets: [
                {
                    data: [
                        300,
                        100
                    ],
                    backgroundColor: [
                        documentStyle.getPropertyValue("--primary-600") || "#5457cd",
                        documentStyle.getPropertyValue("--primary-100") || "#dadafc"
                    ],
                    hoverBackgroundColor: [
                        documentStyle.getPropertyValue("--primary-700") || "#4547a9",
                        documentStyle.getPropertyValue("--primary-200") || "#bcbdf9"
                    ],
                    borderColor: "transparent",
                    fill: true
                }
            ]
        };
        const fileChartOptions = {
            animation: {
                duration: 0
            },
            responsive: true,
            maintainAspectRatio: false,
            cutout: "90%",
            plugins: {
                legend: {
                    labels: {
                        color: textColor
                    }
                }
            }
        };
        setChartData(fileChart);
        setChartOptions(fileChartOptions);
        setChartPlugin(chartPlugin);
    }, [
        layoutConfig
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "grid",
        children: [
            metrics.map((metric, i)=>{
                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-12 md:col-6 lg:col-3",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "card h-full",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex align-items-center justify-content-between mb-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-900 text-xl font-semibold",
                                        children: metric.title
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                icon: metric.icon,
                                                size: "small",
                                                rounded: true,
                                                text: true,
                                                onClick: (event)=>menu.current?.toggle(event)
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(menu_cjs/* Menu */.v, {
                                                ref: menu,
                                                popup: true,
                                                appendTo: "self",
                                                model: menuItems
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (0,utils_cjs.classNames)("border-round", metric.color),
                                        style: {
                                            height: "6px"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: (0,utils_cjs.classNames)("h-full border-round", metric.fieldColor),
                                            style: {
                                                width: "34%"
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex align-item-center justify-content-between",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-900 mt-3 text-md font-medium",
                                                children: metric.files
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-900 mt-3 text-md font-medium",
                                                children: metric.fileSize
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }, i);
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "col-12 md:col-5 xl:col-3",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "card",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-900 text-xl font-semibold mb-3",
                                children: "Account Storage"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex flex-row justify-content-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(chart_cjs/* Chart */.k, {
                                    type: "doughnut",
                                    plugins: [
                                        chartPlugin
                                    ],
                                    id: "country-chart",
                                    data: chartData,
                                    options: chartOptions,
                                    style: {
                                        width: "75%"
                                    }
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mt-5 flex gap-3",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        icon: "pi pi-search",
                                        outlined: true,
                                        className: "flex-1",
                                        label: "Details"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        icon: "pi pi-upload",
                                        className: "flex-1",
                                        label: "Upgrade"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "card",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-900 text-xl font-semibold mb-3",
                                children: "Categories"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "list-none p-0 m-0",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "p-3 mb-3 flex align-items-center justify-content-between cursor-pointer border-round bg-indigo-50 text-indigo-900",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex align-items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-image text-2xl mr-3"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ext-lg font-medium",
                                                        children: "Images"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-lg font-bold",
                                                children: "85"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "p-3 mb-3 flex align-items-center justify-content-between cursor-pointer border-round bg-purple-50 text-purple-900",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex align-items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-file text-2xl mr-3"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ext-lg font-medium",
                                                        children: "Documents"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-lg font-bold",
                                                children: "231"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                        className: "p-3 flex align-items-center justify-content-between cursor-pointer border-round bg-teal-50 text-teal-900",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex align-items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "pi pi-video text-2xl mr-3"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ext-lg font-medium",
                                                        children: "Videos"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-lg font-bold",
                                                children: "40"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "card p-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(toast_cjs/* Toast */.F, {
                                ref: toast
                            }, "fu"),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "card",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(fileupload_cjs/* FileUpload */.p, {
                                    ref: fileUploader,
                                    name: "demo[]",
                                    url: "./upload.php",
                                    accept: "image/*",
                                    customUpload: true,
                                    multiple: true,
                                    auto: true,
                                    className: "upload-button-hidden w-full",
                                    itemTemplate: itemTemplate,
                                    emptyTemplate: emptyTemplate,
                                    maxFileSize: 1000000,
                                    invalidFileSizeMessageSummary: "Invalid File Size",
                                    invalidFileSizeMessageDetail: "Max Size: 1MB"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "col-12 md:col-7 xl:col-9",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "card",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-900 text-xl font-semibold mb-3",
                                children: "Folders"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "grid",
                                children: folders.map((folder, i)=>{
                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "col-12 md:col-6 xl:col-4",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "p-3 border-1 surface-border flex align-items-center justify-content-between hover:surface-100 cursor-pointer border-round",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex align-items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: (0,utils_cjs.classNames)("text-2xl mr-3", folder.icon)
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "text-900 text-lg font-medium",
                                                            children: folder.name
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "text-600 text-lg font-semibold",
                                                    children: folder.size
                                                })
                                            ]
                                        })
                                    }, i);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "card",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-900 text-xl font-semibold mb-3",
                                children: "Recent Uploads"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(datatable_cjs/* DataTable */.w, {
                                ref: dt,
                                value: files,
                                paginator: true,
                                rows: 8,
                                responsiveLayout: "scroll",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                        field: "name",
                                        header: "Name",
                                        sortable: true,
                                        body: nameBodyTemplate,
                                        headerStyle: {
                                            minWidth: "12rem"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                        field: "date",
                                        header: "Date",
                                        body: dateBodyTemplate,
                                        headerClassName: "white-space-nowrap",
                                        headerStyle: {
                                            minWidth: "12rem"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                        field: "fileSize",
                                        header: "File Size",
                                        body: fileSizeBodyTemplate,
                                        sortable: true,
                                        headerStyle: {
                                            minWidth: "12rem"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                        body: uploadBodyCenter,
                                        style: {
                                            width: "10rem"
                                        }
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const page = (Files);


/***/ }),

/***/ 7743:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\files\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,7933,1042,6903,4719,4524,5129,1501,6408,1003,1993,1459,4760,9126,2085,9903,8629,6259,6065,2547,4972], () => (__webpack_exec__(90503)));
module.exports = __webpack_exports__;

})();