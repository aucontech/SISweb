(() => {
var exports = {};
exports.id = 3143;
exports.ids = [3143,6065,2547,1130];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 99261:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'devices',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 20504)), "D:\\sogec\\sogec-web\\app\\(main)\\devices\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\devices\\page.tsx"];
    
    const originalPathname = "/(main)/devices/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 19321:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 71615))

/***/ }),

/***/ 96032:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 81611))

/***/ }),

/***/ 15906:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 61522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 97844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 86249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 13100, 23))

/***/ }),

/***/ 76670:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 27977, 23))

/***/ }),

/***/ 8639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ getDevices)
/* harmony export */ });
/* harmony import */ var _http_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49213);

const getDevices = (reqParams)=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.get("/tenant/deviceInfos", {
        params: {
            ...reqParams
        }
    });
};


/***/ }),

/***/ 96241:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Iy: () => (/* binding */ saveOrUpdateDeviceProfile),
/* harmony export */   O_: () => (/* binding */ getDeviceProfiles),
/* harmony export */   PB: () => (/* binding */ getDeviceProfileById),
/* harmony export */   mI: () => (/* binding */ getTimeSeriesKeyByProfileId)
/* harmony export */ });
/* harmony import */ var _http_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49213);

const getDeviceProfiles = (reqParams)=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.get("/deviceProfiles", {
        params: {
            ...reqParams
        }
    });
};
const getDeviceProfileById = (id)=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.get(`/deviceProfile/${id}`, {});
};
const saveOrUpdateDeviceProfile = (deviceProfile)=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.post(`/deviceProfile`, deviceProfile);
};
const getTimeSeriesKeyByProfileId = (id)=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.get(`/deviceProfile/devices/keys/timeseries`, {
        params: {
            deviceProfileId: id
        }
    });
};


/***/ }),

/***/ 71615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./api/device.api.ts
var device_api = __webpack_require__(8639);
// EXTERNAL MODULE: ./service/Utils.ts
var Utils = __webpack_require__(31130);
// EXTERNAL MODULE: ./node_modules/primereact/toast/toast.cjs.js
var toast_cjs = __webpack_require__(11459);
// EXTERNAL MODULE: ./node_modules/primereact/datatable/datatable.cjs.js
var datatable_cjs = __webpack_require__(14760);
// EXTERNAL MODULE: ./node_modules/primereact/column/column.cjs.js
var column_cjs = __webpack_require__(59210);
// EXTERNAL MODULE: ./node_modules/primereact/confirmdialog/confirmdialog.cjs.js
var confirmdialog_cjs = __webpack_require__(82558);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
// EXTERNAL MODULE: ./node_modules/primereact/sidebar/sidebar.cjs.js
var sidebar_cjs = __webpack_require__(63862);
// EXTERNAL MODULE: ./node_modules/primereact/tabview/tabview.cjs.js
var tabview_cjs = __webpack_require__(11184);
// EXTERNAL MODULE: ./api/deviceProfile.api.ts
var deviceProfile_api = __webpack_require__(96241);
// EXTERNAL MODULE: ./node_modules/primereact/panel/panel.cjs.js
var panel_cjs = __webpack_require__(80400);
// EXTERNAL MODULE: ./node_modules/primereact/dialog/dialog.cjs.js
var dialog_cjs = __webpack_require__(6120);
// EXTERNAL MODULE: ./node_modules/primereact/autocomplete/autocomplete.cjs.js
var autocomplete_cjs = __webpack_require__(37);
;// CONCATENATED MODULE: ./app/(main)/devices/components/DeviceProfileAlarmSetting.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const DeviceProfileAlarmSetting = ({ alarm, onAlarmUpdate, deviceProfileId })=>{
    const [editAlarm, setEditAlarm] = (0,react_.useState)({});
    const [condition, setCondition] = (0,react_.useState)({});
    const [clearCondition, setClearCondition] = (0,react_.useState)({});
    const [isConditionFormVisible, setIsConditionFormVisible] = (0,react_.useState)(false);
    const [suggKey, setSuggKey] = (0,react_.useState)([]);
    const [valueTypes, setValueTypes] = (0,react_.useState)([]);
    const [operations, setOperations] = (0,react_.useState)([]);
    const [suggBoolValues, setSuggBoolValues] = (0,react_.useState)([]);
    (0,react_.useEffect)(()=>{
        console.log(alarm);
        let newEditAlarm = {
            ...editAlarm,
            ...alarm
        };
        if (alarm.createRules.CRITICAL.condition.condition[0] !== undefined) {
            setCondition(alarm.createRules.CRITICAL.condition.condition[0]);
        }
        setEditAlarm(newEditAlarm);
    }, [
        alarm
    ]);
    const _renderAlarmRule = (editAlarm)=>{
        const condition = editAlarm?.createRules?.CRITICAL?.condition?.condition[0];
        let conditionString = "";
        if (condition) {
            const key = condition.key.key;
            const operation = condition.predicate.operation.toLowerCase();
            const value = condition.predicate.value.defaultValue;
            if (value !== null) {
                conditionString = `Condition: ${key} ${operation} ${value}`;
            } else {
                conditionString = `Condition: `;
            }
        }
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                conditionString,
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                    onClick: ()=>setIsConditionFormVisible(true),
                    children: "edit"
                }),
                " "
            ]
        });
    };
    const _renderClearAlarmRule = (editAlarm)=>{
        const condition = editAlarm?.clearRule?.condition?.condition[0];
        let conditionString = "";
        if (condition) {
            const key = condition.key.key; // "E_Stop_DI"
            const operation = condition.predicate.operation.toLowerCase(); // "equal"
            const value = condition.predicate.value.defaultValue; // true
            conditionString = `Condition: ${key} ${operation} ${value}`;
        } else {
            conditionString = "Condition: ";
        }
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                conditionString,
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                    children: "edit"
                }),
                " "
            ]
        });
    };
    const _onChangeValueInput = (field, value)=>{
        console.log(value);
        let newEditAlarm = {
            ...editAlarm
        };
        newEditAlarm[field] = value;
        setEditAlarm(newEditAlarm);
        onAlarmUpdate(newEditAlarm);
    };
    const _renderAlarmRuleForm = (editAlarm)=>{
        if (editAlarm.createRules) {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        children: "Alarm rule"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 lg:col-12 ",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "p-float-label",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                    className: "w-full",
                                    value: editAlarm.alarmType,
                                    onChange: (e)=>_onChangeValueInput("alarmType", e.target.value)
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                    children: "Alarm Type"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 lg:col-12 ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "p-float-label",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: _renderAlarmRule(editAlarm)
                            })
                        })
                    })
                ]
            });
        }
    };
    const _renderClearAlarmRuleForm = (editAlarm)=>{
        if (editAlarm.clearRule) {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        children: "Clear alarm rule"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 lg:col-12 ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "p-float-label",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: _renderClearAlarmRule(editAlarm)
                            })
                        })
                    })
                ]
            });
        } else {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        children: "Clear alarm rule"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 lg:col-12 ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "p-float-label",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: _renderClearAlarmRule(editAlarm)
                            })
                        })
                    })
                ]
            });
        }
    };
    const _onSuggKey = ()=>{
        (0,deviceProfile_api/* getTimeSeriesKeyByProfileId */.mI)(deviceProfileId).then((resp)=>resp.data).then((res)=>{
            setSuggKey([
                ...res
            ]);
        }).catch((err)=>{
            setSuggKey([]);
        });
    };
    const _onSuggValueTypes = ()=>{
        setValueTypes([
            {
                label: "NUMERIC",
                value: "NUMERIC"
            },
            {
                label: "BOOLEAN",
                value: "BOOLEAN"
            }
        ]);
    };
    const _onChangConditionForm = (field, value)=>{
        let newCondition = {
            ...condition
        };
        switch(field){
            case "key":
                newCondition.key.key = value;
                setCondition(newCondition);
                break;
            case "valueType":
                console.log(value);
                newCondition.valueType = value.value;
                setCondition(newCondition);
                break;
            case "operation":
                console.log(value);
                newCondition.predicate.operation = value.value;
                newCondition.predicate.type = newCondition.valueType;
                setCondition(newCondition);
                break;
            case "numericValue":
                console.log(value);
                newCondition.predicate.value.defaultValue = Number(value);
                setCondition(newCondition);
                break;
            case "boolValue":
                console.log(typeof value);
                newCondition.predicate.value.defaultValue = value === "true" ? true : false;
                console.log(newCondition);
                setCondition(newCondition);
                break;
            default:
                break;
        }
    };
    const _onSuggOperations = ()=>{
        if (condition.valueType === "NUMERIC") {
            setOperations([
                {
                    label: "EQUAL",
                    value: "EQUAL"
                },
                {
                    label: "NOT_EQUAL",
                    value: "NOT_EQUAL"
                },
                {
                    label: "GREATER",
                    value: "GREATER"
                },
                {
                    label: "LESS",
                    value: "LESS"
                },
                {
                    label: "GREATER_OR_EQUAL",
                    value: "GREATER_OR_EQUAL"
                },
                {
                    label: "LESS_OR_EQUAL",
                    value: "LESS_OR_EQUAL"
                }
            ]);
        } else if (condition.valueType === "BOOLEAN") {
            setOperations([
                {
                    label: "EQUAL",
                    value: "EQUAL"
                },
                {
                    label: "NOT_EQUAL",
                    value: "NOT_EQUAL"
                }
            ]);
        }
    //setOperations([{ label: "GREATER", value: "GREATER" }]);
    };
    const _renderValueInput = (condition)=>{
        if (condition.valueType === "NUMERIC") {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        children: "Value"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                        keyfilter: "pint",
                        value: condition?.predicate?.value?.defaultValue,
                        onChange: (e)=>{
                            console.log(e);
                            _onChangConditionForm("numericValue", e.target.value);
                        }
                    })
                ]
            });
        } else if (condition.valueType === "BOOLEAN") {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                        children: "Value"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(autocomplete_cjs/* AutoComplete */.Q, {
                        dropdown: true,
                        value: condition?.predicate?.value?.defaultValue,
                        suggestions: suggBoolValues,
                        onChange: (e)=>{
                            _onChangConditionForm("boolValue", e.value);
                        },
                        completeMethod: _onSuggBoolValues
                    })
                ]
            });
        }
    };
    const _onSuggBoolValues = ()=>{
        setSuggBoolValues([
            "true",
            "false"
        ]);
    };
    const _onOkCondtionForm = ()=>{
        console.log(condition);
        console.log(editAlarm);
        editAlarm.createRules.CRITICAL.condition.condition = [
            {
                ...condition
            }
        ];
        setEditAlarm(editAlarm);
        onAlarmUpdate(editAlarm);
    };
    const footerConditionForm = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                label: "Ok",
                icon: "pi pi-check",
                onClick: _onOkCondtionForm,
                autoFocus: true
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                label: "Cancel",
                icon: "pi pi-check"
            })
        ]
    });
    console.log(condition);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(panel_cjs/* Panel */.s, {
                    header: editAlarm?.alarmType,
                    toggleable: true,
                    children: [
                        _renderAlarmRuleForm(editAlarm),
                        _renderClearAlarmRuleForm(editAlarm)
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(dialog_cjs.Dialog, {
                    header: "Condition Form",
                    visible: isConditionFormVisible,
                    onHide: ()=>setIsConditionFormVisible(false),
                    footer: footerConditionForm,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "card p-fluid",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "formgrid grid",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "field col",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "Key"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(autocomplete_cjs/* AutoComplete */.Q, {
                                            dropdown: true,
                                            value: condition?.key?.key,
                                            suggestions: suggKey,
                                            completeMethod: _onSuggKey,
                                            onChange: (e)=>{
                                                _onChangConditionForm("key", e.value);
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "field col",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "Value Types"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(autocomplete_cjs/* AutoComplete */.Q, {
                                            dropdown: true,
                                            field: "label",
                                            suggestions: valueTypes,
                                            value: condition?.valueType,
                                            onChange: (e)=>{
                                                _onChangConditionForm("valueType", e.value);
                                            },
                                            completeMethod: _onSuggValueTypes
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "field col",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            children: "Operation"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(autocomplete_cjs/* AutoComplete */.Q, {
                                            dropdown: true,
                                            field: "label",
                                            suggestions: operations,
                                            value: condition?.predicate?.operation,
                                            onChange: (e)=>{
                                                _onChangConditionForm("operation", e.value);
                                            },
                                            completeMethod: _onSuggOperations
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "field col",
                                    children: _renderValueInput(condition)
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_DeviceProfileAlarmSetting = (DeviceProfileAlarmSetting);

;// CONCATENATED MODULE: ./app/(main)/devices/components/DeviceProfileAlarmSettings.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const DeviceProfileAlarmSettings = ({ alarms, onAlarmsUpdate, deviceProfileId })=>{
    const [alarmList, setAlarmList] = (0,react_.useState)([]);
    (0,react_.useEffect)(()=>{
        setAlarmList(alarms);
    }, [
        alarms
    ]);
    const handleAlarmUpdate = (index, updatedAlarm)=>{
        console.log("udapte ne", updatedAlarm);
        console.log("index ne", index);
        const updatedAlarms = [
            ...alarmList
        ];
        updatedAlarms[index] = updatedAlarm;
        setAlarmList(updatedAlarms);
        onAlarmsUpdate(updatedAlarms);
    };
    console.log(alarmList);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: alarmList && alarmList.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("ol", {
                children: alarmList.map((alarm, index)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_DeviceProfileAlarmSetting, {
                            onAlarmUpdate: (updatedAlarm)=>handleAlarmUpdate(index, updatedAlarm),
                            deviceProfileId: deviceProfileId,
                            alarm: alarm
                        })
                    }, index))
            }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: "No alarms set."
            })
        })
    });
};
/* harmony default export */ const components_DeviceProfileAlarmSettings = (DeviceProfileAlarmSettings);

// EXTERNAL MODULE: ./api/http.api.ts
var http_api = __webpack_require__(49213);
;// CONCATENATED MODULE: ./api/telemetry.api.ts

const getSeverAttributesByDevice = (deviceId)=>{
    return http_api/* httpApi */.Y.get(`/plugins/telemetry/DEVICE/${deviceId}/values/attributes/SERVER_SCOPE`);
};

;// CONCATENATED MODULE: ./app/(main)/devices/components/AttributeSetting.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const AttributeSetting = ({ deviceId })=>{
    console.log(deviceId);
    const [attributes, setAttributes] = (0,react_.useState)([]);
    const _fecthDataAttribute = (0,react_.useCallback)((deviceId)=>{
        getSeverAttributesByDevice(deviceId).then((resp)=>resp.data).then((res)=>{
            setAttributes([
                ...res
            ]);
        }).catch((err)=>{});
    }, []);
    (0,react_.useEffect)(()=>{
        _fecthDataAttribute(deviceId);
    }, [
        deviceId
    ]);
    const _renderLastUpdateTime = (row)=>{
        let { lastUpdateTs } = row;
        return lastUpdateTs ? Utils/* Utils */.c.formatUnixTimeToString(lastUpdateTs) : "";
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(datatable_cjs/* DataTable */.w, {
                // rows={lazyState.rows}
                rowsPerPageOptions: [
                    5,
                    10,
                    25,
                    50
                ],
                //header={renderHeader}
                value: attributes,
                //  paginator
                selectionMode: "single",
                // lazy={true}
                // selection={selectedDevice}
                className: "datatable-responsive",
                emptyMessage: "No records found.",
                paginatorTemplate: "CurrentPageReport RowsPerPageDropdown FirstPageLink PrevPageLink PageLinks  NextPageLink LastPageLink",
                currentPageReportTemplate: "Showing {first} to {last} of {totalRecords}",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        header: "Last Update Time",
                        body: _renderLastUpdateTime
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        field: "key",
                        header: "key"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                        field: "value",
                        header: "Value"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const components_AttributeSetting = (AttributeSetting);

;// CONCATENATED MODULE: ./app/(main)/devices/components/DeviceProfileForm.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







//nếu chưa có alarm nào thì set alarms =
const defaultAlarms = [
    {
        alarmType: "",
        createRules: {
            CRITICAL: {
                condition: {
                    condition: [
                        {
                            key: {
                                type: "TIME_SERIES",
                                key: ""
                            },
                            valueType: "",
                            value: null,
                            predicate: {
                                type: "",
                                operation: "",
                                value: {
                                    defaultValue: null,
                                    userValue: null,
                                    dynamicValue: null
                                }
                            }
                        }
                    ],
                    spec: {
                        type: "SIMPLE"
                    }
                },
                schedule: null,
                alarmDetails: null,
                dashboardId: null
            }
        },
        clearRule: {
            condition: {
                condition: [],
                spec: {
                    type: "SIMPLE"
                }
            },
            schedule: null,
            alarmDetails: null,
            dashboardId: null
        },
        //clearRule: null,
        propagate: false,
        propagateToOwner: false,
        propagateToTenant: false,
        propagateRelationTypes: null
    }
];
const defaultAlarm = {
    alarmType: "",
    createRules: {
        CRITICAL: {
            condition: {
                condition: [
                    {
                        key: {
                            type: "TIME_SERIES",
                            key: ""
                        },
                        valueType: "",
                        value: null,
                        predicate: {
                            type: "",
                            operation: "",
                            value: {
                                defaultValue: null,
                                userValue: null,
                                dynamicValue: null
                            }
                        }
                    }
                ],
                spec: {
                    type: "SIMPLE"
                }
            },
            schedule: null,
            alarmDetails: null,
            dashboardId: null
        }
    },
    clearRule: {
        condition: {
            condition: [],
            //     {
            //         key: {
            //             type: "",
            //             key: "",
            //         },
            //         valueType: "",
            //         value: null,
            //         predicate: {
            //             type: "",
            //             operation: "",
            //             value: {
            //                 defaultValue: null,
            //                 userValue: null,
            //                 dynamicValue: null,
            //             },
            //         },
            //     },
            // ],
            spec: {
                type: "SIMPLE"
            }
        },
        schedule: null,
        alarmDetails: null,
        dashboardId: null
    },
    //  clearRule: null,
    propagate: false,
    propagateToOwner: false,
    propagateToTenant: false,
    propagateRelationTypes: null
};
const DeviceProfileForm = ({ device })=>{
    console.log(device);
    const [deviceProfile, setDeviceProfile] = (0,react_.useState)({});
    const _fetchDataDeviceProfile = (0,react_.useCallback)(({ id })=>{
        (0,deviceProfile_api/* getDeviceProfileById */.PB)(id).then((resp)=>resp.data).then((res)=>{
            console.log(res);
            setDeviceProfile(res);
        }).catch((err)=>console.log(err));
    }, []);
    const handleAlarmsUpdate = (updatedAlarms)=>{
        console.log(updatedAlarms);
        let newDeviceProfile = {};
        newDeviceProfile = {
            ...deviceProfile,
            profileData: {
                ...deviceProfile.profileData,
                alarms: [
                    ...updatedAlarms
                ]
            }
        };
        console.log(newDeviceProfile);
        setDeviceProfile(newDeviceProfile);
    };
    (0,react_.useEffect)(()=>{
        console.log(device);
        if (device && device.deviceProfileId && device.deviceProfileId.id) {
            let profileId = device.deviceProfileId.id;
            _fetchDataDeviceProfile({
                id: profileId
            });
        }
    }, [
        device,
        _fetchDataDeviceProfile
    ]);
    console.log(deviceProfile);
    const _hanldeSubmit = ()=>{
        (0,deviceProfile_api/* saveOrUpdateDeviceProfile */.Iy)(deviceProfile);
    };
    const _handleNewAlarm = ()=>{
        let newDeviceProfile = {};
        if (deviceProfile?.profileData?.alarms === null) {
            newDeviceProfile = {
                ...deviceProfile,
                profileData: {
                    ...deviceProfile.profileData,
                    alarms: [
                        ...defaultAlarms
                    ]
                }
            };
        } else {
            newDeviceProfile = {
                ...deviceProfile,
                profileData: {
                    ...deviceProfile.profileData,
                    alarms: [
                        ...deviceProfile.profileData.alarms,
                        defaultAlarm
                    ]
                }
            };
        }
        console.log(newDeviceProfile);
        setDeviceProfile(newDeviceProfile);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(tabview_cjs/* TabView */.xf, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(tabview_cjs/* TabPanel */.x4, {
                header: "Alarms",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_DeviceProfileAlarmSettings, {
                        onAlarmsUpdate: (updatedAlarms)=>handleAlarmsUpdate(updatedAlarms),
                        alarms: deviceProfile?.profileData?.alarms,
                        deviceProfileId: deviceProfile?.id?.id
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                        onClick: _hanldeSubmit,
                        children: "Submit"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                        onClick: _handleNewAlarm,
                        children: "New Alarm"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(tabview_cjs/* TabPanel */.x4, {
                header: "Attributes",
                children: /*#__PURE__*/ jsx_runtime_.jsx(components_AttributeSetting, {
                    deviceId: device.id.id
                })
            })
        ]
    });
};
/* harmony default export */ const components_DeviceProfileForm = (DeviceProfileForm);

;// CONCATENATED MODULE: ./app/(main)/devices/components/DeviceList.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 












const DeviceList = ()=>{
    const [devices, setDevices] = (0,react_.useState)([]);
    const [totalElements, setTotalElements] = (0,react_.useState)(0);
    const [textSearch, setTextSearch] = (0,react_.useState)("");
    const toast = (0,react_.useRef)(null);
    const typingTimeout = (0,react_.useRef)(null);
    const [isVisible, setIsVisible] = (0,react_.useState)(false);
    const [selectedDevice, setSelectedDevice] = (0,react_.useState)({});
    const _fetchDataDevices = (0,react_.useCallback)(({ pageSize, page, sortOrder, textSearch })=>{
        (0,device_api/* getDevices */.P)({
            pageSize,
            page,
            sortProperty: "createdTime",
            sortOrder: "DESC",
            textSearch
        }).then((resp)=>resp.data).then((res)=>{
            console.log(res.data);
            setDevices([
                ...res.data
            ]);
            setTotalElements(res.totalElements);
        }).catch((err)=>{
            Utils/* UIUtils */.e.showError({
                error: err?.message,
                toast: toast.current
            });
        });
    }, []);
    const [lazyState, setlazyState] = (0,react_.useState)({
        first: 0,
        rows: 10,
        page: 0,
        sortField: null,
        sortOrder: null,
        filters: {}
    });
    const _renderCreatedTime = (row)=>{
        let createdTime = row.createdTime;
        return createdTime ? Utils/* Utils */.c.formatUnixTimeToString(createdTime) : "";
    };
    const _renderState = (row)=>{
        let { active } = row;
        return active ? /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
            disabled: true,
            label: "Active",
            rounded: true,
            severity: "success"
        }) : /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
            disabled: true,
            label: "Inactive",
            rounded: true,
            severity: "danger"
        });
    };
    (0,react_.useEffect)(()=>{
        _fetchDataDevices({
            pageSize: lazyState.rows,
            page: lazyState.page,
            textSearch
        });
    }, [
        lazyState
    ]);
    (0,react_.useEffect)(()=>{
        if (typingTimeout.current) {
            clearTimeout(typingTimeout.current);
        }
        typingTimeout.current = setTimeout(()=>{
            _fetchDataDevices({
                pageSize: lazyState.rows,
                page: lazyState.page,
                textSearch
            });
        }, 300);
        return ()=>{
            if (typingTimeout.current) {
                clearTimeout(typingTimeout.current);
            }
        };
    }, [
        textSearch,
        lazyState
    ]);
    const _onInvsPaging = (event)=>{
        setlazyState(event);
    };
    const renderHeader = ()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex flex-wrap gap-2 align-items-center justify-content-between",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                className: "p-input-icon-left w-full sm:w-20rem flex-order-1 sm:flex-order-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "pi pi-search"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                        placeholder: "Global Search",
                        value: textSearch,
                        onChange: handleInputChange,
                        className: "w-full"
                    })
                ]
            })
        });
    };
    const handleInputChange = (e)=>{
        const value = e.target.value;
        setTextSearch(value);
    };
    const _onClickSelection = (e)=>{
        setSelectedDevice(e.value);
        setIsVisible(true);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(toast_cjs/* Toast */.F, {
                    ref: toast
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(confirmdialog_cjs/* ConfirmDialog */.QH, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(datatable_cjs/* DataTable */.w, {
                        rows: lazyState.rows,
                        rowsPerPageOptions: [
                            5,
                            10,
                            25,
                            50
                        ],
                        header: renderHeader,
                        value: devices,
                        paginator: true,
                        selectionMode: "single",
                        lazy: true,
                        selection: selectedDevice,
                        className: "datatable-responsive",
                        emptyMessage: "No records found.",
                        paginatorTemplate: "CurrentPageReport RowsPerPageDropdown FirstPageLink PrevPageLink PageLinks  NextPageLink LastPageLink",
                        currentPageReportTemplate: "Showing {first} to {last} of {totalRecords}",
                        totalRecords: totalElements,
                        first: lazyState.first,
                        dataKey: "id",
                        onPage: _onInvsPaging,
                        onSelectionChange: (e)=>_onClickSelection(e),
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                sortable: true,
                                header: "Created Time",
                                body: _renderCreatedTime
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                field: "name",
                                header: " Name"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                field: "deviceProfileName",
                                header: "Device profile"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                field: "label",
                                header: "Label"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                field: "active",
                                header: "State",
                                body: _renderState
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(sidebar_cjs/* Sidebar */.Y, {
                    visible: isVisible,
                    className: "w-5",
                    position: "right",
                    onHide: ()=>setIsVisible(false),
                    children: /*#__PURE__*/ jsx_runtime_.jsx(components_DeviceProfileForm, {
                        device: selectedDevice
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_DeviceList = (DeviceList);

;// CONCATENATED MODULE: ./app/(main)/devices/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

const devices = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(components_DeviceList, {})
    });
};
/* harmony default export */ const page = (devices);


/***/ }),

/***/ 81611:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _layout_context_layoutcontext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6538);
/* harmony import */ var primeflex_primeflex_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(63468);
/* harmony import */ var primeflex_primeflex_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(primeflex_primeflex_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var primeicons_primeicons_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51091);
/* harmony import */ var primeicons_primeicons_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(primeicons_primeicons_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(90284);
/* harmony import */ var primereact_resources_primereact_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(84732);
/* harmony import */ var primereact_resources_primereact_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(primereact_resources_primereact_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_demo_Demos_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(63114);
/* harmony import */ var _styles_demo_Demos_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_demo_Demos_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_layout_layout_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(97993);
/* harmony import */ var _styles_layout_layout_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_layout_layout_scss__WEBPACK_IMPORTED_MODULE_6__);
/* __next_internal_client_entry_do_not_use__ default auto */ 







function RootLayout({ children }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("html", {
        lang: "en",
        suppressHydrationWarning: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("head", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                    id: "theme-link",
                    href: `/theme/theme-light/indigo/theme.css`,
                    rel: "stylesheet"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_api__WEBPACK_IMPORTED_MODULE_7__.PrimeReactProvider, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_context_layoutcontext__WEBPACK_IMPORTED_MODULE_1__/* .LayoutProvider */ .a, {
                        children: children
                    })
                })
            })
        ]
    });
}


/***/ }),

/***/ 92547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90284);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18176);
/* harmony import */ var primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63579);
/* harmony import */ var primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23064);
/* harmony import */ var primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63862);
/* harmony import */ var primereact_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7666);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6538);
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AppConfig = (props)=>{
    const { layoutConfig, setLayoutConfig, layoutState, setLayoutState, isSlim, isSlimPlus, isHorizontal } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__/* .LayoutContext */ .V);
    const { changeTheme } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(primereact_api__WEBPACK_IMPORTED_MODULE_3__.PrimeReactContext);
    const scales = [
        12,
        13,
        14,
        15,
        16
    ];
    const componentThemes = [
        {
            name: "indigo",
            color: "#6366F1"
        },
        {
            name: "blue",
            color: "#3B82F6"
        },
        {
            name: "purple",
            color: "#8B5CF6"
        },
        {
            name: "teal",
            color: "#14B8A6"
        },
        {
            name: "cyan",
            color: "#06b6d4"
        },
        {
            name: "green",
            color: "#10b981"
        },
        {
            name: "orange",
            color: "#f59e0b"
        },
        {
            name: "pink",
            color: "#d946ef"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isSlim() || isSlimPlus() || isHorizontal()) {
            setLayoutState((prevState)=>({
                    ...prevState,
                    resetMenu: true
                }));
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.menuMode
    ]);
    const onConfigButtonClick = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: true
            }));
    };
    const onConfigSidebarHide = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: false
            }));
    };
    const changeInputStyle = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                inputStyle: e.value
            }));
    };
    const changeRipple = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                ripple: e.value
            }));
    };
    const changeMenuMode = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuMode: e.value
            }));
    };
    const changeMenuTheme = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuTheme: e.value
            }));
    };
    const changeColorScheme = (colorScheme)=>{
        changeTheme?.(layoutConfig.colorScheme, colorScheme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    colorScheme
                }));
        });
    };
    const _changeTheme = (theme)=>{
        changeTheme?.(layoutConfig.theme, theme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    theme
                }));
        });
    };
    const decrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale - 1
            }));
    };
    const incrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale + 1
            }));
    };
    const applyScale = ()=>{
        document.documentElement.style.fontSize = layoutConfig.scale + "px";
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        applyScale();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.scale
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "layout-config-button config-link",
                type: "button",
                onClick: onConfigButtonClick,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "pi pi-cog"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__/* .Sidebar */ .Y, {
                visible: layoutState.configSidebarVisible,
                onHide: onConfigSidebarHide,
                position: "right",
                className: "layout-config-sidebar w-18rem",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Themes"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap row-gap-3",
                        children: componentThemes.map((theme, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    className: "cursor-pointer p-link w-2rem h-2rem border-circle flex-shrink-0 flex align-items-center justify-content-center",
                                    onClick: ()=>_changeTheme(theme.name),
                                    style: {
                                        backgroundColor: theme.color
                                    },
                                    children: theme.name == layoutConfig.theme && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "pi pi-check text-white"
                                    })
                                })
                            }, i);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Scale"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex align-items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-minus",
                                type: "button",
                                onClick: decrementScale,
                                className: "w-2rem h-2rem mr-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[0]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex gap-2 align-items-center",
                                children: scales.map((s, i)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: (0,primereact_utils__WEBPACK_IMPORTED_MODULE_6__.classNames)("pi pi-circle-fill text-300", {
                                            "text-primary-500": s === layoutConfig.scale
                                        })
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-plus",
                                type: "button",
                                onClick: incrementScale,
                                className: "w-2rem h-2rem ml-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[scales.length - 1]
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Type"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap row-gap-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "static",
                                                checked: layoutConfig.menuMode === "static",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode1",
                                                children: "Static"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "overlay",
                                                checked: layoutConfig.menuMode === "overlay",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode2",
                                                children: "Overlay"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim",
                                                checked: layoutConfig.menuMode === "slim",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode3"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode3",
                                                children: "Slim"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim-plus",
                                                checked: layoutConfig.menuMode === "slim-plus",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode4"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode4",
                                                children: "Slim +"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "drawer",
                                                checked: layoutConfig.menuMode === "drawer",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode7"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode7",
                                                children: "Drawer"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "reveal",
                                                checked: layoutConfig.menuMode === "reveal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode6",
                                                children: "Reveal"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "horizontal",
                                                checked: layoutConfig.menuMode === "horizontal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode5",
                                                children: "Horizontal"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Theme"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "colorScheme",
                                        checked: layoutConfig.menuTheme === "colorScheme",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-colorscheme"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-colorscheme",
                                        children: "Color Scheme"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "primaryColor",
                                        checked: layoutConfig.menuTheme === "primaryColor",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-primarycolor"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-primarycolor",
                                        children: "Primary Color"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "transparent",
                                        checked: layoutConfig.menuTheme === "transparent",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-transparent"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-transparent",
                                        children: "Transparent"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Color Scheme"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "light",
                                checked: layoutConfig.colorScheme === "light",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-light"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-light",
                                children: "Light"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dim",
                                checked: layoutConfig.colorScheme === "dim",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dim"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dim",
                                children: "Dim"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dark",
                                checked: layoutConfig.colorScheme === "dark",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dark"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dark",
                                children: "Dark"
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Input Style"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "outlined",
                                                checked: layoutConfig.inputStyle === "outlined",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "outlined_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "outlined_input",
                                                children: "Outlined"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "filled",
                                                checked: layoutConfig.inputStyle === "filled",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "filled_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "filled_input",
                                                children: "Filled"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Ripple Effect"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__/* .InputSwitch */ .Q, {
                                checked: layoutConfig.ripple,
                                onChange: changeRipple
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppConfig);


/***/ }),

/***/ 6538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ LayoutContext),
/* harmony export */   a: () => (/* binding */ LayoutProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(51824);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ LayoutContext,LayoutProvider auto */ 


const LayoutContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default().createContext({});
const LayoutProvider = (props)=>{
    const [breadcrumbs, setBreadcrumbs] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [layoutConfig, setLayoutConfig] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        ripple: false,
        inputStyle: "outlined",
        menuMode: "static",
        menuTheme: "colorScheme",
        colorScheme: "light",
        theme: "indigo",
        scale: 14
    });
    const [layoutState, setLayoutState] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        staticMenuDesktopInactive: false,
        overlayMenuActive: false,
        overlaySubmenuActive: false,
        profileSidebarVisible: false,
        configSidebarVisible: false,
        staticMenuMobileActive: false,
        menuHoverActive: false,
        resetMenu: false,
        sidebarActive: false,
        anchored: false
    });
    const onMenuToggle = ()=>{
        if (isOverlay()) {
            setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    overlayMenuActive: !prevLayoutState.overlayMenuActive
                }));
        }
        if (isDesktop()) {
            setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    staticMenuDesktopInactive: !prevLayoutState.staticMenuDesktopInactive
                }));
        } else {
            setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    staticMenuMobileActive: !prevLayoutState.staticMenuMobileActive
                }));
        }
    };
    const showConfigSidebar = ()=>{
        setLayoutState((prevLayoutState)=>({
                ...prevLayoutState,
                configSidebarVisible: true
            }));
    };
    const showProfileSidebar = ()=>{
        setLayoutState((prevLayoutState)=>({
                ...prevLayoutState,
                profileSidebarVisible: !prevLayoutState.profileSidebarVisible
            }));
    };
    const isOverlay = ()=>{
        return layoutConfig.menuMode === "overlay";
    };
    const isSlim = ()=>{
        return layoutConfig.menuMode === "slim";
    };
    const isSlimPlus = ()=>{
        return layoutConfig.menuMode === "slim-plus";
    };
    const isHorizontal = ()=>{
        return layoutConfig.menuMode === "horizontal";
    };
    const isDesktop = ()=>{
        return window.innerWidth > 991;
    };
    const value = {
        layoutConfig,
        setLayoutConfig,
        layoutState,
        setLayoutState,
        onMenuToggle,
        showConfigSidebar,
        showProfileSidebar,
        isSlim,
        isSlimPlus,
        isHorizontal,
        isDesktop,
        breadcrumbs,
        setBreadcrumbs
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LayoutContext.Provider, {
        value: value,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                            children: "SOGEC"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            charSet: "UTF-8"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: "description",
                            content: "The ultimate collection of design-agnostic, flexible and accessible React UI Components."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: "robots",
                            content: "index, follow"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: "viewport",
                            content: "initial-scale=1, width=device-width"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:type",
                            content: "website"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:title",
                            content: "Apollo by PrimeReact for Next.js"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:url",
                            content: "https://www.primefaces.org/apollo-react"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:description",
                            content: "The ultimate collection of design-agnostic, flexible and accessible React UI Components."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:image",
                            content: "https://www.primefaces.org/static/social/apollo-react.png"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:ttl",
                            content: "604800"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "icon",
                            href: `/favicon.ico`,
                            type: "image/x-icon"
                        })
                    ]
                }),
                props.children
            ]
        })
    });
};


/***/ }),

/***/ 31130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (/* binding */ Utils),
/* harmony export */   e: () => (/* binding */ UIUtils)
/* harmony export */ });
/* harmony import */ var date_fns_format__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4230);

const showError = ({ error, summary, detail, toast, severity, sticky })=>{
    summary = summary || "Error";
    severity = severity || "error";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    if (error) {
        toast.show({
            severity,
            summary,
            detail: error,
            sticky,
            life
        });
        return;
    }
    return;
};
const showInfo = ({ summary, detail, toast, sticky })=>{
    let severity = "info";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    summary = summary || "Information";
    if (toast) {
        toast.show({
            severity,
            summary,
            detail,
            life,
            sticky
        });
    }
};
const showWarning = ({ summary, detail, toast, sticky })=>{
    let severity = "warn";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    summary = summary || "Warning";
    if (toast) {
        toast.show({
            severity,
            summary,
            detail,
            life,
            sticky
        });
    }
};
const getUnixTimeMilliseconds = ()=>new Date().getTime();
const getUnixTimeMillisecondsGMT7 = ()=>{
    const currentTime = new Date().getTime();
    const offset = 7 * 3600000; // 7 hours * 3600 seconds/hour * 1000 milliseconds/second
    const timeInGMT7 = currentTime + offset;
    return timeInGMT7;
};
const formatUnixTimeToString = (unixTime, fmt)=>{
    const date = new Date(unixTime);
    if (fmt) {
        return (0,date_fns_format__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)(date, fmt);
    }
    fmt = "dd-MM-yyyy HH:mm:ss";
    return (0,date_fns_format__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)(date, fmt);
};
const formatDurationWithWords = (duration)=>{
    let seconds = Math.floor(duration / 1000 % 60);
    let minutes = Math.floor(duration / (1000 * 60) % 60);
    let hours = Math.floor(duration / (1000 * 60 * 60));
    const hoursText = hours > 0 ? `${hours} hours` : "";
    const minutesText = minutes > 0 ? `${minutes} minutes` : "";
    const secondsText = seconds > 0 ? `${seconds} seconds` : "";
    return [
        hoursText,
        minutesText,
        secondsText
    ].filter(Boolean).join(", ");
};
const calculateDurationFromUnixWithWords = (startTime, endTime)=>{
    const start = new Date(startTime);
    const end = new Date(endTime);
    const duration = end - start; // Khoảng thời gian tính bằng miligiây
    return formatDurationWithWords(duration);
};
const UIUtils = {
    showError,
    showInfo,
    showWarning
};
const Utils = {
    formatUnixTimeToString,
    getUnixTimeMilliseconds,
    getUnixTimeMillisecondsGMT7,
    calculateDurationFromUnixWithWords
};



/***/ }),

/***/ 14851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34834);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const NotFound = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                viewBox: "0 0 960 540",
                xmlns: "http://www.w3.org/2000/svg",
                xmlnsXlink: "http://www.w3.org/1999/xlink",
                version: "1.1",
                className: "min-h-screen min-w-screen fixed left-0",
                style: {
                    bottom: "-10rem"
                },
                preserveAspectRatio: "none",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        x: "0",
                        y: "0",
                        width: "960",
                        height: "540",
                        fill: "var(--surface-ground)"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M0 331L26.7 321C53.3 311 106.7 291 160 291C213.3 291 266.7 311 320 329.5C373.3 348 426.7 365 480 373.2C533.3 381.3 586.7 380.7 640 373.8C693.3 367 746.7 354 800 341.2C853.3 328.3 906.7 315.7 933.3 309.3L960 303L960 541L933.3 541C906.7 541 853.3 541 800 541C746.7 541 693.3 541 640 541C586.7 541 533.3 541 480 541C426.7 541 373.3 541 320 541C266.7 541 213.3 541 160 541C106.7 541 53.3 541 26.7 541L0 541Z",
                        fill: "var(--orange-500)",
                        strokeLinecap: "round",
                        strokeLinejoin: "miter"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-5 min-h-screen flex justify-content-center align-items-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "z-1 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-900 font-bold text-8xl mb-4",
                            children: "Oops!"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "line-height-3 mt-0 mb-5 text-700 text-xl font-medium",
                            children: "There is nothing here"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "p-button p-button-warning font-medium p-button-raised",
                                children: "Go to Dashboard"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotFound);


/***/ }),

/***/ 20504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\devices\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 60729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 49986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _full_page_pages_notfound_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14851);


const Custom404 = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_full_page_pages_notfound_page__WEBPACK_IMPORTED_MODULE_1__["default"], {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Custom404);


/***/ }),

/***/ 83174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 63114:
/***/ (() => {



/***/ }),

/***/ 97993:
/***/ (() => {



/***/ }),

/***/ 80400:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
'use client';
'use strict';

__webpack_unused_export__ = ({ value: true });

var React = __webpack_require__(18038);
var api = __webpack_require__(90284);
var componentbase = __webpack_require__(87095);
var csstransition = __webpack_require__(51267);
var hooks = __webpack_require__(85215);
var minus = __webpack_require__(81620);
var plus = __webpack_require__(1501);
var ripple = __webpack_require__(26412);
var utils = __webpack_require__(7666);

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  }
  n["default"] = e;
  return Object.freeze(n);
}

var React__namespace = /*#__PURE__*/_interopNamespace(React);

function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = !0,
      o = !1;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = !0, n = r;
    } finally {
      try {
        if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
  return arr2;
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

var PanelBase = componentbase.ComponentBase.extend({
  defaultProps: {
    __TYPE: 'Panel',
    id: null,
    header: null,
    headerTemplate: null,
    footer: null,
    footerTemplate: null,
    toggleable: null,
    style: null,
    className: null,
    collapsed: null,
    expandIcon: null,
    collapseIcon: null,
    icons: null,
    transitionOptions: null,
    onExpand: null,
    onCollapse: null,
    onToggle: null,
    children: undefined
  },
  css: {
    classes: {
      root: function root(_ref) {
        var props = _ref.props;
        return utils.classNames('p-panel p-component', {
          'p-panel-toggleable': props.toggleable
        });
      },
      header: 'p-panel-header',
      title: 'p-panel-title',
      icons: 'p-panel-icons',
      toggler: 'p-panel-header-icon p-panel-toggler p-link',
      togglerIcon: 'p-panel-header-icon p-panel-toggler p-link',
      toggleableContent: 'p-toggleable-content',
      content: 'p-panel-content',
      footer: 'p-panel-footer',
      transition: 'p-toggleable-content'
    },
    styles: "\n        @layer primereact {\n            .p-panel-header {\n              display: flex;\n              justify-content: space-between;\n              align-items: center;\n            }\n            \n            .p-panel-title {\n              line-height: 1;\n            }\n            \n            .p-panel-header-icon {\n              display: inline-flex;\n              justify-content: center;\n              align-items: center;\n              cursor: pointer;\n              text-decoration: none;\n              overflow: hidden;\n              position: relative;\n            }\n        }\n        "
  }
});

var Panel = /*#__PURE__*/React__namespace.forwardRef(function (inProps, ref) {
  var context = React__namespace.useContext(api.PrimeReactContext);
  var props = PanelBase.getProps(inProps, context);
  var _React$useState = React__namespace.useState(props.id),
    _React$useState2 = _slicedToArray(_React$useState, 2),
    idState = _React$useState2[0],
    setIdState = _React$useState2[1];
  var _React$useState3 = React__namespace.useState(props.collapsed),
    _React$useState4 = _slicedToArray(_React$useState3, 2),
    collapsedState = _React$useState4[0],
    setCollapsedState = _React$useState4[1];
  var elementRef = React__namespace.useRef(null);
  var contentRef = React__namespace.useRef(null);
  var collapsed = props.toggleable ? props.onToggle ? props.collapsed : collapsedState : false;
  var headerId = idState + '_header';
  var contentId = idState + '_content';
  var _PanelBase$setMetaDat = PanelBase.setMetaData({
      props: props,
      state: {
        id: idState,
        collapsed: collapsed
      }
    }),
    ptm = _PanelBase$setMetaDat.ptm,
    cx = _PanelBase$setMetaDat.cx,
    isUnstyled = _PanelBase$setMetaDat.isUnstyled;
  componentbase.useHandleStyle(PanelBase.css.styles, isUnstyled, {
    name: 'panel'
  });
  var toggle = function toggle(event) {
    if (!props.toggleable) {
      return;
    }
    collapsed ? expand(event) : collapse(event);
    if (event) {
      if (props.onToggle) {
        props.onToggle({
          originalEvent: event,
          value: !collapsed
        });
      }
      event.preventDefault();
    }
  };
  var expand = function expand(event) {
    if (!props.onToggle) {
      setCollapsedState(false);
    }
    props.onExpand && event && props.onExpand(event);
  };
  var collapse = function collapse(event) {
    if (!props.onToggle) {
      setCollapsedState(true);
    }
    props.onCollapse && event && props.onCollapse(event);
  };
  React__namespace.useImperativeHandle(ref, function () {
    return {
      props: props,
      toggle: toggle,
      expand: expand,
      collapse: collapse,
      getElement: function getElement() {
        return elementRef.current;
      },
      getContent: function getContent() {
        return contentRef.current;
      }
    };
  });
  hooks.useMountEffect(function () {
    if (!idState) {
      setIdState(utils.UniqueComponentId());
    }
  });
  var createToggleIcon = function createToggleIcon() {
    if (props.toggleable) {
      var buttonId = idState + '_label';
      var togglerProps = utils.mergeProps({
        className: cx('toggler'),
        onClick: toggle,
        id: buttonId,
        'aria-controls': contentId,
        'aria-expanded': !collapsed,
        role: 'tab'
      }, ptm('toggler'));
      var togglerIconProps = utils.mergeProps(ptm('togglericon'));
      var icon = collapsed ? props.expandIcon || /*#__PURE__*/React__namespace.createElement(plus.PlusIcon, togglerIconProps) : props.collapseIcon || /*#__PURE__*/React__namespace.createElement(minus.MinusIcon, togglerIconProps);
      var toggleIcon = utils.IconUtils.getJSXIcon(icon, togglerIconProps, {
        props: props,
        collapsed: collapsed
      });
      return /*#__PURE__*/React__namespace.createElement("button", togglerProps, toggleIcon, /*#__PURE__*/React__namespace.createElement(ripple.Ripple, null));
    }
    return null;
  };
  var createHeader = function createHeader() {
    var header = utils.ObjectUtils.getJSXElement(props.header, props);
    var icons = utils.ObjectUtils.getJSXElement(props.icons, props);
    var togglerElement = createToggleIcon();
    var titleProps = utils.mergeProps({
      id: headerId,
      className: cx('title')
    }, ptm('title'));
    var titleElement = /*#__PURE__*/React__namespace.createElement("span", titleProps, header);
    var iconsProps = utils.mergeProps({
      className: cx('icons')
    }, ptm('icons'));
    var iconsElement = /*#__PURE__*/React__namespace.createElement("div", iconsProps, icons, togglerElement);
    var headerProps = utils.mergeProps({
      className: cx('header')
    }, ptm('header'));
    var content = /*#__PURE__*/React__namespace.createElement("div", headerProps, titleElement, iconsElement);
    if (props.headerTemplate) {
      var defaultContentOptions = {
        className: 'p-panel-header',
        titleClassName: 'p-panel-title',
        iconsClassName: 'p-panel-icons',
        togglerClassName: 'p-panel-header-icon p-panel-toggler p-link',
        onTogglerClick: toggle,
        titleElement: titleElement,
        iconsElement: iconsElement,
        togglerElement: togglerElement,
        element: content,
        props: props,
        collapsed: collapsed
      };
      return utils.ObjectUtils.getJSXElement(props.headerTemplate, defaultContentOptions);
    } else if (props.header || props.toggleable) {
      return content;
    }
    return null;
  };
  var createContent = function createContent() {
    var toggleableContentProps = utils.mergeProps({
      ref: contentRef,
      className: cx('toggleableContent'),
      'aria-hidden': collapsed,
      role: 'region',
      id: contentId,
      'aria-labelledby': headerId
    }, ptm('toggleablecontent'));
    var contentProps = utils.mergeProps({
      className: cx('content')
    }, ptm('content'));
    var transitionProps = utils.mergeProps({
      classNames: cx('transition'),
      timeout: {
        enter: 1000,
        exit: 450
      },
      "in": !collapsed,
      unmountOnExit: true,
      options: props.transitionOptions
    }, ptm('transition'));
    return /*#__PURE__*/React__namespace.createElement(csstransition.CSSTransition, _extends({
      nodeRef: contentRef
    }, transitionProps), /*#__PURE__*/React__namespace.createElement("div", toggleableContentProps, /*#__PURE__*/React__namespace.createElement("div", contentProps, props.children)));
  };
  var createFooter = function createFooter() {
    var footer = utils.ObjectUtils.getJSXElement(props.footer, props);
    var footerProps = utils.mergeProps({
      className: cx('footer')
    }, ptm('footer'));
    var content = /*#__PURE__*/React__namespace.createElement("div", footerProps, footer);
    if (props.footerTemplate) {
      var defaultContentOptions = {
        className: cx('footer'),
        element: content,
        props: props
      };
      return utils.ObjectUtils.getJSXElement(props.footerTemplate, defaultContentOptions);
    } else if (props.footer) {
      return content;
    }
    return null;
  };
  var rootProps = utils.mergeProps({
    id: idState,
    ref: elementRef,
    style: props.style,
    className: utils.classNames(props.className, cx('root'))
  }, PanelBase.getOtherProps(props), ptm('root'));
  var header = createHeader();
  var content = createContent();
  var footer = createFooter();
  return /*#__PURE__*/React__namespace.createElement("div", rootProps, header, content, footer);
});
Panel.displayName = 'Panel';

exports.s = Panel;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,7933,1042,6903,4719,4524,5129,1501,6408,1003,1993,1459,4760,6120,590,4230,37,1184,2558,1620,4972], () => (__webpack_exec__(99261)));
module.exports = __webpack_exports__;

})();