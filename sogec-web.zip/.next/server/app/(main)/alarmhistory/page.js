(() => {
var exports = {};
exports.id = 5092;
exports.ids = [5092,6065,2547,1130];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 88887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'alarmhistory',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 30237)), "D:\\sogec\\sogec-web\\app\\(main)\\alarmhistory\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\alarmhistory\\page.tsx"];
    
    const originalPathname = "/(main)/alarmhistory/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 12003:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 84826))

/***/ }),

/***/ 96032:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 81611))

/***/ }),

/***/ 15906:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 61522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 97844, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 86249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 13100, 23))

/***/ }),

/***/ 76670:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 27977, 23))

/***/ }),

/***/ 8639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   P: () => (/* binding */ getDevices)
/* harmony export */ });
/* harmony import */ var _http_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49213);

const getDevices = (reqParams)=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.get("/tenant/deviceInfos", {
        params: {
            ...reqParams
        }
    });
};


/***/ }),

/***/ 84826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/primereact/datatable/datatable.cjs.js
var datatable_cjs = __webpack_require__(14760);
// EXTERNAL MODULE: ./node_modules/primereact/toast/toast.cjs.js
var toast_cjs = __webpack_require__(11459);
// EXTERNAL MODULE: ./node_modules/primereact/confirmdialog/confirmdialog.cjs.js
var confirmdialog_cjs = __webpack_require__(82558);
// EXTERNAL MODULE: ./node_modules/primereact/column/column.cjs.js
var column_cjs = __webpack_require__(59210);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./api/http.api.ts
var http_api = __webpack_require__(49213);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 48 modules
var axios = __webpack_require__(53071);
// EXTERNAL MODULE: ./service/localStorage.ts
var localStorage = __webpack_require__(40365);
;// CONCATENATED MODULE: ./api/http.api.v2.ts


const http_api_v2_httpApi = axios/* default */.Z.create({
    baseURL: "http://ewon-vpn.ddns.net:8200/api/v2",
    headers: {
        "Content-Type": "application/json"
    },
    timeout: 30000
});
http_api_v2_httpApi.interceptors.request.use((config)=>{
    const token = (0,localStorage/* readToken */.YG)();
    if (token) {
        config.headers["X-Authorization"] = `Bearer ${token}`;
    }
    return config;
}, (error)=>{
    return Promise.reject(error);
}); // httpApi.interceptors.response.use(
 //     (response) => {
 //         // If the response is successful, just return it
 //         return response;
 //     },
 //     async (error) => {
 //         const originalRequest = error.config;
 //         const router = useRouter();
 //         // Check if the error is due to a token expiration and we haven't already retried
 //         if (error.response.status === 401 && !originalRequest._retry) {
 //             originalRequest._retry = true; // Mark it so we don't try to refresh the token again
 //             const refreshToken: string | null = readRefreshToken();
 //             if (refreshToken) {
 //                 try {
 //                     const res = await refreshTokenFun({
 //                         refreshToken,
 //                     });
 //                     if (res) {
 //                         persistToken(res.token);
 //                         persistRefreshToken(res.refreshToken);
 //                         originalRequest.headers[
 //                             "X-Authorization"
 //                         ] = `Bearer ${res.token}`;
 //                     }
 //                     // Update the header of the original request
 //                     // Retry the request with the new token
 //                     return httpApi(originalRequest);
 //                 } catch (refreshError) {
 //                     console.log(refreshError);
 //                     //deleteToken();
 //                     return Promise.reject(refreshError); // If token refresh fails, reject the promise
 //                 }
 //             } else {
 //                 return Promise.reject(error);
 //             }
 //         }
 //         // If the error is not due to token expiration or another request, just return it
 //         return Promise.reject(error);
 //     }
 // );

;// CONCATENATED MODULE: ./api/alarm.api.ts


const getAllAlarms = (reqParams)=>{
    return httpApi.get("/alarms", {
        params: {
            ...reqParams
        }
    });
};
const getAlarms = (entityType, entityId, reqParams)=>{
    return http_api_v2_httpApi.get(`/alarm/${entityType}/${entityId}`, {
        params: {
            ...reqParams
        }
    });
};
const getAlarmTypes = (reqParams)=>{
    return http_api/* httpApi */.Y.get("/alarm/types", {
        params: {
            ...reqParams
        }
    });
};

// EXTERNAL MODULE: ./service/Utils.ts
var Utils = __webpack_require__(31130);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
;// CONCATENATED MODULE: ./app/(main)/alarmhistory/components/AlarmList.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AlarmList = ({ filters })=>{
    const toast = (0,react_.useRef)(null);
    const [lazyState, setlazyState] = (0,react_.useState)({
        first: 0,
        rows: 10,
        page: 0,
        sortField: null,
        sortOrder: null,
        filters: {}
    });
    const [totalElements, setTotalElements] = (0,react_.useState)(0);
    const [alarms, setAlarms] = (0,react_.useState)([]);
    const [textSearch, setTextSearch] = (0,react_.useState)("");
    const _onInvsPaging = (event)=>{
        setlazyState(event);
    };
    const _fetchDataAlarms = (0,react_.useCallback)(({ pageSize, page, sortOrder, textSearch }, filters)=>{
        if (filters && filters.device && filters.device.id) {
            let device = filters.device;
            let reqParams = {};
            reqParams = {
                ...reqParams,
                pageSize,
                page,
                sortOrder: "DESC",
                sortProperty: "createdTime"
            };
            let dates = filters.dates ? [
                ...filters.dates
            ] : [];
            if (dates && dates[0] && dates[1]) {
                reqParams = {
                    ...reqParams,
                    startTime: dates[0].getTime(),
                    endTime: dates[1].getTime()
                };
            }
            if (textSearch !== "") {
                reqParams = {
                    ...reqParams,
                    textSearch
                };
            }
            let alarmType = filters?.alarmType;
            if (alarmType && alarmType.type) {
                reqParams = {
                    ...reqParams,
                    typeList: alarmType.type
                };
            }
            console.log(filters);
            getAlarms(device.id.entityType, device.id.id, reqParams).then((resp)=>resp.data).then((res)=>{
                console.log(res);
                setAlarms([
                    ...res.data
                ]);
                setTotalElements(res.totalElements);
            }).catch((err)=>{
                Utils/* UIUtils */.e.showError({
                    error: err?.message,
                    toast: toast.current
                });
            });
        } else {}
    }, []);
    (0,react_.useEffect)(()=>{
        _fetchDataAlarms({
            pageSize: lazyState.rows,
            page: lazyState.page,
            textSearch
        }, filters);
    }, [
        lazyState,
        _fetchDataAlarms,
        filters,
        textSearch
    ]);
    const _renderCreatedTime = (row)=>{
        let createdTime = row.createdTime;
        return createdTime ? Utils/* Utils */.c.formatUnixTimeToString(createdTime) : "";
    };
    const _renderStartTime = (row)=>{
        let startTs = row.startTs;
        return startTs ? Utils/* Utils */.c.formatUnixTimeToString(startTs) : "";
    };
    const _renderValue = (row)=>{
        let { details } = row;
        let value = details?.data?.split(",")[1];
        return value ? value : "";
    };
    const _renderDurationTime = (row)=>{
        let { startTs, endTs } = row;
        return startTs && endTs ? Utils/* Utils */.c.calculateDurationFromUnixWithWords(startTs, endTs) : "";
    };
    const handleInputChange = (e)=>{
        const value = e.target.value;
        setTextSearch(value);
    };
    const renderHeader = ()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex flex-wrap gap-2 align-items-center justify-content-between",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                className: "p-input-icon-left w-full sm:w-20rem flex-order-1 sm:flex-order-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "pi pi-search"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                        placeholder: "Search Alarms",
                        value: textSearch,
                        onChange: handleInputChange,
                        className: "w-full"
                    })
                ]
            })
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(toast_cjs/* Toast */.F, {
                    ref: toast
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(confirmdialog_cjs/* ConfirmDialog */.QH, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(datatable_cjs/* DataTable */.w, {
                        rows: lazyState.rows,
                        rowsPerPageOptions: [
                            5,
                            10,
                            25,
                            50
                        ],
                        header: renderHeader,
                        value: alarms,
                        paginator: true,
                        lazy: true,
                        className: "datatable-responsive",
                        emptyMessage: "No products found.",
                        paginatorTemplate: "CurrentPageReport RowsPerPageDropdown FirstPageLink PrevPageLink PageLinks  NextPageLink LastPageLink",
                        currentPageReportTemplate: "Showing {first} to {last} of {totalRecords}",
                        totalRecords: totalElements,
                        first: lazyState.first,
                        dataKey: "id",
                        onPage: _onInvsPaging,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                sortable: true,
                                header: "Created Time",
                                body: _renderCreatedTime
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                field: "originatorName",
                                header: "Originator"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                field: "type",
                                header: "Type"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                header: "Start Time",
                                body: _renderStartTime
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                header: "Duration",
                                body: _renderDurationTime
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                header: "Value",
                                body: _renderValue
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                                field: "description",
                                header: "Description"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_AlarmList = (AlarmList);

// EXTERNAL MODULE: ./node_modules/primereact/autocomplete/autocomplete.cjs.js
var autocomplete_cjs = __webpack_require__(37);
// EXTERNAL MODULE: ./api/device.api.ts
var device_api = __webpack_require__(8639);
// EXTERNAL MODULE: ./node_modules/primereact/calendar/calendar.cjs.js
var calendar_cjs = __webpack_require__(52186);
;// CONCATENATED MODULE: ./app/(main)/alarmhistory/components/FilterAlarm.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const defFilter = {
    device: null,
    dates: null,
    alarmType: null
};
const FilterAlarm = ({ showDevice, onAction, showAlarmType })=>{
    const [editFilter, setEditFilter] = (0,react_.useState)([]);
    const [suggDevices, setSuggDevices] = (0,react_.useState)([]);
    const [suggAlarmType, setSuggAlarmType] = (0,react_.useState)([]);
    (0,react_.useEffect)(()=>{
        let newFilter = {
            ...defFilter
        };
        setEditFilter(editFilter);
    }, []);
    const _onSuggDevices = (evt)=>{
        (0,device_api/* getDevices */.P)({
            page: 0,
            pageSize: 50,
            textSearch: evt.query
        }).then((resp)=>resp.data).then((res)=>{
            res.data.forEach((it)=>{
                it.label = `${it.name}`;
            });
            setSuggDevices([
                ...res.data
            ]);
        }).catch((err)=>{
            setSuggDevices([]);
        });
    };
    const _processFilterChange = (field, value)=>{
        let newFil = {
            ...editFilter
        };
        newFil[field] = value;
        setEditFilter(newFil);
        onAction(newFil);
    };
    const _onSuggAlarmType = (evt)=>{
        getAlarmTypes({
            page: 0,
            pageSize: 50,
            textSearch: evt.query
        }).then((resp)=>resp.data).then((resp)=>{
            setSuggAlarmType([
                ...resp.data
            ]);
        }).catch((err)=>{
            setSuggAlarmType([]);
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "grid p-fluid",
            children: [
                showDevice && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-12 lg:col-3",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "p-float-label",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(autocomplete_cjs/* AutoComplete */.Q, {
                                dropdown: true,
                                suggestions: suggDevices,
                                field: "label",
                                value: editFilter.device,
                                completeMethod: _onSuggDevices,
                                onChange: (e)=>_processFilterChange("device", e.value)
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                children: "Device"
                            })
                        ]
                    })
                }),
                showDevice && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-12 lg:col-3",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "p-float-label",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(calendar_cjs/* Calendar */.f, {
                                value: editFilter.dates,
                                selectionMode: "range",
                                onChange: (e)=>{
                                    _processFilterChange("dates", e.value);
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                children: "Select Date"
                            })
                        ]
                    })
                }),
                showAlarmType && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "col-12 lg:col-3",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "p-float-label",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(autocomplete_cjs/* AutoComplete */.Q, {
                                dropdown: true,
                                field: "type",
                                value: editFilter.alarmType,
                                onChange: (e)=>{
                                    _processFilterChange("alarmType", e.value);
                                },
                                suggestions: suggAlarmType,
                                completeMethod: _onSuggAlarmType
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                children: "Alarm type"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_FilterAlarm = (FilterAlarm);

;// CONCATENATED MODULE: ./app/(main)/alarmhistory/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const Alarm = ()=>{
    const [filters, setFilters] = (0,react_.useState)({});
    const _onFilterChange = (evt)=>{
        setFilters(evt);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(components_FilterAlarm, {
                    onAction: _onFilterChange,
                    showDevice: true,
                    showDate: true,
                    showAlarmType: true
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_AlarmList, {
                filters: filters
            })
        ]
    });
};
/* harmony default export */ const page = (Alarm);


/***/ }),

/***/ 81611:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _layout_context_layoutcontext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6538);
/* harmony import */ var primeflex_primeflex_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(63468);
/* harmony import */ var primeflex_primeflex_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(primeflex_primeflex_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var primeicons_primeicons_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51091);
/* harmony import */ var primeicons_primeicons_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(primeicons_primeicons_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(90284);
/* harmony import */ var primereact_resources_primereact_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(84732);
/* harmony import */ var primereact_resources_primereact_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(primereact_resources_primereact_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _styles_demo_Demos_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(63114);
/* harmony import */ var _styles_demo_Demos_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_demo_Demos_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_layout_layout_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(97993);
/* harmony import */ var _styles_layout_layout_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_layout_layout_scss__WEBPACK_IMPORTED_MODULE_6__);
/* __next_internal_client_entry_do_not_use__ default auto */ 







function RootLayout({ children }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("html", {
        lang: "en",
        suppressHydrationWarning: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("head", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                    id: "theme-link",
                    href: `/theme/theme-light/indigo/theme.css`,
                    rel: "stylesheet"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_api__WEBPACK_IMPORTED_MODULE_7__.PrimeReactProvider, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layout_context_layoutcontext__WEBPACK_IMPORTED_MODULE_1__/* .LayoutProvider */ .a, {
                        children: children
                    })
                })
            })
        ]
    });
}


/***/ }),

/***/ 92547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90284);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18176);
/* harmony import */ var primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63579);
/* harmony import */ var primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23064);
/* harmony import */ var primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63862);
/* harmony import */ var primereact_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7666);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6538);
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AppConfig = (props)=>{
    const { layoutConfig, setLayoutConfig, layoutState, setLayoutState, isSlim, isSlimPlus, isHorizontal } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__/* .LayoutContext */ .V);
    const { changeTheme } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(primereact_api__WEBPACK_IMPORTED_MODULE_3__.PrimeReactContext);
    const scales = [
        12,
        13,
        14,
        15,
        16
    ];
    const componentThemes = [
        {
            name: "indigo",
            color: "#6366F1"
        },
        {
            name: "blue",
            color: "#3B82F6"
        },
        {
            name: "purple",
            color: "#8B5CF6"
        },
        {
            name: "teal",
            color: "#14B8A6"
        },
        {
            name: "cyan",
            color: "#06b6d4"
        },
        {
            name: "green",
            color: "#10b981"
        },
        {
            name: "orange",
            color: "#f59e0b"
        },
        {
            name: "pink",
            color: "#d946ef"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isSlim() || isSlimPlus() || isHorizontal()) {
            setLayoutState((prevState)=>({
                    ...prevState,
                    resetMenu: true
                }));
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.menuMode
    ]);
    const onConfigButtonClick = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: true
            }));
    };
    const onConfigSidebarHide = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: false
            }));
    };
    const changeInputStyle = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                inputStyle: e.value
            }));
    };
    const changeRipple = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                ripple: e.value
            }));
    };
    const changeMenuMode = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuMode: e.value
            }));
    };
    const changeMenuTheme = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuTheme: e.value
            }));
    };
    const changeColorScheme = (colorScheme)=>{
        changeTheme?.(layoutConfig.colorScheme, colorScheme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    colorScheme
                }));
        });
    };
    const _changeTheme = (theme)=>{
        changeTheme?.(layoutConfig.theme, theme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    theme
                }));
        });
    };
    const decrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale - 1
            }));
    };
    const incrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale + 1
            }));
    };
    const applyScale = ()=>{
        document.documentElement.style.fontSize = layoutConfig.scale + "px";
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        applyScale();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.scale
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "layout-config-button config-link",
                type: "button",
                onClick: onConfigButtonClick,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "pi pi-cog"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__/* .Sidebar */ .Y, {
                visible: layoutState.configSidebarVisible,
                onHide: onConfigSidebarHide,
                position: "right",
                className: "layout-config-sidebar w-18rem",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Themes"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap row-gap-3",
                        children: componentThemes.map((theme, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    className: "cursor-pointer p-link w-2rem h-2rem border-circle flex-shrink-0 flex align-items-center justify-content-center",
                                    onClick: ()=>_changeTheme(theme.name),
                                    style: {
                                        backgroundColor: theme.color
                                    },
                                    children: theme.name == layoutConfig.theme && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "pi pi-check text-white"
                                    })
                                })
                            }, i);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Scale"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex align-items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-minus",
                                type: "button",
                                onClick: decrementScale,
                                className: "w-2rem h-2rem mr-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[0]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex gap-2 align-items-center",
                                children: scales.map((s, i)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: (0,primereact_utils__WEBPACK_IMPORTED_MODULE_6__.classNames)("pi pi-circle-fill text-300", {
                                            "text-primary-500": s === layoutConfig.scale
                                        })
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-plus",
                                type: "button",
                                onClick: incrementScale,
                                className: "w-2rem h-2rem ml-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[scales.length - 1]
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Type"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap row-gap-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "static",
                                                checked: layoutConfig.menuMode === "static",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode1",
                                                children: "Static"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "overlay",
                                                checked: layoutConfig.menuMode === "overlay",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode2",
                                                children: "Overlay"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim",
                                                checked: layoutConfig.menuMode === "slim",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode3"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode3",
                                                children: "Slim"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim-plus",
                                                checked: layoutConfig.menuMode === "slim-plus",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode4"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode4",
                                                children: "Slim +"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "drawer",
                                                checked: layoutConfig.menuMode === "drawer",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode7"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode7",
                                                children: "Drawer"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "reveal",
                                                checked: layoutConfig.menuMode === "reveal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode6",
                                                children: "Reveal"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "horizontal",
                                                checked: layoutConfig.menuMode === "horizontal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode5",
                                                children: "Horizontal"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Theme"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "colorScheme",
                                        checked: layoutConfig.menuTheme === "colorScheme",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-colorscheme"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-colorscheme",
                                        children: "Color Scheme"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "primaryColor",
                                        checked: layoutConfig.menuTheme === "primaryColor",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-primarycolor"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-primarycolor",
                                        children: "Primary Color"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "transparent",
                                        checked: layoutConfig.menuTheme === "transparent",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-transparent"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-transparent",
                                        children: "Transparent"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Color Scheme"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "light",
                                checked: layoutConfig.colorScheme === "light",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-light"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-light",
                                children: "Light"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dim",
                                checked: layoutConfig.colorScheme === "dim",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dim"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dim",
                                children: "Dim"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dark",
                                checked: layoutConfig.colorScheme === "dark",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dark"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dark",
                                children: "Dark"
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Input Style"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "outlined",
                                                checked: layoutConfig.inputStyle === "outlined",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "outlined_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "outlined_input",
                                                children: "Outlined"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "filled",
                                                checked: layoutConfig.inputStyle === "filled",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "filled_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "filled_input",
                                                children: "Filled"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Ripple Effect"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__/* .InputSwitch */ .Q, {
                                checked: layoutConfig.ripple,
                                onChange: changeRipple
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppConfig);


/***/ }),

/***/ 6538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   V: () => (/* binding */ LayoutContext),
/* harmony export */   a: () => (/* binding */ LayoutProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(51824);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ LayoutContext,LayoutProvider auto */ 


const LayoutContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default().createContext({});
const LayoutProvider = (props)=>{
    const [breadcrumbs, setBreadcrumbs] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [layoutConfig, setLayoutConfig] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        ripple: false,
        inputStyle: "outlined",
        menuMode: "static",
        menuTheme: "colorScheme",
        colorScheme: "light",
        theme: "indigo",
        scale: 14
    });
    const [layoutState, setLayoutState] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        staticMenuDesktopInactive: false,
        overlayMenuActive: false,
        overlaySubmenuActive: false,
        profileSidebarVisible: false,
        configSidebarVisible: false,
        staticMenuMobileActive: false,
        menuHoverActive: false,
        resetMenu: false,
        sidebarActive: false,
        anchored: false
    });
    const onMenuToggle = ()=>{
        if (isOverlay()) {
            setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    overlayMenuActive: !prevLayoutState.overlayMenuActive
                }));
        }
        if (isDesktop()) {
            setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    staticMenuDesktopInactive: !prevLayoutState.staticMenuDesktopInactive
                }));
        } else {
            setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    staticMenuMobileActive: !prevLayoutState.staticMenuMobileActive
                }));
        }
    };
    const showConfigSidebar = ()=>{
        setLayoutState((prevLayoutState)=>({
                ...prevLayoutState,
                configSidebarVisible: true
            }));
    };
    const showProfileSidebar = ()=>{
        setLayoutState((prevLayoutState)=>({
                ...prevLayoutState,
                profileSidebarVisible: !prevLayoutState.profileSidebarVisible
            }));
    };
    const isOverlay = ()=>{
        return layoutConfig.menuMode === "overlay";
    };
    const isSlim = ()=>{
        return layoutConfig.menuMode === "slim";
    };
    const isSlimPlus = ()=>{
        return layoutConfig.menuMode === "slim-plus";
    };
    const isHorizontal = ()=>{
        return layoutConfig.menuMode === "horizontal";
    };
    const isDesktop = ()=>{
        return window.innerWidth > 991;
    };
    const value = {
        layoutConfig,
        setLayoutConfig,
        layoutState,
        setLayoutState,
        onMenuToggle,
        showConfigSidebar,
        showProfileSidebar,
        isSlim,
        isSlimPlus,
        isHorizontal,
        isDesktop,
        breadcrumbs,
        setBreadcrumbs
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LayoutContext.Provider, {
        value: value,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                            children: "SOGEC"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            charSet: "UTF-8"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: "description",
                            content: "The ultimate collection of design-agnostic, flexible and accessible React UI Components."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: "robots",
                            content: "index, follow"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            name: "viewport",
                            content: "initial-scale=1, width=device-width"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:type",
                            content: "website"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:title",
                            content: "Apollo by PrimeReact for Next.js"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:url",
                            content: "https://www.primefaces.org/apollo-react"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:description",
                            content: "The ultimate collection of design-agnostic, flexible and accessible React UI Components."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:image",
                            content: "https://www.primefaces.org/static/social/apollo-react.png"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                            property: "og:ttl",
                            content: "604800"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "icon",
                            href: `/favicon.ico`,
                            type: "image/x-icon"
                        })
                    ]
                }),
                props.children
            ]
        })
    });
};


/***/ }),

/***/ 31130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (/* binding */ Utils),
/* harmony export */   e: () => (/* binding */ UIUtils)
/* harmony export */ });
/* harmony import */ var date_fns_format__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4230);

const showError = ({ error, summary, detail, toast, severity, sticky })=>{
    summary = summary || "Error";
    severity = severity || "error";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    if (error) {
        toast.show({
            severity,
            summary,
            detail: error,
            sticky,
            life
        });
        return;
    }
    return;
};
const showInfo = ({ summary, detail, toast, sticky })=>{
    let severity = "info";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    summary = summary || "Information";
    if (toast) {
        toast.show({
            severity,
            summary,
            detail,
            life,
            sticky
        });
    }
};
const showWarning = ({ summary, detail, toast, sticky })=>{
    let severity = "warn";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    summary = summary || "Warning";
    if (toast) {
        toast.show({
            severity,
            summary,
            detail,
            life,
            sticky
        });
    }
};
const getUnixTimeMilliseconds = ()=>new Date().getTime();
const getUnixTimeMillisecondsGMT7 = ()=>{
    const currentTime = new Date().getTime();
    const offset = 7 * 3600000; // 7 hours * 3600 seconds/hour * 1000 milliseconds/second
    const timeInGMT7 = currentTime + offset;
    return timeInGMT7;
};
const formatUnixTimeToString = (unixTime, fmt)=>{
    const date = new Date(unixTime);
    if (fmt) {
        return (0,date_fns_format__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)(date, fmt);
    }
    fmt = "dd-MM-yyyy HH:mm:ss";
    return (0,date_fns_format__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)(date, fmt);
};
const formatDurationWithWords = (duration)=>{
    let seconds = Math.floor(duration / 1000 % 60);
    let minutes = Math.floor(duration / (1000 * 60) % 60);
    let hours = Math.floor(duration / (1000 * 60 * 60));
    const hoursText = hours > 0 ? `${hours} hours` : "";
    const minutesText = minutes > 0 ? `${minutes} minutes` : "";
    const secondsText = seconds > 0 ? `${seconds} seconds` : "";
    return [
        hoursText,
        minutesText,
        secondsText
    ].filter(Boolean).join(", ");
};
const calculateDurationFromUnixWithWords = (startTime, endTime)=>{
    const start = new Date(startTime);
    const end = new Date(endTime);
    const duration = end - start; // Khoảng thời gian tính bằng miligiây
    return formatDurationWithWords(duration);
};
const UIUtils = {
    showError,
    showInfo,
    showWarning
};
const Utils = {
    formatUnixTimeToString,
    getUnixTimeMilliseconds,
    getUnixTimeMillisecondsGMT7,
    calculateDurationFromUnixWithWords
};



/***/ }),

/***/ 14851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34834);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const NotFound = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                viewBox: "0 0 960 540",
                xmlns: "http://www.w3.org/2000/svg",
                xmlnsXlink: "http://www.w3.org/1999/xlink",
                version: "1.1",
                className: "min-h-screen min-w-screen fixed left-0",
                style: {
                    bottom: "-10rem"
                },
                preserveAspectRatio: "none",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        x: "0",
                        y: "0",
                        width: "960",
                        height: "540",
                        fill: "var(--surface-ground)"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M0 331L26.7 321C53.3 311 106.7 291 160 291C213.3 291 266.7 311 320 329.5C373.3 348 426.7 365 480 373.2C533.3 381.3 586.7 380.7 640 373.8C693.3 367 746.7 354 800 341.2C853.3 328.3 906.7 315.7 933.3 309.3L960 303L960 541L933.3 541C906.7 541 853.3 541 800 541C746.7 541 693.3 541 640 541C586.7 541 533.3 541 480 541C426.7 541 373.3 541 320 541C266.7 541 213.3 541 160 541C106.7 541 53.3 541 26.7 541L0 541Z",
                        fill: "var(--orange-500)",
                        strokeLinecap: "round",
                        strokeLinejoin: "miter"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-5 min-h-screen flex justify-content-center align-items-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "z-1 text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-900 font-bold text-8xl mb-4",
                            children: "Oops!"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "line-height-3 mt-0 mb-5 text-700 text-xl font-medium",
                            children: "There is nothing here"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "p-button p-button-warning font-medium p-button-raised",
                                children: "Go to Dashboard"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotFound);


/***/ }),

/***/ 30237:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\alarmhistory\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 60729:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 49986:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _full_page_pages_notfound_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(14851);


const Custom404 = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_full_page_pages_notfound_page__WEBPACK_IMPORTED_MODULE_1__["default"], {});
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Custom404);


/***/ }),

/***/ 83174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 63114:
/***/ (() => {



/***/ }),

/***/ 97993:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,7933,1042,6903,4719,4524,5129,1501,6408,1003,1993,1459,4760,6120,590,6946,4230,2186,37,2558,4972], () => (__webpack_exec__(88887)));
module.exports = __webpack_exports__;

})();