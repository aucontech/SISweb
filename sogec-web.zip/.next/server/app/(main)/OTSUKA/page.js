(() => {
var exports = {};
exports.id = 6715;
exports.ids = [6715,2547,63];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 85173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'OTSUKA',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 98602)), "D:\\sogec\\sogec-web\\app\\(main)\\OTSUKA\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\OTSUKA\\page.tsx"];
    
    const originalPathname = "/(main)/OTSUKA/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 48596:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38078))

/***/ }),

/***/ 38078:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/primereact/tabview/tabview.cjs.js
var tabview_cjs = __webpack_require__(11184);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/primereact/datatable/datatable.cjs.js
var datatable_cjs = __webpack_require__(14760);
// EXTERNAL MODULE: ./node_modules/primereact/column/column.cjs.js
var column_cjs = __webpack_require__(59210);
// EXTERNAL MODULE: ./node_modules/date-fns/format.mjs + 34 modules
var format = __webpack_require__(4230);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
// EXTERNAL MODULE: ./service/localStorage.ts
var service_localStorage = __webpack_require__(40365);
// EXTERNAL MODULE: ./app/(main)/data-table-device/ID-DEVICE/IdDevice.tsx
var IdDevice = __webpack_require__(90063);
;// CONCATENATED MODULE: ./app/(main)/OTSUKA/telemetryOTSUKA/telemetryOTSUKA.tsx








function TelemetryOTSUKA({}) {
    const [sensorData, setSensorData] = (0,react_.useState)([]); // State để lưu trữ dữ liệu cảm biến
    const [textSearch, setTextSearch] = (0,react_.useState)("");
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        const token = (0,service_localStorage/* readToken */.YG)();
        const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
        ws.current = new WebSocket(url);
        const obj1 = {
            attrSubCmds: [],
            tsSubCmds: [
                {
                    entityType: "DEVICE",
                    entityId: IdDevice/* id_OTSUKA */.kx,
                    scope: "LATEST_TELEMETRY",
                    cmdId: 1
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                console.log("WebSocket connected");
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj1));
                });
            };
            ws.current.onclose = ()=>{
                console.log("WebSocket connection closed.");
            };
        }
        return ()=>{
            if (ws.current) {
                console.log("Cleaning up WebSocket connection.");
                ws.current.close();
            }
        };
    }, []);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (evt)=>{
                let dataReceived = JSON.parse(evt.data);
                if (dataReceived.update !== null) {
                    const keys = Object.keys(dataReceived.data);
                    const sensorDataArray = keys.map((key)=>{
                        const valueArray = dataReceived.data[key][0];
                        const timestamp = valueArray[0];
                        const value = valueArray[1];
                        return {
                            name: key,
                            value,
                            timestamp
                        };
                    });
                    setSensorData(sensorDataArray);
                }
            };
        }
    }, []);
    const handleInputChange = (e)=>{
        const value = e.target.value.toLowerCase();
        setTextSearch(value);
    };
    const filteredSensorData = sensorData.filter((sensor)=>sensor.name.toLowerCase().replace(/_/g, " ").includes(textSearch));
    const renderHeader = ()=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            style: {
                display: "flex",
                justifyContent: "space-between",
                padding: "0px 10px 10px 0px"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 25,
                            fontWeight: 500
                        },
                        children: "EWON OTSUKA"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-wrap gap-2 align-items-center justify-content-between",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "p-input-icon-left w-full sm:w-20rem flex-order-1 sm:flex-order-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "pi pi-search"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                placeholder: "Global Search",
                                value: textSearch,
                                onChange: handleInputChange,
                                className: "w-full"
                            })
                        ]
                    })
                })
            ]
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(datatable_cjs/* DataTable */.w, {
            header: renderHeader,
            value: filteredSensorData,
            rows: 1,
            className: "datatable-responsive",
            emptyMessage: "No products found.",
            responsiveLayout: "scroll",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                    field: "timestamp",
                    header: "Last Update",
                    headerClassName: "white-space-nowrap w-1",
                    body: (rowData)=>(0,format/* default */.ZP)(new Date(rowData.timestamp), "dd/MM/yyyy HH:mm")
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                    field: "name",
                    header: "Name",
                    headerClassName: "white-space-nowrap w-1 h-5",
                    body: (rowData)=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: rowData.name.replace(/_/g, " ")
                        })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                    field: "value",
                    header: "Value",
                    headerClassName: "white-space-nowrap w-1 h-5",
                    body: (rowData)=>/*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: rowData.value.slice(0, 5)
                        })
                })
            ]
        })
    });
}
/* harmony default export */ const telemetryOTSUKA = (TelemetryOTSUKA);

// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/@reactflow/core/dist/esm/index.mjs + 106 modules
var esm = __webpack_require__(30322);
// EXTERNAL MODULE: ./node_modules/@reactflow/background/dist/esm/index.mjs
var dist_esm = __webpack_require__(61460);
// EXTERNAL MODULE: ./node_modules/reactflow/dist/style.css
var style = __webpack_require__(46627);
;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/IconOTSUKA.tsx

const svgIcon = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    height: "20",
    width: "20",
    version: "1.1",
    id: "_x32_",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "-51.2 -51.2 614.40 614.40",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            strokeWidth: "0",
            children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                x: "-51.2",
                y: "-51.2",
                width: "614.40",
                height: "614.40",
                rx: "307.2",
                fill: "#7ed0ec"
            })
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            stroke: "#CCCCCC",
            strokeWidth: "5.12"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("style", {
                    type: "text/css",
                    children: " "
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("g", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        className: "st0",
                        d: "M472.732,243.625l-0.869-1.337l-0.929-1.296L320.925,33.194C305.854,12.379,281.598,0,255.996,0 c-25.594,0-49.85,12.379-64.87,33.125L41.066,240.992l-0.929,1.296l-0.869,1.337c-8.17,12.669-12.49,27.323-12.49,42.395 c0,16.196,4.924,31.753,14.254,44.993c18.105,25.755,49.441,38.015,80.18,31.463v63.755c0,47.294,38.476,85.769,85.769,85.769 h98.039c47.285,0,85.76-38.475,85.76-85.769v-63.755c30.689,6.586,62.059-5.666,80.215-31.497 c9.295-13.206,14.228-28.772,14.228-44.959C485.222,270.948,480.902,256.294,472.732,243.625z M421.034,295.86 c-4.013,5.708-11.084,8.401-17.866,6.808l-73.459-17.159v140.722c0,13.64-11.05,24.698-24.69,24.698H206.98 c-13.64,0-24.698-11.059-24.698-24.698V285.509l-73.442,17.159c-6.799,1.584-13.861-1.099-17.874-6.808 c-2.079-2.948-3.118-6.39-3.118-9.84c0-3.221,0.912-6.45,2.735-9.278L240.592,68.942c3.578-4.942,9.304-7.872,15.404-7.872 s11.834,2.93,15.412,7.872l150.009,207.799c1.823,2.828,2.734,6.057,2.734,9.278C424.152,289.47,423.104,292.912,421.034,295.86z"
                    })
                })
            ]
        })
    ]
});
const station = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    width: "50px",
    height: "50px",
    viewBox: "0 0 1024 1024",
    className: "icon",
    version: "1.1",
    xmlns: "http://www.w3.org/2000/svg",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M227.9 768c-22 0-39.7-9.7-51.3-28.2-15.1-24-15.5-56-14.9-70.7 0.9-23.9 6.1-47.9 13.9-64.1l26.2 12.5c-11.8 24.7-17.3 80.4-0.7 106.8 6.3 10 14.8 14.6 26.7 14.6V768z",
            fill: "#333E48"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M175.8 604.8c-4.7 9.7-8.4 22.3-10.8 35.9 6.5 4.7 15.5 8.4 27.8 10.1 1.9-13.1 5.2-25.1 9.2-33.4l-26.2-12.6z",
            fill: ""
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M227.9 537.7c-14.5 0-61.7 34.9-61.7 69.2 0 34.4 47.2 26.8 61.7 26.8v-96z",
            fill: "#00AD68"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M227.9 537.7v96.1c-6 0-17.5 1.3-28.9 0.4V553c11.5-9.3 23-15.3 28.9-15.3z",
            fill: ""
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M475 768c22 0 39.7-9.7 51.3-28.2 15.1-24 15.5-56 14.9-70.7-0.9-23.9-6.1-47.9-13.9-64.1l-26.2 12.5c11.8 24.7 17.3 80.4 0.7 106.8-6.3 10-14.8 14.6-26.7 14.6L475 768z",
            fill: "#333E48"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M527.1 604.8c4.7 9.7 8.4 22.3 10.8 35.9-6.5 4.7-15.5 8.4-27.8 10.1-1.9-13.1-5.2-25.1-9.2-33.4l26.2-12.6z",
            fill: ""
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M475 537.7c14.5 0 61.7 34.9 61.7 69.2 0 34.4-47.2 26.8-61.7 26.8v-96z",
            fill: "#FF5959"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M475 537.7v96.1c6 0 17.5 1.3 28.9 0.4V553c-11.4-9.3-22.9-15.3-28.9-15.3z",
            fill: ""
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M923.6 119.5c0-10.6-8.7-19.4-19.4-19.4H115.6c-10.6 0-19.4 8.7-19.4 19.4v170.2c0 10.6 8.7 19.4 19.4 19.4h788.7c10.6 0 19.4-8.7 19.4-19.4l-0.1-170.2z",
            fill: "#00AD68"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M484.9 881.5V515.7c0-11.8-9.7-21.5-21.5-21.5H239.6c-11.8 0-21.5 9.7-21.5 21.5v365.8h266.8z",
            fill: "#333E48"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M218.1 714.8h266.8v166.8H218.1z",
            fill: "#D1D3D3"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M269.3 805.9h31v75.6h-31zM402.7 805.9h31v75.6h-31z",
            fill: "#A4A9AD"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M271.7 557.3h159.6v57.8H271.7z",
            fill: "#FFFFFF"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M672.9 307.5h162.6v574H672.9z",
            fill: "#D1D3D3"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M672.9 307.5h162.6v60.3H672.9zM672.9 618.5h162.6v46.1H672.9z",
            fill: ""
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M872.2 881.5V662.1c0-10.6-8.7-19.4-19.4-19.4H655.4c-10.6 0-19.4 8.7-19.4 19.4v219.4h236.2z",
            fill: "#A4A9AD"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M372.1 100.2H267.7L150.5 309.1H255z",
            fill: "#FFB819"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M476.6 100.2H372.1L255 309.1h104.4z",
            fill: "#F2D383"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M218.1 673.3h133.4v92.5H218.1z",
            fill: "#00AD68"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M351.5 673.3h133.4v92.5H351.5z",
            fill: "#FF5959"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M751.3 259.4c21.2 0 38.4-17.2 38.4-38.4s-38.4-67.1-38.4-67.1-38.4 45.9-38.4 67.1c-0.1 21.2 17.1 38.4 38.4 38.4z",
            fill: "#FFB819"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M963.9 917.3c0 4.3-3.5 7.8-7.8 7.8H64.4c-4.3 0-7.8-3.5-7.8-7.8v-28c0-4.3 3.5-7.8 7.8-7.8h891.7c4.3 0 7.8 3.5 7.8 7.8v28z",
            fill: "#333E48"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M310.4 727.4h-51.2c-8 0-14.5-6.5-14.5-14.5s6.5-14.5 14.5-14.5h51.2c8 0 14.5 6.5 14.5 14.5s-6.5 14.5-14.5 14.5zM443.8 727.4h-51.2c-8 0-14.5-6.5-14.5-14.5s6.5-14.5 14.5-14.5h51.2c8 0 14.5 6.5 14.5 14.5s-6.5 14.5-14.5 14.5z",
            fill: "#FFFFFF"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M754.2 695.9m-13.5 0a13.5 13.5 0 1 0 27 0 13.5 13.5 0 1 0-27 0Z",
            fill: "#D1D3D3"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M687.4 695.9m-13.5 0a13.5 13.5 0 1 0 27 0 13.5 13.5 0 1 0-27 0Z",
            fill: "#D1D3D3"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M820.9 695.9m-13.5 0a13.5 13.5 0 1 0 27 0 13.5 13.5 0 1 0-27 0Z",
            fill: "#D1D3D3"
        })
    ]
});
const pipeSDV = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 508 508",
    width: "50px",
    height: "50px",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                    style: {
                        fill: "#324A5E"
                    },
                    cx: "254",
                    cy: "254",
                    r: "254"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "247.2",
                    y: "152.8",
                    style: {
                        fill: "#ACB3BA"
                    },
                    width: "14",
                    height: "86.4"
                }),
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFFFFF"
                            },
                            d: "M254,148c0,13.2,49.6,24,82,24c32,0,34.8-10.8,34.8-24s-2.4-24-34.8-24S254,134.8,254,148z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFFFFF"
                            },
                            d: "M254,148c0,13.2-49.6,24-82,24c-32,0-34.8-10.8-34.8-24s2.4-24,34.8-24S254,134.8,254,148z"
                        }),
                        " "
                    ]
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                    style: {
                        fill: "#E6E9EE"
                    },
                    cx: "254",
                    cy: "148.8",
                    r: "28.4"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#2C9984"
                    },
                    d: "M298.4,258.8c-1.6-23.2-20.8-42-44.4-42s-43.2,18.4-44.4,42H298.4z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "121.6",
                    y: "251.6",
                    style: {
                        fill: "#E6E9EE"
                    },
                    width: "265.2",
                    height: "120"
                }),
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFFFFF"
                            },
                            d: "M414.4,387.6h-21.6c-14.4,0-26-11.6-26-26V262c0-14.4,11.6-26,26-26h21.6V387.6z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFFFFF"
                            },
                            d: "M93.6,387.6h21.6c14.4,0,26-11.6,26-26V262c0-14.4-11.6-26-26-26H93.6V387.6z"
                        }),
                        " "
                    ]
                }),
                " "
            ]
        })
    ]
});
const tankSVG = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512",
    width: "125px",
    height: "200px",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#CCC3A8"
                    },
                    d: "M138.216,263.598H75.251c-7.365,0-13.334,5.97-13.334,13.334v17.749v3.733v17.75 c0,0.23,0.021,0.453,0.033,0.681h89.565c0.012-0.228,0.034-0.451,0.034-0.681v-17.75v-3.733v-17.75 C151.55,269.568,145.58,263.598,138.216,263.598z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#C9B585"
                    },
                    d: "M84.14,298.415v-3.733v-17.75c0-7.364,5.969-13.334,13.334-13.334H75.251 c-7.365,0-13.334,5.97-13.334,13.334v17.749v3.733v17.75c0,0.23,0.021,0.453,0.033,0.681h22.223 c-0.012-0.228-0.033-0.451-0.033-0.681V298.415z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#4BAF78"
                    },
                    d: "M183.153,299.096H57.843H43.329c-7.365,0-13.334,5.97-13.334,13.334v27.833v140.462v27.833H44.51 h138.643h14.514v-27.833V326.929v-27.833H183.153z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#299956"
                    },
                    d: "M52.218,340.263V312.43c0-7.364,5.969-13.334,13.334-13.334h-7.709H43.329 c-7.365,0-13.334,5.97-13.334,13.334v27.833v140.462v27.833H44.51h7.709v-27.833V340.263H52.218z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#CCC3A8"
                    },
                    d: "M418.401,0H399.34h-30.001h-11.852h-2.051h-51.287h-9.627h-53.338 c-7.364,0-13.334,5.97-13.334,13.334v11.982v9.499v11.982c0,0.232,0.024,0.456,0.034,0.683h53.338h36.226h24.689h28.649h60.914 c0.013-0.228,0.034-0.451,0.034-0.683V34.815v-9.499V13.334C431.735,5.97,425.765,0,418.401,0z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#C9B585"
                    },
                    d: "M250.074,34.815v-9.499V13.334C250.074,5.97,256.044,0,263.408,0h-22.223 c-7.364,0-13.334,5.97-13.334,13.334v11.982v9.499v11.982c0,0.232,0.024,0.456,0.034,0.683h22.223 c-0.011-0.228-0.034-0.451-0.034-0.683V34.815z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                    style: {
                        fill: "#FFB92E"
                    },
                    points: "183.153,343.638 44.509,343.638 29.995,343.638 29.995,379.134 44.509,379.134 183.153,379.134 197.667,379.134 197.667,343.638 "
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                    style: {
                        fill: "#EF9A1D"
                    },
                    points: "50.295,343.638 31.918,343.638 29.995,343.638 29.995,379.134 31.918,379.134 50.295,379.134 52.218,379.134 52.218,343.638 "
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "336.004",
                    y: "35.824",
                    style: {
                        fill: "#8BD8F7"
                    },
                    width: "63.336",
                    height: "459.665"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#36A1CB"
                    },
                    d: "M435.704,35.498H224.106c-22.618,0-40.954,18.334-40.954,40.954v18.461v385.813v18.461h293.507 v-18.461V148.408v-18.461v-9.32v-18.461v-7.251V76.453C476.66,53.832,458.323,35.498,435.704,35.498z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#7C7A75"
                    },
                    d: "M399.34,17.164c-4.604,0-8.334,3.73-8.334,8.334v1.992h-46.669v-1.992 c0-4.604-3.731-8.334-8.334-8.334c-4.604,0-8.334,3.73-8.334,8.334v10.326V56.61v17.334v38.122v38.122 c0,0.186,0.016,0.367,0.027,0.55c-0.012,0.183-0.027,0.364-0.027,0.55v38.121v38.124v38.121v38.124c0,0.186,0.016,0.367,0.027,0.549 c-0.012,0.182-0.027,0.363-0.027,0.549v38.123v38.123v38.123v38.121v38.124c0,4.602,3.73,8.334,8.334,8.334h63.336 c4.602,0,8.334-3.731,8.334-8.334v-38.124v-38.121v-38.126v-38.123v-38.123c0-0.186-0.017-0.367-0.028-0.549 c0.012-0.182,0.028-0.363,0.028-0.549V265.65v-38.121v-38.124v-38.121c0-0.186-0.017-0.367-0.028-0.55 c0.012-0.183,0.028-0.364,0.028-0.55v-38.122V73.944V57.619V35.824V25.498C407.674,20.895,403.942,17.164,399.34,17.164z M391.007,487.15h-46.669v-21.457h46.669V487.15z M391.007,449.026h-46.669v-21.453h46.669V449.026z M391.007,410.907h-46.669 v-21.455h46.669V410.907z M391.007,372.784h-46.669v-21.455h46.669V372.784z M391.007,334.662h-46.669v-21.455h46.669V334.662z M391.007,295.441h-46.669v-21.457h46.669V295.441z M391.007,257.317h-46.669v-21.453h46.669V257.317z M391.007,219.198h-46.669 v-21.457h46.669V219.198z M391.007,181.074h-46.669v-21.453h46.669V181.074z M391.007,141.853h-46.669v-21.454h46.669V141.853z M391.007,103.731h-46.669V82.278h46.669V103.731z M391.007,57.619v7.99h-46.669v-9V44.158h46.669V57.619z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#2B80AF"
                    },
                    d: "M205.375,94.914V76.453c0-22.62,18.336-40.954,40.954-40.954h-22.223 c-22.618,0-40.954,18.334-40.954,40.954v18.461v385.813v18.461h22.222v-18.461V94.914H205.375z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#6B6861"
                    },
                    d: "M344.245,24.317v479.501h22.223V487.15h-22.13v-21.457h22.13v-16.667h-22.13v-21.453h22.13v-16.667 h-22.13v-21.454h22.13v-16.667h-22.13v-21.455h22.13v-16.667h-22.13v-21.455h22.13V295.44h-22.13v-21.457h22.13v-16.667h-22.13 v-21.453h22.13v-16.667h-22.13v-21.457h22.13v-16.667h-22.13v-21.453h22.13v-17.767h-22.13v-21.454h22.13v-16.667h-22.13V82.278 h22.13V65.611h-22.13v-9V44.158h22.13V27.49h-22.13v-1.992C344.338,25.096,344.299,24.703,344.245,24.317z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#CCC3A8"
                    },
                    d: "M497.642,480.725h-83.706H98.066H14.36c-7.691,0-13.926,6.235-13.926,13.926v3.422 C0.433,505.765,6.668,512,14.36,512h83.706h298.77h28.15h72.656c7.691,0,13.926-6.235,13.926-13.926v-3.422 C511.568,486.96,505.333,480.725,497.642,480.725z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#C9B585"
                    },
                    d: "M22.655,498.074v-3.422c0-7.691,6.235-13.926,13.926-13.926H14.358 c-7.691,0-13.926,6.235-13.926,13.926v3.422c0,7.691,6.235,13.926,13.926,13.926h22.223C28.891,512,22.655,505.765,22.655,498.074z"
                }),
                " "
            ]
        })
    ]
});
const halfCricle = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    fill: "#000000",
    height: "64px",
    width: "64px",
    version: "1.1",
    id: "Capa_1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 285.919 285.919",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M142.959,0C64.131,0,0,64.132,0,142.96c0,78.828,64.131,142.959,142.959,142.959c78.828,0,142.96-64.131,142.96-142.959 C285.919,64.132,221.787,0,142.959,0z M142.959,260.919V142.96V25c65.043,0,117.96,52.917,117.96,117.96 C260.919,208.003,208.002,260.919,142.959,260.919z"
                }),
                " "
            ]
        })
    ]
});
const gauges = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512",
    width: "50px",
    height: "50px",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "232.191",
                    y: "445.555",
                    style: {
                        fill: "#E6E6E6"
                    },
                    width: "47.619",
                    height: "66.445"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "232.191",
                    y: "445.555",
                    style: {
                        fill: "#CCCCCC"
                    },
                    width: "10.8",
                    height: "66.445"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "260.013",
                    y: "445.555",
                    style: {
                        fill: "#F2F2F2"
                    },
                    width: "10.8",
                    height: "66.445"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "232.191",
                    y: "445.555",
                    style: {
                        fill: "#CCCCCC"
                    },
                    width: "47.619",
                    height: "30.903"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#B3B3B3"
                    },
                    d: "M290.922,389.21v75.981h-69.82V389.21c11.328,2.209,22.999,3.375,34.904,3.375 C267.923,392.585,279.582,391.419,290.922,389.21z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#999999"
                    },
                    d: "M235.286,389.21v75.981h-14.184V389.21c2.301,2.209,4.672,3.375,7.09,3.375 C230.614,392.585,232.982,391.419,235.286,389.21z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#CCCCCC"
                    },
                    d: "M280.368,389.21v75.981h-14.184V389.21c2.301,2.209,4.672,3.375,7.09,3.375 C275.695,392.585,278.064,391.419,280.368,389.21z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#999999"
                    },
                    d: "M256.006,392.585c-11.905,0-23.576-1.166-34.904-3.375v23.318c11.328,2,22.999,3.044,34.904,3.044 c11.917,0,23.576-1.043,34.916-3.044V389.21C279.582,391.419,267.923,392.585,256.006,392.585z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#F77346"
                    },
                    d: "M256.006,0c110.345,0,199.803,89.457,199.803,199.815c0,98.441-71.183,180.252-164.886,196.759 c-11.34,2-22.999,3.044-34.916,3.044c-11.905,0-23.576-1.043-34.904-3.044c-93.716-16.507-164.911-98.318-164.911-196.759 C56.191,89.457,145.648,0,256.006,0z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#F4550F"
                    },
                    d: "M256.006,384.071c-10.815,0-21.647-0.945-32.194-2.807c-42.119-7.419-80.633-29.578-108.447-62.393 c-28.134-33.194-43.629-75.476-43.629-119.057c0-101.606,82.663-184.269,184.269-184.269c101.6,0,184.256,82.663,184.256,184.269 c0,43.581-15.492,85.864-43.621,119.057c-27.809,32.816-66.315,54.974-108.427,62.393 C277.653,383.127,266.817,384.071,256.006,384.071z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#35D8B9"
                    },
                    d: "M137.577,81.377c65.295-65.295,171.552-65.295,236.856,0.009s65.295,171.552,0,236.847 c-65.304,65.304-171.552,65.313-236.856,0.009S72.273,146.681,137.577,81.377z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#B9FCEF"
                    },
                    d: "M374.432,81.385c65.304,65.304,65.295,171.552,0,236.847 c-65.304,65.304-171.552,65.313-236.856,0.009"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "196.857",
                    y: "267.389",
                    style: {
                        fill: "#F2F2F2"
                    },
                    width: "118.298",
                    height: "46.539"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#FFFFFF"
                    },
                    d: "M273.016,199.815c0-9.401-7.609-17.022-17.01-17.022c-9.401,0-17.022,7.621-17.022,17.022 s7.621,17.022,17.022,17.022C265.407,216.837,273.016,209.216,273.016,199.815z"
                }),
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#666666"
                            },
                            d: "M315.149,261.866h-39.544c-0.006,0-0.012-0.001-0.018-0.001h-39.171 c-0.006,0-0.012,0.001-0.018,0.001h-39.548c-3.05,0-5.523,2.473-5.523,5.523v46.539c0,3.05,2.473,5.523,5.523,5.523h39.527 c0.015,0,0.027,0.004,0.042,0.004h39.171c0.015,0,0.027-0.004,0.042-0.004h39.52c3.05,0,5.523-2.473,5.523-5.523v-46.539 C320.672,264.339,318.2,261.866,315.149,261.866z M241.94,308.405v-35.493h28.126v35.493H241.94z M202.374,272.912h28.521v35.493 h-28.521V272.912z M309.626,308.405H281.11v-35.493h28.516V308.405z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#666666"
                            },
                            d: "M261.524,177.981v-51.873h-11.046v51.874c-9.763,2.474-17.019,11.309-17.019,21.831 c0,12.431,10.114,22.545,22.545,22.545c12.425,0,22.533-10.114,22.533-22.545C278.539,189.291,271.285,180.454,261.524,177.981z M256.006,211.314c-6.341,0-11.5-5.158-11.5-11.5c0-6.336,5.152-11.492,11.487-11.498h0.023 c6.329,0.006,11.476,5.162,11.476,11.498C267.494,206.156,262.34,211.314,256.006,211.314z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "250.477",
                            y: "59.438",
                            style: {
                                fill: "#666666"
                            },
                            width: "11.046",
                            height: "33.419"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "196.996",
                            y: "78.071",
                            transform: "matrix(-0.342 -0.9397 0.9397 -0.342 208.2402 313.0015)",
                            style: {
                                fill: "#666666"
                            },
                            width: "33.419",
                            height: "11.046"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "159.807",
                            y: "99.553",
                            transform: "matrix(-0.6428 -0.766 0.766 -0.6428 209.4925 307.8353)",
                            style: {
                                fill: "#666666"
                            },
                            width: "33.418",
                            height: "11.045"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "132.195",
                            y: "132.444",
                            transform: "matrix(-0.866 -0.5 0.5 -0.866 208.8721 331.9027)",
                            style: {
                                fill: "#666666"
                            },
                            width: "33.418",
                            height: "11.045"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "117.492",
                            y: "172.82",
                            transform: "matrix(-0.9848 -0.1737 0.1737 -0.9848 235.3859 377.2847)",
                            style: {
                                fill: "#666666"
                            },
                            width: "33.419",
                            height: "11.046"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "361.068",
                            y: "215.784",
                            transform: "matrix(-0.9848 -0.1737 0.1737 -0.9848 711.3721 504.8686)",
                            style: {
                                fill: "#666666"
                            },
                            width: "33.419",
                            height: "11.046"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "128.694",
                            y: "204.581",
                            transform: "matrix(-0.1736 -0.9848 0.9848 -0.1736 -60.4133 391.8862)",
                            style: {
                                fill: "#666666"
                            },
                            width: "11.045",
                            height: "33.419"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "372.277",
                            y: "161.623",
                            transform: "matrix(-0.1736 -0.9848 0.9848 -0.1736 267.7623 581.3542)",
                            style: {
                                fill: "#666666"
                            },
                            width: "11.045",
                            height: "33.419"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "357.595",
                            y: "121.259",
                            transform: "matrix(-0.5 -0.866 0.866 -0.5 425.1972 521.4208)",
                            style: {
                                fill: "#666666"
                            },
                            width: "11.045",
                            height: "33.418"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "329.957",
                            y: "88.367",
                            transform: "matrix(-0.766 -0.6428 0.6428 -0.766 524.9188 401.2193)",
                            style: {
                                fill: "#666666"
                            },
                            width: "11.045",
                            height: "33.418"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                            x: "292.783",
                            y: "66.886",
                            transform: "matrix(-0.9397 -0.342 0.342 -0.9397 550.0344 264.1713)",
                            style: {
                                fill: "#666666"
                            },
                            width: "11.046",
                            height: "33.419"
                        }),
                        " "
                    ]
                }),
                " "
            ]
        })
    ]
});
const pipeSmall = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 508 508",
    width: "30px",
    height: "30px",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                    style: {
                        fill: "#84DBFF"
                    },
                    cx: "254",
                    cy: "254",
                    r: "254"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#F1543F"
                    },
                    d: "M266.4,112.8c0,23.6-6.8,64.8-15.2,64.8c-8.4,0-15.2-41.2-15.2-64.8s6.8-20.4,15.2-20.4 C259.6,92.4,266.4,89.2,266.4,112.8z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#FF7058"
                    },
                    d: "M327.6,113.6H180.4c-8.8,0-16.4-7.2-16.4-16.4l0,0c0-8.8,7.2-16.4,16.4-16.4h147.2 c8.8,0,16.4,7.2,16.4,16.4l0,0C344,106.4,336.8,113.6,327.6,113.6z"
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "121.2",
                    y: "244.4",
                    style: {
                        fill: "#E6E9EE"
                    },
                    width: "265.2",
                    height: "130.8"
                }),
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFFFFF"
                            },
                            d: "M386.8,398L386.8,398c-12,0-21.6-9.6-21.6-21.6v-130c0-12,9.6-21.6,21.6-21.6l0,0 c12,0,21.6,9.6,21.6,21.6v130C408,388,398.4,398,386.8,398z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFFFFF"
                            },
                            d: "M121.2,398L121.2,398c-12,0-21.6-9.6-21.6-21.6v-130c0-12,9.6-21.6,21.6-21.6l0,0 c12,0,21.6,9.6,21.6,21.6v130C142.8,388,133.2,398,121.2,398z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFFFFF"
                            },
                            d: "M308,224c0,50.8-24.4,121.2-54,121.2c-30,0-54-70.4-54-121.2s24.4-62.8,54-62.8 C284,161.2,308,173.2,308,224z"
                        }),
                        " "
                    ]
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    style: {
                        fill: "#E6E9EE"
                    },
                    d: "M310.8,222.4H197.2c-6.8,0-12.4-5.6-12.4-12.4l0,0c0-6.8,5.6-12.4,12.4-12.4h113.2 c6.8,0,12.4,5.6,12.4,12.4l0,0C322.8,216.8,317.6,222.4,310.8,222.4z"
                }),
                " "
            ]
        })
    ]
});
const pipeMark = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "-51.2 -51.2 614.40 614.40",
    width: "50px",
    height: "50px",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0",
            children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                x: "-51.2",
                y: "-51.2",
                width: "614.40",
                height: "614.40",
                rx: "307.2",
                fill: "#7ed0ec"
            })
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFAD61"
                            },
                            d: "M55.756,398.907H25.962c-8.706,0-15.763-7.058-15.763-15.763V128.856 c0-8.706,7.058-15.763,15.763-15.763h29.794c8.706,0,15.763,7.058,15.763,15.763v254.289 C71.52,391.85,64.462,398.907,55.756,398.907z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#FFAD61"
                            },
                            d: "M486.038,398.907h-29.275c-8.706,0-15.763-7.058-15.763-15.763V128.856 c0-8.706,7.058-15.763,15.763-15.763h29.275c8.706,0,15.763,7.058,15.763,15.763v254.289 C501.801,391.85,494.743,398.907,486.038,398.907z"
                        }),
                        " "
                    ]
                }),
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                    x: "71.517",
                    y: "148.949",
                    style: {
                        fill: "#F2F2F2"
                    },
                    width: "369.476",
                    height: "214.102"
                }),
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#534741"
                            },
                            d: "M486.038,102.894h-29.275c-14.316,0-25.962,11.646-25.962,25.962v9.894H81.719v-9.894 c0-14.316-11.647-25.962-25.963-25.962H25.962C11.646,102.894,0,114.54,0,128.856v254.289c0,14.316,11.646,25.962,25.962,25.962 h29.794c14.316,0,25.963-11.646,25.963-25.962v-9.894h349.082v9.894c0,14.316,11.646,25.962,25.962,25.962h29.275 c14.316,0,25.962-11.646,25.962-25.962V128.856C512,114.54,500.354,102.894,486.038,102.894z M61.321,383.144 c0,3.068-2.496,5.564-5.565,5.564H25.962c-3.068,0-5.564-2.496-5.564-5.564V128.856c0-3.068,2.496-5.564,5.564-5.564h29.794 c3.069,0,5.565,2.496,5.565,5.564V383.144z M81.719,352.852V159.148h349.082v193.703H81.719z M451.199,128.856 c0-3.068,2.496-5.564,5.564-5.564h29.275c3.068,0,5.564,2.496,5.564,5.564v254.289c0,3.068-2.496,5.564-5.564,5.564h-29.275 c-3.068,0-5.564-2.496-5.564-5.564V128.856z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#534741"
                            },
                            d: "M277.306,319.593h-5.197c-5.632,0-10.199,4.567-10.199,10.199c0,5.632,4.567,10.199,10.199,10.199 h5.197c5.632,0,10.199-4.567,10.199-10.199C287.505,324.16,282.938,319.593,277.306,319.593z"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#534741"
                            },
                            d: "M232.615,319.593h-123.68c-5.632,0-10.199,4.567-10.199,10.199c0,5.632,4.567,10.199,10.199,10.199 h123.681c5.632,0,10.199-4.567,10.199-10.199C242.815,324.16,238.248,319.593,232.615,319.593z"
                        }),
                        " "
                    ]
                }),
                " "
            ]
        })
    ]
});
const markPipe = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    height: "30px",
    width: "30px",
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                            style: {
                                fill: "#F0C419"
                            },
                            points: "0,344.276 158.897,344.276 158.897,167.724 0,167.724 "
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                            style: {
                                fill: "#C1991A"
                            },
                            points: "494.345,397.241 388.414,397.241 370.759,317.793 370.759,194.207 388.414,114.759 494.345,114.759 512,194.207 512,317.793 "
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                            style: {
                                fill: "#ECF0F1"
                            },
                            points: "220.69,344.276 308.966,344.276 308.966,167.724 220.69,167.724 "
                        }),
                        " ",
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                                    style: {
                                        fill: "#C1991A"
                                    },
                                    points: "308.966,317.793 370.759,317.793 370.759,194.207 308.966,194.207 "
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                                    style: {
                                        fill: "#C1991A"
                                    },
                                    points: "158.897,317.793 220.69,317.793 220.69,194.207 158.897,194.207 "
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    style: {
                                        fill: "#C1991A"
                                    },
                                    d: "M35.31,379.586c-4.873,0-8.828-3.946-8.828-8.828V141.241c0-4.882,3.955-8.828,8.828-8.828 s8.828,3.946,8.828,8.828v229.517C44.138,375.64,40.183,379.586,35.31,379.586"
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    style: {
                                        fill: "#C1991A"
                                    },
                                    d: "M79.448,379.586c-4.873,0-8.828-3.946-8.828-8.828V141.241c0-4.882,3.955-8.828,8.828-8.828 c4.873,0,8.828,3.946,8.828,8.828v229.517C88.276,375.64,84.321,379.586,79.448,379.586"
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    style: {
                                        fill: "#C1991A"
                                    },
                                    d: "M123.586,379.586c-4.873,0-8.828-3.946-8.828-8.828V141.241c0-4.882,3.955-8.828,8.828-8.828 s8.828,3.946,8.828,8.828v229.517C132.414,375.64,128.459,379.586,123.586,379.586"
                                }),
                                " "
                            ]
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                            style: {
                                fill: "#F0C419"
                            },
                            points: "370.759,317.793 512,317.793 512,194.207 370.759,194.207 "
                        }),
                        " "
                    ]
                }),
                " "
            ]
        })
    ]
});
const coupling = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    fill: "#000000",
    height: "200px",
    width: "200px",
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    transform: "translate(0 -1)",
                    children: [
                        " ",
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M487.246,194.154h-25.394v-8.393c0-9.252-7.535-16.787-16.787-16.787H411.03c-9.015,0-16.325,7.315-16.325,16.325v8.617 c-20.502-1.249-30.091-7.304-33.21-14.962c-3.256-8.015-5.538-12.599-9.108-17.277c-10.542-13.801-25.03-25.246-44.694-36.938 c-32.52-19.344-74.7-19.337-111.366-0.229c-17.633,9.202-33.704,22.242-45.102,37.164c-3.572,4.681-5.854,9.265-9.113,17.288 c-3.094,7.595-12.574,13.62-32.783,14.928v-8.591c0-9.013-7.313-16.325-16.334-16.325H58.967c-9.252,0-16.787,7.535-16.787,16.787 v8.393H16.787C7.772,194.154,0,201.93,0,210.941v83.934c0,9.017,7.77,16.787,16.787,16.787H42.18v9.308 c0,8.772,7.105,15.872,15.872,15.872h34.942c9.023,0,16.334-7.306,16.334-16.325v-8.602c20.206,1.307,29.673,7.327,32.768,14.933 c3.257,8.018,5.539,12.603,9.11,17.28c10.859,14.208,26.241,26.482,44.847,37.019c34.553,19.575,76.917,19.575,111.463-0.001 c18.606-10.531,33.993-22.807,44.85-37.013c3.566-4.672,5.807-9.178,9.111-17.279c3.116-7.658,12.717-13.715,33.228-14.965v8.627 c0,9.017,7.308,16.325,16.325,16.325h34.942c8.772,0,15.88-7.097,15.88-15.872v-9.308h25.394c9.01,0,16.787-7.771,16.787-16.787 v-83.934C504.033,201.932,496.255,194.154,487.246,194.154z M42.177,294.875h-25.39v-83.934h25.39V294.875z M58.967,320.055 V185.76h33.574v8.397h-0.217v117.491h0.217v8.407H58.967z M394.488,295.102c-27.326,1.624-42.827,11.334-48.558,25.419 c-2.769,6.79-4.502,10.274-6.905,13.423c-9.304,12.173-22.985,23.089-39.782,32.595c-29.416,16.669-65.497,16.669-94.917,0.002 c-16.796-9.512-30.474-20.426-39.78-32.602c-2.408-3.156-4.171-6.696-6.9-13.414c-5.72-14.057-21.134-23.746-48.318-25.408v-84.43 c27.183-1.663,42.611-11.356,48.332-25.4c2.732-6.725,4.495-10.266,6.906-13.426c9.837-12.878,23.989-24.361,39.522-32.467 c31.654-16.496,67.663-16.503,95.023-0.227c17.984,10.694,30.945,20.932,39.932,32.697c2.41,3.157,4.172,6.698,6.901,13.416 c5.74,14.092,21.225,23.799,48.543,25.423V295.102z M445.066,320.055h-33.574V185.76h33.574V320.055z M487.246,294.875h-25.39 v-83.934h25.39V294.875z"
                                }),
                                " "
                            ]
                        }),
                        " "
                    ]
                }),
                " "
            ]
        })
    ]
});
const pipeEnd = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    height: "50px",
    width: "50px",
    version: "1.1",
    id: "Layer_1",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "-50.38 -50.38 604.52 604.52",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0",
            children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                x: "-50.38",
                y: "-50.38",
                width: "604.52",
                height: "604.52",
                rx: "302.26",
                fill: "#7ed0ec"
            })
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#BDC3C7"
                            },
                            d: "M251.661,91.21c-4.79,0-8.678-3.879-8.678-8.678V47.82c0-4.799,3.888-8.678,8.678-8.678 c4.79,0,8.678,3.879,8.678,8.678v34.712C260.339,87.331,256.451,91.21,251.661,91.21"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#35495E"
                            },
                            d: "M0,308.159v86.78c0,4.53,4.148,8.678,8.678,8.678h34.929V299.481H8.678 C4.148,299.481,0,303.638,0,308.159"
                        }),
                        " ",
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    style: {
                                        fill: "#21313F"
                                    },
                                    d: "M43.61,282.125v139.793c0,4.278,3.463,7.732,7.732,7.732h36.126c4.539,0,8.209-3.671,8.209-8.201 V281.648c0-4.521-3.671-8.201-8.209-8.201h-35.18C47.515,273.447,43.61,277.352,43.61,282.125"
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    style: {
                                        fill: "#21313F"
                                    },
                                    d: "M321.305,134.6H181.512c-4.27,0-7.732,3.462-7.732,7.741v36.126c0,4.53,3.671,8.201,8.201,8.201 h139.793c4.539,0,8.209-3.671,8.209-8.201v-35.189C329.983,138.505,326.078,134.6,321.305,134.6"
                                }),
                                " "
                            ]
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#35495E"
                            },
                            d: "M503.759,308.159v86.78c0,4.53-4.148,8.678-8.678,8.678h-34.929V299.481h34.929 C499.61,299.481,503.759,303.638,503.759,308.159"
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#21313F"
                            },
                            d: "M460.153,282.125v139.793c0,4.278-3.462,7.732-7.732,7.732h-36.135c-4.53,0-8.201-3.671-8.201-8.201 V281.648c0-4.521,3.671-8.201,8.201-8.201h35.189C456.248,273.447,460.153,277.352,460.153,282.125"
                        }),
                        " ",
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    style: {
                                        fill: "#35495E"
                                    },
                                    d: "M408.085,299.481c0,0-34.347-1.805-60.746-26.034l-8.244-6.179 c-16.662-12.496-26.468-32.108-26.468-52.944v-27.657H191.136v27.657c0,20.836-9.806,40.448-26.476,52.944l-8.235,6.179 c-26.398,24.229-60.746,26.034-60.746,26.034v104.136c37.081,0,47.755,13.581,50.827,21.131 c2.265,5.545,4.643,11.108,8.279,15.872c11.481,15.022,27.778,26.936,43.754,35.979c33.072,18.736,73.615,18.736,106.687,0 c15.967-9.042,32.273-20.957,43.746-35.979c3.645-4.764,6.022-10.327,8.287-15.872c3.063-7.55,13.746-21.131,50.827-21.131 V299.481z"
                                }),
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                                    style: {
                                        fill: "#35495E"
                                    },
                                    points: "242.983,82.532 208.271,134.6 295.051,134.6 260.339,82.532 "
                                }),
                                " "
                            ]
                        }),
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            style: {
                                fill: "#D25627"
                            },
                            d: "M121.492,30.464L121.492,30.464c0,9.554,7.81,17.356,17.356,17.356h225.627 c9.546,0,17.356-7.801,17.356-17.356c0-9.546-7.81-17.356-17.356-17.356H138.847C129.302,13.108,121.492,20.918,121.492,30.464"
                        }),
                        " "
                    ]
                }),
                " "
            ]
        })
    ]
});
const gasOut = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
    height: "50px",
    width: "50px",
    version: "1.1",
    id: "_x32_",
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 512 512",
    fill: "#000000",
    children: [
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_bgCarrier",
            "stroke-width": "0"
        }),
        /*#__PURE__*/ jsx_runtime_.jsx("g", {
            id: "SVGRepo_tracerCarrier",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
        }),
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
            id: "SVGRepo_iconCarrier",
            children: [
                " ",
                /*#__PURE__*/ jsx_runtime_.jsx("style", {
                    type: "text/css",
                    children: "  "
                }),
                " ",
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                            className: "st0",
                            points: "512,256.001 195.491,18.616 195.491,153.599 0,153.599 0,358.403 195.491,358.403 195.491,493.384 "
                        }),
                        " "
                    ]
                }),
                " "
            ]
        })
    ]
});


// EXTERNAL MODULE: ./app/(main)/OTSUKA/ReactFlow/Flow.css
var Flow = __webpack_require__(96035);
;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/initalsEgdes.tsx

const styleLine = {
    strokeWidth: 2,
    stroke: "#FFF"
};
const markerType = {
    type: esm/* MarkerType */.QZ.ArrowClosed,
    width: 7,
    height: 7,
    color: "#036E9B"
};
const initialEdges = [
    {
        id: "station-pipeSVD",
        source: "station",
        target: "pipeSVD",
        // animated: true,
        style: {
            ...styleLine
        }
    },
    {
        id: "station-pipeSmall",
        source: "station",
        target: "pipeSmall",
        type: "smoothstep",
        // animated: true,
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeSmall-pipeSVD",
        source: "pipeSmall",
        target: "pipeSVD",
        type: "smoothstep",
        // animated: true,
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeSmall2-pipeSVD",
        source: "pipeSmall2",
        target: "pipeMark",
        type: "smoothstep",
        // animated: true,
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeSVD-pipeSmall2",
        source: "pipeSVD",
        target: "pipeSmall2",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "Tank-pipeSVD",
        source: "pipeSVD",
        target: "TankSVG",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "HalfCricle-Tank",
        source: "halfCricle",
        target: "TankSVG",
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "Tank-epipeSVD",
        source: "TankSVG",
        target: "pipeMark",
        // animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeMark-gauges",
        source: "pipeMark",
        target: "gauges",
        // animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeMark-gauges",
        source: "pipeMark",
        target: "gauges",
        // animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeMark-gauges2",
        source: "pipeMark",
        target: "gauges2",
        // animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "gauges-FIQ",
        source: "gauges",
        target: "FIQ",
        animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "gauges-bara1",
        source: "gauges",
        target: "bara1",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "gauges2-bara2",
        source: "gauges2",
        target: "bara2",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "FIQ-1",
        source: "FIQ",
        target: "1",
        animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "FIQ2-2",
        source: "FIQ2",
        target: "2",
        animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "FIQ-coupling2",
        source: "FIQ",
        target: "coupling2",
        animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "gauges2-FIQ2",
        source: "gauges2",
        target: "FIQ2",
        animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "gauges2-coupling",
        source: "gauges2",
        target: "coupling",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "gauges3-bara3",
        source: "gauges3",
        target: "bara3",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "coupling-coupling2",
        source: "coupling",
        target: "coupling2",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "FIQ2-pipeMark2",
        source: "FIQ2",
        target: "pipeMark2",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "coupling2-pipeMark2",
        source: "coupling2",
        target: "pipeMark2",
        // animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeMark2-pipeEnd",
        source: "pipeMark2",
        target: "pipeEnd",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeMark2-pipeEnd2",
        source: "pipeMark2",
        target: "pipeEnd2",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeEnd-pipeMark3",
        source: "pipeEnd",
        target: "pipeMark3",
        // animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeEnd2-pipeMark3",
        source: "pipeEnd2",
        target: "pipeMark3",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeMark3-gauges3",
        source: "pipeMark3",
        target: "gauges3",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeMark3-halfCricle2",
        source: "pipeMark3",
        target: "halfCricle2",
        // animated: true,
        type: "smoothstep",
        style: {
            ...styleLine
        }
    },
    {
        id: "pipeMark3-gasout",
        source: "pipeMark3",
        target: "gasout",
        // animated: true,
        type: "smoothstep",
        markerEnd: {
            ...markerType
        },
        style: {
            ...styleLine
        }
    }
];

// EXTERNAL MODULE: ./node_modules/primereact/overlaypanel/overlaypanel.cjs.js
var overlaypanel_cjs = __webpack_require__(98063);
// EXTERNAL MODULE: ./node_modules/primereact/confirmdialog/confirmdialog.cjs.js
var confirmdialog_cjs = __webpack_require__(82558);
// EXTERNAL MODULE: ./api/http.api.ts
var http_api = __webpack_require__(49213);
;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/BallValue01.tsx




function BallValue01() {
    const [sensorData, setSensorData] = (0,react_.useState)([]);
    const [upData, setUpData] = (0,react_.useState)([]);
    const [upTS, setUpTS] = (0,react_.useState)([]);
    const [data, setData] = (0,react_.useState)([]);
    const [Status, setStatus] = (0,react_.useState)([]);
    const token = (0,service_localStorage/* readToken */.YG)();
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj2 = {
            entityDataCmds: [
                {
                    cmdId: 1,
                    latestCmd: {
                        keys: [
                            {
                                type: "ATTRIBUTE",
                                key: "BallValue_01"
                            }
                        ]
                    },
                    query: {
                        entityFilter: {
                            type: "singleEntity",
                            singleEntity: {
                                entityType: "DEVICE",
                                id: "28f7e830-a3ce-11ee-9ca1-8f006c3fce43"
                            }
                        },
                        pageLink: {
                            pageSize: 1,
                            page: 0,
                            sortOrder: {
                                key: {
                                    type: "ENTITY_FIELD",
                                    key: "createdTime"
                                },
                                direction: "DESC"
                            }
                        },
                        entityFields: [
                            {
                                type: "ENTITY_FIELD",
                                key: "name"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "label"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "additionalInfo"
                            }
                        ],
                        latestValues: [
                            {
                                type: "ATTRIBUTE",
                                key: "BallValue_01"
                            }
                        ]
                    }
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj2));
                });
            };
            ws.current.onclose = ()=>{};
            return ()=>{
                ws.current?.close();
            };
        }
    }, []);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (event)=>{
                let dataReceived = JSON.parse(event.data);
                if (dataReceived.data && dataReceived.data.data.length > 0) {
                    const ballValue = dataReceived.data.data[0].latest.ATTRIBUTE.BallValue_01.value;
                    setUpData(ballValue);
                    const ballTS = dataReceived.data.data[0].latest.ATTRIBUTE.BallValue_01.ts;
                    setUpTS(ballTS);
                } else if (dataReceived.update && dataReceived.update.length > 0) {
                    const updatedData = dataReceived.update[0].latest.ATTRIBUTE.BallValue_01.value;
                    const updateTS = dataReceived.update[0].latest.ATTRIBUTE.BallValue_01.ts;
                    setUpData(updatedData);
                    setUpTS(updateTS);
                }
            };
        }
    }, []);
    const handleButtonClick = async ()=>{
        try {
            const newValue = !sensorData;
            await http_api/* httpApi */.Y.post("/plugins/telemetry/DEVICE/28f7e830-a3ce-11ee-9ca1-8f006c3fce43/SERVER_SCOPE", {
                BallValue_01: newValue
            });
            setSensorData(newValue);
            fetchData();
        } catch (error) {}
    };
    const fetchData = async ()=>{
        try {
            const res = await http_api/* httpApi */.Y.get("/plugins/telemetry/DEVICE/28f7e830-a3ce-11ee-9ca1-8f006c3fce43/values/attributes/SERVER_SCOPE");
            setData(res.data);
        } catch (error) {}
    };
    (0,react_.useEffect)(()=>{
        fetchData();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: data.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: item.key === "BallValue_01" && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        style: {
                            padding: 10,
                            cursor: "pointer",
                            border: "none",
                            width: 50,
                            height: 50,
                            background: "white",
                            fontWeight: 600
                        },
                        onClick: handleButtonClick,
                        children: item.value.toString() === "false" ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            style: {
                                color: "red"
                            },
                            children: "OFF"
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            style: {
                                color: "green"
                            },
                            children: "ON"
                        })
                    })
                })
            }, item.key))
    });
}

;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/BallValue02.tsx




function BallValue02_BallValue01() {
    const [sensorData, setSensorData] = (0,react_.useState)([]);
    const [upData, setUpData] = (0,react_.useState)([]);
    const [upTS, setUpTS] = (0,react_.useState)([]);
    const [data, setData] = (0,react_.useState)([]);
    const [Status, setStatus] = (0,react_.useState)([]);
    const token = (0,service_localStorage/* readToken */.YG)();
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj2 = {
            entityDataCmds: [
                {
                    cmdId: 1,
                    latestCmd: {
                        keys: [
                            {
                                type: "ATTRIBUTE",
                                key: "BallValue_02"
                            }
                        ]
                    },
                    query: {
                        entityFilter: {
                            type: "singleEntity",
                            singleEntity: {
                                entityType: "DEVICE",
                                id: "28f7e830-a3ce-11ee-9ca1-8f006c3fce43"
                            }
                        },
                        pageLink: {
                            pageSize: 1,
                            page: 0,
                            sortOrder: {
                                key: {
                                    type: "ENTITY_FIELD",
                                    key: "createdTime"
                                },
                                direction: "DESC"
                            }
                        },
                        entityFields: [
                            {
                                type: "ENTITY_FIELD",
                                key: "name"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "label"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "additionalInfo"
                            }
                        ],
                        latestValues: [
                            {
                                type: "ATTRIBUTE",
                                key: "BallValue_02"
                            }
                        ]
                    }
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj2));
                });
            };
            ws.current.onclose = ()=>{};
            return ()=>{
                ws.current?.close();
            };
        }
    }, []);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (event)=>{
                let dataReceived = JSON.parse(event.data);
                if (dataReceived.data && dataReceived.data.data.length > 0) {
                    const ballValue = dataReceived.data.data[0].latest.ATTRIBUTE.BallValue_02.value;
                    setUpData(ballValue);
                    const ballTS = dataReceived.data.data[0].latest.ATTRIBUTE.BallValue_02.ts;
                    setUpTS(ballTS);
                } else if (dataReceived.update && dataReceived.update.length > 0) {
                    const updatedData = dataReceived.update[0].latest.ATTRIBUTE.BallValue_02.value;
                    const updateTS = dataReceived.update[0].latest.ATTRIBUTE.BallValue_02.ts;
                    setUpData(updatedData);
                    setUpTS(updateTS);
                }
            };
        }
    }, []);
    const handleButtonClick = async ()=>{
        try {
            const newValue = !sensorData;
            await http_api/* httpApi */.Y.post("/plugins/telemetry/DEVICE/28f7e830-a3ce-11ee-9ca1-8f006c3fce43/SERVER_SCOPE", {
                BallValue_02: newValue
            });
            setSensorData(newValue);
            fetchData();
        } catch (error) {}
    };
    const fetchData = async ()=>{
        try {
            const res = await http_api/* httpApi */.Y.get("/plugins/telemetry/DEVICE/28f7e830-a3ce-11ee-9ca1-8f006c3fce43/values/attributes/SERVER_SCOPE");
            setData(res.data);
        } catch (error) {}
    };
    (0,react_.useEffect)(()=>{
        fetchData();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: data.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: item.key === "BallValue_02" && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        style: {
                            padding: 10,
                            cursor: "pointer",
                            border: "none",
                            width: 50,
                            height: 50,
                            fontWeight: 600,
                            background: "white"
                        },
                        onClick: handleButtonClick,
                        children: item.value.toString() === "false" ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            style: {
                                color: "red"
                            },
                            children: "OFF"
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            style: {
                                color: "green"
                            },
                            children: "ON"
                        })
                    })
                })
            }, item.key))
    });
}

;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/SDV_Otsuka.tsx







function SDV_Otsuka() {
    const [sensorData, setSensorData] = (0,react_.useState)([]);
    const [upData, setUpData] = (0,react_.useState)([]);
    const [upTS, setUpTS] = (0,react_.useState)([]);
    const [inputValue, setInputValue] = (0,react_.useState)();
    const token = (0,service_localStorage/* readToken */.YG)();
    const op = (0,react_.useRef)(null);
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj2 = {
            entityDataCmds: [
                {
                    cmdId: 1,
                    latestCmd: {
                        keys: [
                            {
                                type: "ATTRIBUTE",
                                key: "SDV"
                            }
                        ]
                    },
                    query: {
                        entityFilter: {
                            type: "singleEntity",
                            singleEntity: {
                                entityType: "DEVICE",
                                id: "28f7e830-a3ce-11ee-9ca1-8f006c3fce43"
                            }
                        },
                        pageLink: {
                            pageSize: 1,
                            page: 0,
                            sortOrder: {
                                key: {
                                    type: "ENTITY_FIELD",
                                    key: "createdTime"
                                },
                                direction: "DESC"
                            }
                        },
                        entityFields: [
                            {
                                type: "ENTITY_FIELD",
                                key: "name"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "label"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "additionalInfo"
                            }
                        ],
                        latestValues: [
                            {
                                type: "ATTRIBUTE",
                                key: "SDV"
                            }
                        ]
                    }
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                console.log("WebSocket connected");
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj2));
                });
            };
            ws.current.onclose = ()=>{
                console.log("WebSocket connection closed.");
            };
            return ()=>{
                console.log("Cleaning up WebSocket connection.");
                ws.current?.close();
            };
        }
    }, []);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (event)=>{
                let dataReceived = JSON.parse(event.data);
                if (dataReceived.data && dataReceived.data.data.length > 0) {
                    const ballValue = dataReceived.data.data[0].latest.ATTRIBUTE.SDV.value;
                    setUpData(ballValue);
                    const ballTS = dataReceived.data.data[0].latest.ATTRIBUTE.SDV.ts;
                    setUpTS(ballTS);
                } else if (dataReceived.update && dataReceived.update.length > 0) {
                    const updatedData = dataReceived.update[0].latest.ATTRIBUTE.SDV.value;
                    const updateTS = dataReceived.update[0].latest.ATTRIBUTE.SDV.ts;
                    setUpData(updatedData);
                    setUpTS(updateTS);
                }
            };
        }
    }, []);
    const handleButtonClick = async ()=>{
        try {
            await http_api/* httpApi */.Y.post("/plugins/telemetry/DEVICE/28f7e830-a3ce-11ee-9ca1-8f006c3fce43/SERVER_SCOPE", {
                SDV: inputValue
            });
            setSensorData(inputValue);
            setUpData(inputValue);
            op.current?.hide();
        } catch (error) {
            console.log("error: ", error);
        }
    };
    const handleInputChange = (event)=>{
        const newValue = Number(event.target.value);
        setInputValue(newValue);
    };
    const handleButtonToggle = (e)=>{
        op.current?.toggle(e);
        setInputValue(upData);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(button_cjs.Button, {
                style: {
                    border: "none"
                },
                onClick: handleButtonToggle,
                children: [
                    " ",
                    "SDV - ",
                    upData
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(overlaypanel_cjs/* OverlayPanel */.T, {
                ref: op,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                            keyfilter: "int",
                            value: inputValue,
                            onChange: handleInputChange
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                            label: "Update",
                            onClick: handleButtonClick
                        })
                    ]
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/primereact/toast/toast.cjs.js
var toast_cjs = __webpack_require__(11459);
;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/PCV01_Otsuka.tsx







function PCV_01_Otsuka() {
    const [sensorData, setSensorData] = (0,react_.useState)([]);
    const [upData, setUpData] = (0,react_.useState)([]);
    const [upTS, setUpTS] = (0,react_.useState)([]);
    const [inputValue, setInputValue] = (0,react_.useState)();
    const token = (0,service_localStorage/* readToken */.YG)();
    const op = (0,react_.useRef)(null);
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj2 = {
            entityDataCmds: [
                {
                    cmdId: 1,
                    latestCmd: {
                        keys: [
                            {
                                type: "ATTRIBUTE",
                                key: "PCV_01"
                            }
                        ]
                    },
                    query: {
                        entityFilter: {
                            type: "singleEntity",
                            singleEntity: {
                                entityType: "DEVICE",
                                id: "28f7e830-a3ce-11ee-9ca1-8f006c3fce43"
                            }
                        },
                        pageLink: {
                            pageSize: 1,
                            page: 0,
                            sortOrder: {
                                key: {
                                    type: "ENTITY_FIELD",
                                    key: "createdTime"
                                },
                                direction: "DESC"
                            }
                        },
                        entityFields: [
                            {
                                type: "ENTITY_FIELD",
                                key: "name"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "label"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "additionalInfo"
                            }
                        ],
                        latestValues: [
                            {
                                type: "ATTRIBUTE",
                                key: "PCV_01"
                            }
                        ]
                    }
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                console.log("WebSocket connected");
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj2));
                });
            };
            ws.current.onclose = ()=>{
                console.log("WebSocket connection closed.");
            };
            return ()=>{
                console.log("Cleaning up WebSocket connection.");
                ws.current?.close();
            };
        }
    }, []);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (event)=>{
                let dataReceived = JSON.parse(event.data);
                if (dataReceived.data && dataReceived.data.data.length > 0) {
                    const ballValue = dataReceived.data.data[0].latest.ATTRIBUTE.PCV_01.value;
                    setUpData(ballValue);
                    const ballTS = dataReceived.data.data[0].latest.ATTRIBUTE.PCV_01.ts;
                    setUpTS(ballTS);
                } else if (dataReceived.update && dataReceived.update.length > 0) {
                    const updatedData = dataReceived.update[0].latest.ATTRIBUTE.PCV_01.value;
                    const updateTS = dataReceived.update[0].latest.ATTRIBUTE.PCV_01.ts;
                    setUpData(updatedData);
                    setUpTS(updateTS);
                }
            };
        }
    }, []);
    const handleButtonClick = async ()=>{
        try {
            await http_api/* httpApi */.Y.post("/plugins/telemetry/DEVICE/28f7e830-a3ce-11ee-9ca1-8f006c3fce43/SERVER_SCOPE", {
                PCV_01: inputValue
            });
            setSensorData(inputValue);
            setUpData(inputValue);
            op.current?.hide();
        } catch (error) {
            console.log("error: ", error);
        }
    };
    const handleInputChange = (event)=>{
        const newValue = Number(event.target.value);
        setInputValue(newValue);
    };
    const handleButtonToggle = (e)=>{
        op.current?.toggle(e);
        setInputValue(upData);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(button_cjs.Button, {
                style: {
                    border: "none"
                },
                onClick: handleButtonToggle,
                children: [
                    " ",
                    "PCV - ",
                    upData
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(overlaypanel_cjs/* OverlayPanel */.T, {
                ref: op,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                            keyfilter: "int",
                            value: inputValue,
                            onChange: handleInputChange
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                            label: "Update",
                            onClick: handleButtonClick
                        })
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/PCV02_Otsuka.tsx







function PCV_02_Otsuka() {
    const [sensorData, setSensorData] = (0,react_.useState)([]);
    const [upData, setUpData] = (0,react_.useState)([]);
    const [upTS, setUpTS] = (0,react_.useState)([]);
    const [inputValue, setInputValue] = (0,react_.useState)();
    const token = (0,service_localStorage/* readToken */.YG)();
    const op = (0,react_.useRef)(null);
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj2 = {
            entityDataCmds: [
                {
                    cmdId: 1,
                    latestCmd: {
                        keys: [
                            {
                                type: "ATTRIBUTE",
                                key: "PCV_02"
                            }
                        ]
                    },
                    query: {
                        entityFilter: {
                            type: "singleEntity",
                            singleEntity: {
                                entityType: "DEVICE",
                                id: "28f7e830-a3ce-11ee-9ca1-8f006c3fce43"
                            }
                        },
                        pageLink: {
                            pageSize: 1,
                            page: 0,
                            sortOrder: {
                                key: {
                                    type: "ENTITY_FIELD",
                                    key: "createdTime"
                                },
                                direction: "DESC"
                            }
                        },
                        entityFields: [
                            {
                                type: "ENTITY_FIELD",
                                key: "name"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "label"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "additionalInfo"
                            }
                        ],
                        latestValues: [
                            {
                                type: "ATTRIBUTE",
                                key: "PCV_02"
                            }
                        ]
                    }
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                console.log("WebSocket connected");
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj2));
                });
            };
            ws.current.onclose = ()=>{
                console.log("WebSocket connection closed.");
            };
            return ()=>{
                console.log("Cleaning up WebSocket connection.");
                ws.current?.close();
            };
        }
    }, []);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (event)=>{
                let dataReceived = JSON.parse(event.data);
                if (dataReceived.data && dataReceived.data.data.length > 0) {
                    const ballValue = dataReceived.data.data[0].latest.ATTRIBUTE.PCV_02.value;
                    setUpData(ballValue);
                    const ballTS = dataReceived.data.data[0].latest.ATTRIBUTE.PCV_02.ts;
                    setUpTS(ballTS);
                } else if (dataReceived.update && dataReceived.update.length > 0) {
                    const updatedData = dataReceived.update[0].latest.ATTRIBUTE.PCV_02.value;
                    const updateTS = dataReceived.update[0].latest.ATTRIBUTE.PCV_02.ts;
                    setUpData(updatedData);
                    setUpTS(updateTS);
                }
            };
        }
    }, []);
    const handleButtonClick = async ()=>{
        try {
            await http_api/* httpApi */.Y.post("/plugins/telemetry/DEVICE/28f7e830-a3ce-11ee-9ca1-8f006c3fce43/SERVER_SCOPE", {
                PCV_02: inputValue
            });
            setSensorData(inputValue);
            setUpData(inputValue);
            op.current?.hide();
        } catch (error) {
            console.log("error: ", error);
        }
    };
    const handleInputChange = (event)=>{
        const newValue = Number(event.target.value);
        setInputValue(newValue);
    };
    const handleButtonToggle = (e)=>{
        op.current?.toggle(e);
        setInputValue(upData);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(button_cjs.Button, {
                style: {
                    border: "none"
                },
                onClick: handleButtonToggle,
                children: [
                    " ",
                    "PCV - ",
                    upData
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(overlaypanel_cjs/* OverlayPanel */.T, {
                ref: op,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                            keyfilter: "int",
                            value: inputValue,
                            onChange: handleInputChange
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                            label: "Update",
                            onClick: handleButtonClick
                        })
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/PSV02_Otsuka.tsx







function PSV_02_Otsuka() {
    const [sensorData, setSensorData] = (0,react_.useState)([]);
    const [upData, setUpData] = (0,react_.useState)([]);
    const [upTS, setUpTS] = (0,react_.useState)([]);
    const [inputValue, setInputValue] = (0,react_.useState)();
    const token = (0,service_localStorage/* readToken */.YG)();
    const op = (0,react_.useRef)(null);
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj2 = {
            entityDataCmds: [
                {
                    cmdId: 1,
                    latestCmd: {
                        keys: [
                            {
                                type: "ATTRIBUTE",
                                key: "PSV_02"
                            }
                        ]
                    },
                    query: {
                        entityFilter: {
                            type: "singleEntity",
                            singleEntity: {
                                entityType: "DEVICE",
                                id: "28f7e830-a3ce-11ee-9ca1-8f006c3fce43"
                            }
                        },
                        pageLink: {
                            pageSize: 1,
                            page: 0,
                            sortOrder: {
                                key: {
                                    type: "ENTITY_FIELD",
                                    key: "createdTime"
                                },
                                direction: "DESC"
                            }
                        },
                        entityFields: [
                            {
                                type: "ENTITY_FIELD",
                                key: "name"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "label"
                            },
                            {
                                type: "ENTITY_FIELD",
                                key: "additionalInfo"
                            }
                        ],
                        latestValues: [
                            {
                                type: "ATTRIBUTE",
                                key: "PSV_02"
                            }
                        ]
                    }
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                console.log("WebSocket connected");
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj2));
                });
            };
            ws.current.onclose = ()=>{
                console.log("WebSocket connection closed.");
            };
            return ()=>{
                console.log("Cleaning up WebSocket connection.");
                ws.current?.close();
            };
        }
    }, []);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (event)=>{
                let dataReceived = JSON.parse(event.data);
                if (dataReceived.data && dataReceived.data.data.length > 0) {
                    const ballValue = dataReceived.data.data[0].latest.ATTRIBUTE.PSV_02.value;
                    setUpData(ballValue);
                    const ballTS = dataReceived.data.data[0].latest.ATTRIBUTE.PSV_02.ts;
                    setUpTS(ballTS);
                } else if (dataReceived.update && dataReceived.update.length > 0) {
                    const updatedData = dataReceived.update[0].latest.ATTRIBUTE.PSV_02.value;
                    const updateTS = dataReceived.update[0].latest.ATTRIBUTE.PSV_02.ts;
                    setUpData(updatedData);
                    setUpTS(updateTS);
                }
            };
        }
    }, []);
    const handleButtonClick = async ()=>{
        try {
            await http_api/* httpApi */.Y.post("/plugins/telemetry/DEVICE/28f7e830-a3ce-11ee-9ca1-8f006c3fce43/SERVER_SCOPE", {
                PSV_02: inputValue
            });
            setSensorData(inputValue);
            setUpData(inputValue);
            op.current?.hide();
        } catch (error) {
            console.log("error: ", error);
        }
    };
    const handleInputChange = (event)=>{
        const newValue = Number(event.target.value);
        setInputValue(newValue);
    };
    const handleButtonToggle = (e)=>{
        op.current?.toggle(e);
        setInputValue(upData);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(button_cjs.Button, {
                style: {
                    border: "none"
                },
                onClick: handleButtonToggle,
                children: [
                    " ",
                    "PCV - ",
                    upData,
                    " BARA"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(overlaypanel_cjs/* OverlayPanel */.T, {
                ref: op,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                            keyfilter: "int",
                            value: inputValue,
                            onChange: handleInputChange
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                            label: "Update",
                            onClick: handleButtonClick
                        })
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/(main)/OTSUKA/ReactFlow/ReactFlow.tsx



















function App() {
    const op = (0,react_.useRef)(null);
    const toast = (0,react_.useRef)(null);
    const [data, setData] = (0,react_.useState)([]);
    const token = (0,service_localStorage/* readToken */.YG)();
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
    const [flowRate, setFlowRate] = (0,react_.useState)([]);
    const [pipePressure, setPipePressure] = (0,react_.useState)(null);
    const [liquidLever, setLiquidLever] = (0,react_.useState)(null);
    const [tankPressureAI, setTankPreesureAI] = (0,react_.useState)(null);
    const [spare01AI, setSpare01AI] = (0,react_.useState)(null);
    const [spare02AI, setSpare02AI] = (0,react_.useState)(null);
    const [spare03AI, setSpare03AI] = (0,react_.useState)(null);
    const [spare04AI, setSpare04AI] = (0,react_.useState)(null);
    const [temprerature01AI, setTemperature01AI] = (0,react_.useState)(null);
    const [temprerature02AI, setTemperature02AI] = (0,react_.useState)(null);
    const [solenoido01Do, setSolenoid01Do] = (0,react_.useState)(null);
    const [timeUpdate, setTimeUpdate] = (0,react_.useState)(null);
    const [checkConnectData, setCheckConnectData] = (0,react_.useState)(false);
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj1 = {
            attrSubCmds: [],
            tsSubCmds: [
                {
                    entityType: "DEVICE",
                    entityId: IdDevice/* id_OTSUKA */.kx,
                    scope: "LATEST_TELEMETRY",
                    cmdId: 1
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                console.log("WebSocket connected");
                setCheckConnectData(true);
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj1));
                });
            };
            ws.current.onclose = ()=>{
                console.log("WebSocket connection closed.");
                setCheckConnectData(false);
            };
            return ()=>{
                console.log("Cleaning up WebSocket connection.");
                ws.current?.close();
            };
        }
    }, []);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (evt)=>{
                let dataReceived = JSON.parse(evt.data);
                if (dataReceived.update !== null) {
                    setData([
                        ...data,
                        dataReceived
                    ]);
                    const keys = Object.keys(dataReceived.data);
                    const stateMap = {
                        DI_MAP_1: setFlowRate,
                        DI_RESET: setPipePressure,
                        DI_SD_1: setLiquidLever,
                        DO_BC_01: setTankPreesureAI,
                        DI_SELECT_SW: setSpare01AI,
                        DI_UPS_ALARM: setSpare02AI,
                        DI_UPS_BATTERY: setSpare03AI,
                        DI_UPS_CHARGING: setSpare04AI,
                        DI_ZSC_1: setTemperature01AI,
                        DI_ZSC_2: setTemperature02AI,
                        DI_ZSO_1: setSolenoid01Do
                    };
                    keys.forEach((key)=>{
                        if (stateMap[key]) {
                            const value = dataReceived.data[key][0][1];
                            const slicedValue = value;
                            stateMap[key]?.(slicedValue);
                        }
                    });
                    if (keys.includes("time")) {
                        const timeUpdate = dataReceived.data["time"][0][1];
                        setTimeUpdate(timeUpdate);
                    }
                }
            };
        }
    }, [
        data
    ]);
    const ValueGas = {
        SVF: "SVF",
        GVF: "GVF",
        SVA: "SVA",
        GVA: "GVA"
    };
    const KeyGas = {
        SM3H: "SM3/H",
        M3H: "M3/H",
        SM3: "SM3",
        M3: "M3"
    };
    (0,react_.useEffect)(()=>{
        const updatedNodes = nodes.map((node)=>{
            if (node.id === "1a") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "black"
                                            },
                                            children: [
                                                ValueGas.SVF,
                                                " -"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "green"
                                            },
                                            children: [
                                                " ",
                                                flowRate,
                                                " "
                                            ]
                                        })
                                    ]
                                }),
                                KeyGas.SM3H
                            ]
                        })
                    }
                };
            }
            if (node.id === "1b") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "black"
                                            },
                                            children: [
                                                ValueGas.GVF,
                                                " -"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            style: {
                                                color: "green"
                                            },
                                            children: pipePressure
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: KeyGas.M3H
                                })
                            ]
                        })
                    }
                };
            }
            if (node.id === "1c") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "black"
                                            },
                                            children: [
                                                ValueGas.SVA,
                                                " -"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            style: {
                                                color: "green"
                                            },
                                            children: liquidLever
                                        })
                                    ]
                                }),
                                KeyGas.SM3
                            ]
                        })
                    }
                };
            }
            if (node.id === "1d") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "black"
                                            },
                                            children: [
                                                ValueGas.GVA,
                                                " -"
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            style: {
                                                color: "green"
                                            },
                                            children: tankPressureAI
                                        })
                                    ]
                                }),
                                KeyGas.M3
                            ]
                        })
                    }
                };
            }
            if (node.id === "2a") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "black"
                                            },
                                            children: [
                                                ValueGas.SVF,
                                                " -"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "green"
                                            },
                                            children: [
                                                " ",
                                                spare01AI,
                                                " "
                                            ]
                                        })
                                    ]
                                }),
                                KeyGas.SM3H
                            ]
                        })
                    }
                };
            }
            if (node.id === "2b") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "black"
                                            },
                                            children: [
                                                ValueGas.GVF,
                                                " -"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "green"
                                            },
                                            children: [
                                                " ",
                                                spare02AI,
                                                " "
                                            ]
                                        })
                                    ]
                                }),
                                KeyGas.M3H
                            ]
                        })
                    }
                };
            }
            if (node.id === "2c") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "black"
                                            },
                                            children: [
                                                ValueGas.SVA,
                                                " -"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "green"
                                            },
                                            children: [
                                                " ",
                                                spare03AI,
                                                " "
                                            ]
                                        })
                                    ]
                                }),
                                KeyGas.SM3
                            ]
                        })
                    }
                };
            }
            if (node.id === "2d") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    style: {
                                        display: "flex"
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "black"
                                            },
                                            children: [
                                                ValueGas.GVA,
                                                " -"
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            style: {
                                                color: "green"
                                            },
                                            children: [
                                                " ",
                                                spare04AI,
                                                " "
                                            ]
                                        })
                                    ]
                                }),
                                KeyGas.M3
                            ]
                        })
                    }
                };
            }
            if (node.id === "bara1") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                fontSize: 35,
                                fontWeight: 500,
                                display: "flex"
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                style: {
                                    color: "green",
                                    display: "flex",
                                    marginLeft: 20
                                },
                                children: [
                                    temprerature01AI?.slice(0, 4),
                                    " BARA"
                                ]
                            })
                        })
                    }
                };
            }
            if (node.id === "bara2") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                fontSize: 35,
                                fontWeight: 500,
                                display: "flex"
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                style: {
                                    color: "green",
                                    display: "flex",
                                    marginLeft: 20
                                },
                                children: [
                                    temprerature02AI?.slice(0, 4),
                                    " BARA"
                                ]
                            })
                        })
                    }
                };
            }
            if (node.id === "bara3") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                fontSize: 35,
                                fontWeight: 500,
                                display: "flex"
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                style: {
                                    color: "green",
                                    display: "flex",
                                    marginLeft: 20
                                },
                                children: [
                                    solenoido01Do?.slice(0, 4),
                                    " BARG"
                                ]
                            })
                        })
                    }
                };
            }
            if (node.id === "timeUpdate") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Last Update"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    style: {
                                        color: "green",
                                        display: "flex",
                                        marginLeft: 20
                                    },
                                    children: timeUpdate
                                })
                            ]
                        })
                    }
                };
            }
            if (node.id === "ConnectData") {
                return {
                    ...node,
                    data: {
                        ...node.data,
                        label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                fontSize: 40,
                                fontWeight: 500,
                                display: "flex",
                                padding: 10
                            },
                            children: checkConnectData ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                style: {},
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    style: {
                                        padding: 5,
                                        color: "green"
                                    },
                                    children: "CONNECTED"
                                })
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                style: {},
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    style: {
                                        padding: 5,
                                        color: "red"
                                    },
                                    children: "DISCONNECT"
                                })
                            })
                        })
                    }
                };
            }
            return node;
        });
        setNodes(updatedNodes);
    }, [
        flowRate,
        pipePressure
    ]);
    const storedPositionString = localStorage.getItem("positions");
    const initialPositions = storedPositionString ? JSON.parse(storedPositionString) : {
        ConnectData: {
            x: 208,
            y: -191
        },
        FIQ: {
            x: 981.2251539415981,
            y: 257.1013591338559
        },
        FIQ2: {
            x: 1226.1465266939656,
            y: 726.6350071962734
        },
        TankSVG: {
            x: 385.07262836525877,
            y: 277.9478545543576
        },
        bara1: {
            x: 484.3049129189668,
            y: 137.40231270294777
        },
        bara2: {
            x: 812.4155143100833,
            y: 549.6845581780644
        },
        bara3: {
            x: 1696.691591708324,
            y: 184.59079367738252
        },
        coupling: {
            x: 1023.0081198522901,
            y: 475.897562474152
        },
        coupling2: {
            x: 1222,
            y: 258
        },
        gasout: {
            x: 2208.0977013919046,
            y: 501
        },
        gauges: {
            x: 781.7512871049225,
            y: 218.79590743621344
        },
        gauges2: {
            x: 782.2030149904368,
            y: 687.8553699550267
        },
        gauges3: {
            x: 1860.8894273127753,
            y: 320.77797356828194
        },
        halfCricle: {
            x: 208.76511323364036,
            y: 106.11892503762641
        },
        halfCricle2: {
            x: 2069.3257850544323,
            y: 134.44178854694428
        },
        pipeEnd: {
            x: 1628.0073170731707,
            y: 327.44634146341457
        },
        pipeEnd2: {
            x: 1627,
            y: 627.9926829268292
        },
        pipeMark: {
            x: 585.8373981032122,
            y: 499.5746838226502
        },
        pipeMark2: {
            x: 1431,
            y: 503
        },
        pipeMark3: {
            x: 1824,
            y: 501
        },
        pipeSVD: {
            x: 368.0514839198503,
            y: 630.7105280371044
        },
        pipeSmall: {
            x: 171.08770377058852,
            y: 825.3606829381719
        },
        pipeSmall2: {
            x: 385.9928793215362,
            y: 825.6382385547478
        },
        position1: {
            x: 865.6323620672963,
            y: -192
        },
        position2: {
            x: 821,
            y: 850
        },
        sation: {
            x: 135.66390840327284,
            y: 650.8221976174074
        },
        timeUpdate: {
            x: 1600.9121951219513,
            y: -191.17073170731666
        }
    };
    const [positions, setPositions] = (0,react_.useState)(initialPositions);
    const [editingEnabled, setEditingEnabled] = (0,react_.useState)(false);
    const [initialNodes, setInitialNodes] = (0,react_.useState)([
        {
            id: "station",
            position: positions.sation,
            type: "custom",
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                fontSize: 20,
                                color: "green",
                                fontWeight: 500
                            }
                        }),
                        station
                    ]
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "pipeSmall",
            position: positions.pipeSmall,
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(BallValue01, {}),
                        " ",
                        pipeSmall
                    ]
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "pipeSmall2",
            position: positions.pipeSmall2,
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx(BallValue02_BallValue01, {}),
                        " ",
                        pipeSmall
                    ]
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "pipeSVD",
            position: positions.pipeSVD,
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                            style: {
                                fontSize: 20
                            },
                            children: [
                                " ",
                                /*#__PURE__*/ jsx_runtime_.jsx(SDV_Otsuka, {})
                            ]
                        }),
                        pipeSDV
                    ]
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "TankSVG",
            position: positions.TankSVG,
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        " ",
                        tankSVG
                    ]
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "halfCricle",
            position: positions.halfCricle,
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        " ",
                        halfCricle
                    ]
                })
            }
        },
        {
            id: "pipeMark",
            position: positions.pipeMark,
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        " ",
                        pipeMark
                    ]
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "gauges",
            position: positions.gauges,
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                fontSize: 30,
                                fontWeight: 500
                            },
                            children: "PT"
                        }),
                        gauges
                    ]
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "gauges2",
            position: positions.gauges2,
            data: {
                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                fontSize: 30,
                                fontWeight: 500
                            },
                            children: "PT"
                        }),
                        gauges
                    ]
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "FIQ",
            position: positions.FIQ,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 25
                        },
                        children: "FIQ-1501"
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "FIQ2",
            position: positions.FIQ2,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 25
                        },
                        children: "FIQ-1502"
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "1",
            position: positions.position1,
            type: "custom",
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 30
                        }
                    })
                })
            },
            style: {
                width: 600,
                height: 290
            },
            sourcePosition: esm/* Position */.Ly.Bottom,
            targetPosition: esm/* Position */.Ly.Bottom
        },
        {
            id: "1a",
            data: {
                label: ""
            },
            position: {
                x: 5,
                y: 5
            },
            parentNode: "1",
            style: {
                width: "590px",
                height: "70px"
            }
        },
        {
            id: "1b",
            data: {
                label: ""
            },
            position: {
                x: 5,
                y: 75
            },
            parentNode: "1",
            style: {
                width: "590px",
                height: "70px"
            }
        },
        {
            id: "1c",
            data: {
                label: ""
            },
            position: {
                x: 5,
                y: 145
            },
            parentNode: "1",
            style: {
                width: "590px",
                height: "70px"
            }
        },
        {
            id: "1d",
            data: {
                label: ""
            },
            position: {
                x: 5,
                y: 215
            },
            parentNode: "1",
            style: {
                width: "590px",
                height: "70px"
            }
        },
        {
            id: "2",
            position: positions.position2,
            type: "custom",
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 30
                        }
                    })
                })
            },
            style: {
                width: 600,
                height: 290
            },
            sourcePosition: esm/* Position */.Ly.Top,
            targetPosition: esm/* Position */.Ly.Top
        },
        {
            id: "2a",
            data: {
                label: ""
            },
            position: {
                x: 5,
                y: 5
            },
            parentNode: "2",
            style: {
                width: "590px",
                height: "70px"
            }
        },
        {
            id: "2b",
            data: {
                label: ""
            },
            position: {
                x: 5,
                y: 75
            },
            parentNode: "2",
            style: {
                width: "590px",
                height: "70px"
            }
        },
        {
            id: "2c",
            data: {
                label: ""
            },
            position: {
                x: 5,
                y: 145
            },
            parentNode: "2",
            style: {
                width: "590px",
                height: "70px"
            }
        },
        {
            id: "2d",
            data: {
                label: ""
            },
            position: {
                x: 5,
                y: 215
            },
            parentNode: "2",
            style: {
                width: "590px",
                height: "70px"
            }
        },
        {
            id: "coupling",
            position: positions.coupling,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: markPipe
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "coupling2",
            position: positions.coupling2,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: markPipe
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "pipeMark2",
            position: positions.pipeMark2,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: pipeMark
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "pipeEnd",
            position: positions.pipeEnd,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        style: {
                            fontSize: 23,
                            fontWeight: 500
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(PCV_01_Otsuka, {}),
                            pipeEnd
                        ]
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "pipeEnd2",
            position: positions.pipeEnd2,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        style: {
                            fontSize: 23,
                            fontWeight: 500
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(PCV_02_Otsuka, {}),
                            pipeEnd
                        ]
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "gauges3",
            position: positions.gauges3,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                style: {
                                    fontSize: 30,
                                    fontWeight: 500
                                },
                                children: "PT"
                            }),
                            gauges
                        ]
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Right
        },
        {
            id: "halfCricle2",
            position: positions.halfCricle2,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(PSV_02_Otsuka, {})
                            }),
                            halfCricle
                        ]
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Bottom,
            targetPosition: esm/* Position */.Ly.Bottom
        },
        {
            id: "pipeMark3",
            position: positions.pipeMark3,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: pipeMark
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "gasout",
            position: positions.gasout,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: gasOut
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Left
        },
        {
            id: "bara1",
            position: positions.bara1,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: gasOut
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Right,
            style: {
                width: "300px",
                height: "70px"
            }
        },
        {
            id: "bara2",
            position: positions.bara2,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: gasOut
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Bottom,
            style: {
                width: "300px",
                height: "70px"
            }
        },
        {
            id: "bara3",
            position: positions.bara3,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        style: {
                            fontSize: 20,
                            fontWeight: 500
                        },
                        children: gasOut
                    })
                })
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Right,
            style: {
                width: "300px",
                height: "70px"
            }
        },
        {
            id: "timeUpdate",
            position: positions.timeUpdate,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {})
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Right,
            style: {
                width: "730px"
            }
        },
        {
            id: "ConnectData",
            position: positions.ConnectData,
            data: {
                label: /*#__PURE__*/ jsx_runtime_.jsx("div", {})
            },
            sourcePosition: esm/* Position */.Ly.Right,
            targetPosition: esm/* Position */.Ly.Right,
            style: {
                width: "300px"
            }
        }
    ]);
    const [nodes, setNodes, onNodesChange] = (0,esm/* useNodesState */.Rr)(initialNodes);
    const [edges, setEdges, onEdgesChange] = (0,esm/* useEdgesState */.ll)(initialEdges);
    const onNodeDragStop = (0,react_.useCallback)((event, node)=>{
        if (editingEnabled) {
            const { id, position } = node;
            setNodes((prevNodes)=>prevNodes.map((n)=>n.id === id ? {
                        ...n,
                        position: position
                    } : n));
            if (id === "1") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        position1: position
                    }));
            } else if (id === "coupling") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        coupling: position
                    }));
            } else if (id === "station") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        sation: position
                    }));
            } else if (id === "pipeSVD") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        pipeSVD: position
                    }));
            } else if (id === "TankSVG") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        TankSVG: position
                    }));
            } else if (id === "halfCricle") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        halfCricle: position
                    }));
            } else if (id === "pipeMark") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        pipeMark: position
                    }));
            } else if (id === "pipeSmall") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        pipeSmall: position
                    }));
            } else if (id === "pipeSmall2") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        pipeSmall2: position
                    }));
            } else if (id === "gauges") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        gauges: position
                    }));
            } else if (id === "gauges2") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        gauges2: position
                    }));
            } else if (id === "FIQ") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        FIQ: position
                    }));
            } else if (id === "FIQ2") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        FIQ2: position
                    }));
            } else if (id === "3") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        coupling2: position
                    }));
            } else if (id === "pipeMark2") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        pipeMark2: position
                    }));
            } else if (id === "pipeEnd") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        pipeEnd: position
                    }));
            } else if (id === "pipeEnd2") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        pipeEnd2: position
                    }));
            } else if (id === "gauges3") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        gauges3: position
                    }));
            } else if (id === "halfCricle2") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        halfCricle2: position
                    }));
            } else if (id === "pipeMark3") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        pipeMark3: position
                    }));
            } else if (id === "gasout") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        gasout: position
                    }));
            } else if (id === "bara1") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        bara1: position
                    }));
            } else if (id === "bara2") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        bara2: position
                    }));
            } else if (id === "bara3") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        bara3: position
                    }));
            } else if (id === "timeUpdate") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        timeUpdate: position
                    }));
            } else if (id === "ConnectData") {
                setPositions((prevPositions)=>({
                        ...prevPositions,
                        ConnectData: position
                    }));
            }
        }
    }, [
        setNodes,
        setPositions,
        editingEnabled
    ]);
    (0,react_.useEffect)(()=>{
        localStorage.setItem("positions", JSON.stringify(positions));
    }, [
        positions
    ]);
    const toggleEditing = ()=>{
        setEditingEnabled(!editingEnabled);
    };
    const paragraphContents = {
        SVF: "Standard Volume Flow Rate",
        GVF: "Gross Volume Flow Rate",
        SVA: "Standard Volume Accumulated",
        GVA: "Gross Volume Accumulated",
        PT: "Pressure Transmitter",
        PSV: "Pressure Safety Valve",
        PCV: "Pressure Control Valve",
        SSV: "Slam Shut Off Valve",
        SDV: "Shutdown valve"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(toast_cjs/* Toast */.F, {
                ref: toast
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(confirmdialog_cjs/* ConfirmDialog */.QH, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                onClick: toggleEditing,
                children: editingEnabled ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: "SAVE"
                }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    children: "EDIT"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    padding: 15,
                    display: "flex",
                    justifyContent: "space-between"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                fontSize: 25,
                                fontWeight: 500
                            },
                            children: "EWON OTSUKA"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            width: 25,
                            height: 30,
                            textAlign: "center",
                            cursor: "pointer"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                style: {
                                    border: "2px solid black",
                                    borderRadius: 50,
                                    fontWeight: 600
                                },
                                onClick: (e)=>op.current?.toggle(e),
                                children: "?"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(overlaypanel_cjs/* OverlayPanel */.T, {
                                style: {
                                    width: 400,
                                    fontWeight: 500,
                                    fontSize: 17
                                },
                                ref: op,
                                children: Object.keys(paragraphContents).map((key, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            key,
                                            " - ",
                                            paragraphContents[key],
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                                        ]
                                    }, index))
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    width: "100%",
                    height: "100vh",
                    position: "relative",
                    overflow: "hidden",
                    alignItems: "center"
                },
                children: [
                    !editingEnabled && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            position: "absolute",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%",
                            backgroundColor: "rgba(0, 0, 0, 0.02)",
                            zIndex: 999,
                            opacity: 0.2
                        }
                    }),
                    editingEnabled && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        style: {
                            position: "absolute",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%"
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(esm/* ReactFlow */.x$, {
                        nodes: nodes,
                        edges: edges,
                        onNodesChange: onNodesChange,
                        onEdgesChange: onEdgesChange,
                        onNodeDragStop: onNodeDragStop,
                        fitView: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(dist_esm/* Background */.A, {
                            style: {
                                backgroundColor: "gray"
                            }
                        })
                    })
                ]
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/(main)/OTSUKA/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 



const TabOtsuka = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            style: {
                width: "100%"
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(tabview_cjs/* TabView */.xf, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(tabview_cjs/* TabPanel */.x4, {
                        header: "Graphic",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(App, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(tabview_cjs/* TabPanel */.x4, {
                        header: "Telemetry",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(telemetryOTSUKA, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const page = (TabOtsuka);


/***/ }),

/***/ 90063:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c4: () => (/* binding */ id_THACHTHAT),
/* harmony export */   d3: () => (/* binding */ id_IGUECU),
/* harmony export */   kx: () => (/* binding */ id_OTSUKA)
/* harmony export */ });
/* unused harmony exports id_YOSHINO, id_SPMCV, id_NITORI, id_ARAKAWA, id_SNG_HungYen, id_SNG_BinhDuong, id_SNG, id_CNG_HungYen, id_CNG_PRU, id_CNG_BinhDuong, id_LGDS, id_ZOCV, id_VREC, id_KOA */
const id_OTSUKA = "28f7e830-a3ce-11ee-9ca1-8f006c3fce43";
const id_THACHTHAT = "28e76d70-a3ce-11ee-9ca1-8f006c3fce43";
const id_IGUECU = "28af6d80-a3ce-11ee-9ca1-8f006c3fce43";
const id_SNG_HungYen = "28f1a6a0-a3ce-11ee-9ca1-8f006c3fce43";
const id_SNG_BinhDuong = "28e375d0-a3ce-11ee-9ca1-8f006c3fce43";
const id_SNG = "28db8690-a3ce-11ee-9ca1-8f006c3fce43";
const id_CNG_HungYen = "28dcbf10-a3ce-11ee-9ca1-8f006c3fce43";
const id_CNG_PRU = "28cedc60-a3ce-11ee-9ca1-8f006c3fce43";
const id_CNG_BinhDuong = "28d37040-a3ce-11ee-9ca1-8f006c3fce43";
const id_LGDS = "28cf2a80-a3ce-11ee-9ca1-8f006c3fce43";
const id_ZOCV = "28ca96a0-a3ce-11ee-9ca1-8f006c3fce43";
const id_VREC = "28c3dfe0-a3ce-11ee-9ca1-8f006c3fce43";
const id_KOA = "28c391c1-a3ce-11ee-9ca1-8f006c3fce43";
const id_YOSHINO = "28c31c90-a3ce-11ee-9ca1-8f006c3fce43";
const id_SPMCV = "28b009c0-a3ce-11ee-9ca1-8f006c3fce43";
const id_NITORI = "28afe2b0-a3ce-11ee-9ca1-8f006c3fce43";
const id_ARAKAWA = "28af9490-a3ce-11ee-9ca1-8f006c3fce43";
 // export for name guest
 //export for SNG
 //export for CNG



/***/ }),

/***/ 92547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90284);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18176);
/* harmony import */ var primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63579);
/* harmony import */ var primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23064);
/* harmony import */ var primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63862);
/* harmony import */ var primereact_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7666);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6538);
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AppConfig = (props)=>{
    const { layoutConfig, setLayoutConfig, layoutState, setLayoutState, isSlim, isSlimPlus, isHorizontal } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__/* .LayoutContext */ .V);
    const { changeTheme } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(primereact_api__WEBPACK_IMPORTED_MODULE_3__.PrimeReactContext);
    const scales = [
        12,
        13,
        14,
        15,
        16
    ];
    const componentThemes = [
        {
            name: "indigo",
            color: "#6366F1"
        },
        {
            name: "blue",
            color: "#3B82F6"
        },
        {
            name: "purple",
            color: "#8B5CF6"
        },
        {
            name: "teal",
            color: "#14B8A6"
        },
        {
            name: "cyan",
            color: "#06b6d4"
        },
        {
            name: "green",
            color: "#10b981"
        },
        {
            name: "orange",
            color: "#f59e0b"
        },
        {
            name: "pink",
            color: "#d946ef"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isSlim() || isSlimPlus() || isHorizontal()) {
            setLayoutState((prevState)=>({
                    ...prevState,
                    resetMenu: true
                }));
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.menuMode
    ]);
    const onConfigButtonClick = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: true
            }));
    };
    const onConfigSidebarHide = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: false
            }));
    };
    const changeInputStyle = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                inputStyle: e.value
            }));
    };
    const changeRipple = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                ripple: e.value
            }));
    };
    const changeMenuMode = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuMode: e.value
            }));
    };
    const changeMenuTheme = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuTheme: e.value
            }));
    };
    const changeColorScheme = (colorScheme)=>{
        changeTheme?.(layoutConfig.colorScheme, colorScheme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    colorScheme
                }));
        });
    };
    const _changeTheme = (theme)=>{
        changeTheme?.(layoutConfig.theme, theme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    theme
                }));
        });
    };
    const decrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale - 1
            }));
    };
    const incrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale + 1
            }));
    };
    const applyScale = ()=>{
        document.documentElement.style.fontSize = layoutConfig.scale + "px";
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        applyScale();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.scale
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "layout-config-button config-link",
                type: "button",
                onClick: onConfigButtonClick,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "pi pi-cog"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__/* .Sidebar */ .Y, {
                visible: layoutState.configSidebarVisible,
                onHide: onConfigSidebarHide,
                position: "right",
                className: "layout-config-sidebar w-18rem",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Themes"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap row-gap-3",
                        children: componentThemes.map((theme, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    className: "cursor-pointer p-link w-2rem h-2rem border-circle flex-shrink-0 flex align-items-center justify-content-center",
                                    onClick: ()=>_changeTheme(theme.name),
                                    style: {
                                        backgroundColor: theme.color
                                    },
                                    children: theme.name == layoutConfig.theme && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "pi pi-check text-white"
                                    })
                                })
                            }, i);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Scale"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex align-items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-minus",
                                type: "button",
                                onClick: decrementScale,
                                className: "w-2rem h-2rem mr-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[0]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex gap-2 align-items-center",
                                children: scales.map((s, i)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: (0,primereact_utils__WEBPACK_IMPORTED_MODULE_6__.classNames)("pi pi-circle-fill text-300", {
                                            "text-primary-500": s === layoutConfig.scale
                                        })
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-plus",
                                type: "button",
                                onClick: incrementScale,
                                className: "w-2rem h-2rem ml-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[scales.length - 1]
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Type"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap row-gap-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "static",
                                                checked: layoutConfig.menuMode === "static",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode1",
                                                children: "Static"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "overlay",
                                                checked: layoutConfig.menuMode === "overlay",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode2",
                                                children: "Overlay"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim",
                                                checked: layoutConfig.menuMode === "slim",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode3"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode3",
                                                children: "Slim"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim-plus",
                                                checked: layoutConfig.menuMode === "slim-plus",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode4"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode4",
                                                children: "Slim +"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "drawer",
                                                checked: layoutConfig.menuMode === "drawer",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode7"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode7",
                                                children: "Drawer"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "reveal",
                                                checked: layoutConfig.menuMode === "reveal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode6",
                                                children: "Reveal"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "horizontal",
                                                checked: layoutConfig.menuMode === "horizontal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode5",
                                                children: "Horizontal"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Theme"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "colorScheme",
                                        checked: layoutConfig.menuTheme === "colorScheme",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-colorscheme"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-colorscheme",
                                        children: "Color Scheme"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "primaryColor",
                                        checked: layoutConfig.menuTheme === "primaryColor",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-primarycolor"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-primarycolor",
                                        children: "Primary Color"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "transparent",
                                        checked: layoutConfig.menuTheme === "transparent",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-transparent"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-transparent",
                                        children: "Transparent"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Color Scheme"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "light",
                                checked: layoutConfig.colorScheme === "light",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-light"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-light",
                                children: "Light"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dim",
                                checked: layoutConfig.colorScheme === "dim",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dim"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dim",
                                children: "Dim"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dark",
                                checked: layoutConfig.colorScheme === "dark",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dark"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dark",
                                children: "Dark"
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Input Style"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "outlined",
                                                checked: layoutConfig.inputStyle === "outlined",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "outlined_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "outlined_input",
                                                children: "Outlined"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "filled",
                                                checked: layoutConfig.inputStyle === "filled",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "filled_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "filled_input",
                                                children: "Filled"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Ripple Effect"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__/* .InputSwitch */ .Q, {
                                checked: layoutConfig.ripple,
                                onChange: changeRipple
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppConfig);


/***/ }),

/***/ 98602:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\OTSUKA\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 96035:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,7933,1042,6903,4719,4524,5129,1501,6408,1003,1993,1459,4760,6120,590,4230,1184,2558,7785,6065,4972], () => (__webpack_exec__(85173)));
module.exports = __webpack_exports__;

})();