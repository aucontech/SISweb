(() => {
var exports = {};
exports.id = 1989;
exports.ids = [1989];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 12989:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'OTSUKA',
        {
        children: [
        'graphic-otk',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1853)), "D:\\sogec\\sogec-web\\app\\(main)\\OTSUKA\\graphic-otk\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\OTSUKA\\graphic-otk\\page.tsx"];
    
    const originalPathname = "/(main)/OTSUKA/graphic-otk/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 47540:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 97581))

/***/ }),

/***/ 97581:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./app/(main)/OTSUKA/graphic-otk/graphic-OTK.css
var graphic_OTK = __webpack_require__(95083);
// EXTERNAL MODULE: ./service/localStorage.ts
var localStorage = __webpack_require__(40365);
// EXTERNAL MODULE: ./app/(main)/data-table-device/ID-DEVICE/IdDevice.tsx
var IdDevice = __webpack_require__(90063);
;// CONCATENATED MODULE: ./app/(main)/OTSUKA/graphic-otk/Data-OTK.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




function DataOTK() {
    const [data, setData] = (0,react_.useState)([]);
    const token = (0,localStorage/* readToken */.YG)();
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/telemetry?token="}${token}`;
    const [flowRate, setFlowRate] = (0,react_.useState)(null);
    const [pipePressure, setPipePressure] = (0,react_.useState)(null);
    const [liquidLever, setLiquidLever] = (0,react_.useState)(null);
    const [tankPressureAI, setTankPreesureAI] = (0,react_.useState)(null);
    const [spare01AI, setSpare01AI] = (0,react_.useState)(null);
    const [spare02AI, setSpare02AI] = (0,react_.useState)(null);
    const [spare03AI, setSpare03AI] = (0,react_.useState)(null);
    const [spare04AI, setSpare04AI] = (0,react_.useState)(null);
    const [temprerature01AI, setTemperature01AI] = (0,react_.useState)(null);
    const [temprerature02AI, setTemperature02AI] = (0,react_.useState)(null);
    const [solenoido01Do, setSolenoid01Do] = (0,react_.useState)(null);
    const [timeUpdate, setTimeUpdate] = (0,react_.useState)(null);
    const ws = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj1 = {
            attrSubCmds: [],
            tsSubCmds: [
                {
                    entityType: "DEVICE",
                    entityId: IdDevice/* id_OTSUKA */.kx,
                    scope: "LATEST_TELEMETRY",
                    cmdId: 1
                }
            ]
        };
        if (ws.current) {
            ws.current.onopen = ()=>{
                console.log("WebSocket connected");
                setTimeout(()=>{
                    ws.current?.send(JSON.stringify(obj1));
                });
            };
            ws.current.onclose = ()=>{
                console.log("WebSocket connection closed.");
            };
            return ()=>{
                console.log("Cleaning up WebSocket connection.");
                ws.current?.close();
            };
        }
    }, [
        url
    ]);
    (0,react_.useEffect)(()=>{
        if (ws.current) {
            ws.current.onmessage = (evt)=>{
                let dataReceived = JSON.parse(evt.data);
                if (dataReceived.update !== null) {
                    setData([
                        ...data,
                        dataReceived
                    ]);
                    const keys = Object.keys(dataReceived.data);
                    const stateMap = {
                        Flow_Rate_AI: setFlowRate,
                        Pipe_Pressure_AI: setPipePressure,
                        Liquid_Level_AI: setLiquidLever,
                        Tank_Pressure_AI: setTankPreesureAI,
                        Spare_01_AI: setSpare01AI,
                        Spare_02_AI: setSpare02AI,
                        Spare_03_AI: setSpare03AI,
                        Spare_04_AI: setSpare04AI,
                        Temperature_01_AI: setTemperature01AI,
                        Temperature_02_AI: setTemperature02AI,
                        Solenoid_01_DO: setSolenoid01Do
                    };
                    keys.forEach((key)=>{
                        if (stateMap[key]) {
                            const value = dataReceived.data[key][0][1];
                            const slicedValue = value.slice(0, 6);
                            stateMap[key]?.(slicedValue);
                        }
                    });
                    if (keys.includes("Flow_Rate_AI")) {
                        const timeUpdate = dataReceived.data["time"][0][1];
                        setTimeUpdate(timeUpdate);
                    }
                }
            };
        }
    }, [
        data
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("text", {
                x: "980",
                y: "40",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerTime",
                id: "UID_1701153734203",
                children: [
                    "Last update ",
                    timeUpdate
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "650",
                y: "120",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: flowRate
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "650",
                y: "155",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: pipePressure
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "650",
                y: "190",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: liquidLever
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "650",
                y: "225",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: tankPressureAI
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "650",
                y: "575",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: spare01AI
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "650",
                y: "610",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: spare02AI
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "650",
                y: "645",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: spare03AI
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "650",
                y: "680",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: spare04AI
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "410",
                y: "120",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: temprerature01AI
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "610",
                y: "400",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: temprerature02AI
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "1035",
                y: "256",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainer",
                id: "UID_1701153734203",
                children: solenoido01Do
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "570",
                y: "120",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "FRA :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "570",
                y: "155",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "PPA :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "570",
                y: "190",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "LLA :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "570",
                y: "225",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "TPA :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "570",
                y: "575",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "S01A :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "570",
                y: "610",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "S02A :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "570",
                y: "645",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "S03A:"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "570",
                y: "680",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "S04A :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "335",
                y: "120",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "T01A :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "530",
                y: "400",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "T02A :"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "955",
                y: "256",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerName",
                id: "UID_1701153734203",
                children: "S01D :"
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/(main)/OTSUKA/graphic-otk/TextGraphic.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


function TextGraphic() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "150",
                y: "430",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerText",
                id: "UID_1701153734203",
                children: "SDV-1001"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "940",
                y: "350",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerText",
                id: "UID_1701153734203",
                children: "SVD-1002"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("text", {
                x: "940",
                y: "535",
                transform: "matrix(1 0 0 1 -19.130434036254883 -4.202898333038109)",
                className: "nativeContainerText",
                id: "UID_1701153734203",
                children: "SVD-1003"
            })
        ]
    });
}

// EXTERNAL MODULE: ./node_modules/primereact/overlaypanel/overlaypanel.cjs.js
var overlaypanel_cjs = __webpack_require__(98063);
;// CONCATENATED MODULE: ./app/(main)/OTSUKA/graphic-otk/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





function GraphicOTK() {
    const op = (0,react_.useRef)(null);
    const paragraphContents = {
        SVF: "Standard Volume Flow Rate",
        GVF: "Gross Volume Flow Rate",
        SVA: "Standard Volume Accumulated",
        GVA: "Gross Volume Accumulated",
        PT: "Pressure Transmitter",
        PSV: "Pressure Safety Valve",
        PCV: "Pressure Control Valve",
        SSV: "Slam Shut Off Valve",
        SDV: "Shutdown valve"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                style: {
                    padding: 15,
                    display: "flex",
                    justifyContent: "space-between"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            style: {
                                fontSize: 25,
                                fontWeight: 500
                            },
                            children: "EWON OTSUKA"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            width: 25,
                            height: 30,
                            textAlign: "center",
                            cursor: "pointer"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                style: {
                                    border: "2px solid black",
                                    borderRadius: 50,
                                    fontWeight: 600
                                },
                                onClick: (e)=>op.current?.toggle(e),
                                children: [
                                    " ",
                                    "?"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(overlaypanel_cjs/* OverlayPanel */.T, {
                                style: {
                                    width: 400,
                                    fontWeight: 500,
                                    fontSize: 17
                                },
                                ref: op,
                                children: Object.keys(paragraphContents).map((key, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                        children: [
                                            " ",
                                            key,
                                            " - ",
                                            paragraphContents[key],
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                                        ]
                                    }, index))
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    background: "#87CEEB",
                    borderRadius: 2,
                    boxShadow: "0 0 10px rgba(0, 0, 0, 2)"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    contentScriptType: "text/ecmascript",
                    zoomAndPan: "magnify",
                    contentStyleType: "text/css",
                    version: "1.0",
                    preserveAspectRatio: "xMidYMid meet",
                    viewBox: "0 0 1366 740",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("defs", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    id: "svg_2",
                                    viewBox: "0 0 512 512",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m236.73,269.72c7.93,0 33.75,19.07 33.75,37.85c0,18.79 -25.82,14.68 -33.75,14.68l0,-52.53z",
                                            fill: "#FF5959",
                                            id: "svg_1"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m236.73,269.72l0,52.53c3.26,0 9.55,0.69 15.83,0.2l0,-44.39c-6.28,-5.11 -12.57,-8.34 -15.83,-8.34z",
                                            "enable-background": "new",
                                            id: "svg_4",
                                            opacity: "0.2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m101.63,269.72c-7.93,0 -33.75,19.07 -33.75,37.85c0,18.79 25.82,14.68 33.75,14.68l0,-52.53z",
                                            fill: "#00AD68",
                                            id: "svg_5"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m101.63,269.72l0,52.53c-3.26,0 -9.56,0.69 -15.83,0.2l0,-44.39c6.28,-5.11 12.57,-8.34 15.83,-8.34z",
                                            "enable-background": "new",
                                            id: "svg_6",
                                            opacity: "0.2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m482.04,41.03c0,-5.83 -4.76,-10.59 -10.58,-10.59l-431.27,0c-5.83,0 -10.59,4.76 -10.59,10.59l0,93.06c0,5.82 4.76,10.58 10.59,10.58l431.26,0c5.83,0 10.59,-4.76 10.59,-10.58l0,-93.06z",
                                            fill: "#00AD68",
                                            id: "svg_7"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m242.11,457.7l0,-200.03c0,-6.46 -5.28,-11.74 -11.74,-11.74l-122.39,0c-6.45,0 -11.73,5.28 -11.73,11.74l0,200.03l145.86,0z",
                                            fill: "#333E48",
                                            id: "svg_8"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            fill: "#D1D3D3",
                                            height: "91.2",
                                            id: "svg_9",
                                            width: "145.87",
                                            x: "96.25",
                                            y: "366.51"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                            id: "svg_10",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                    fill: "#A4A9AD",
                                                    height: "41.34",
                                                    id: "svg_11",
                                                    width: "16.94",
                                                    x: "124.24",
                                                    y: "416.36"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                    fill: "#A4A9AD",
                                                    height: "41.34",
                                                    id: "svg_12",
                                                    width: "16.94",
                                                    x: "197.18",
                                                    y: "416.36"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            fill: "#FFFFFF",
                                            height: "31.61",
                                            id: "svg_13",
                                            width: "87.29",
                                            x: "125.53",
                                            y: "280.42"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            fill: "#D1D3D3",
                                            height: "313.88",
                                            id: "svg_14",
                                            width: "88.91",
                                            x: "344.91",
                                            y: "143.83"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            height: "32.99",
                                            id: "svg_15",
                                            opacity: "0.1",
                                            width: "88.91",
                                            x: "344.91",
                                            y: "143.83"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            height: "25.23",
                                            id: "svg_16",
                                            opacity: "0.1",
                                            width: "88.91",
                                            x: "344.91",
                                            y: "313.89"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m453.94,457.7l0,-119.99c0,-5.82 -4.77,-10.59 -10.59,-10.59l-107.97,0c-5.82,0 -10.58,4.77 -10.58,10.59l0,119.99l129.14,0z",
                                            fill: "#A4A9AD",
                                            id: "svg_17"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                                            fill: "#FFB819",
                                            id: "svg_18",
                                            points: "180.466,30.442 123.35,30.442 59.284,144.67 116.399,144.67 "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                                            fill: "#F2D383",
                                            id: "svg_19",
                                            points: "237.58,30.442 180.466,30.442 116.399,144.67 173.515,144.67 "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            fill: "#00AD68",
                                            height: "50.58",
                                            id: "svg_20",
                                            width: "72.94",
                                            x: "96.25",
                                            y: "343.87"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            fill: "#FF5959",
                                            height: "50.58",
                                            id: "svg_21",
                                            width: "72.94",
                                            x: "169.18",
                                            y: "343.87"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m387.78,117.53c11.61,0 21.02,-9.41 21.02,-21.02s-21.02,-36.7 -21.02,-36.7s-21.01,25.09 -21.01,36.7s9.4,21.02 21.01,21.02z",
                                            fill: "#FFB819",
                                            id: "svg_22"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m504.06,477.28c0,2.35 -1.92,4.28 -4.27,4.28l-487.58,0c-2.35,0 -4.27,-1.93 -4.27,-4.28l0,-15.3c0,-2.35 1.92,-4.28 4.27,-4.28l487.58,0c2.35,0 4.27,1.93 4.27,4.28l0,15.3z",
                                            fill: "#333E48",
                                            id: "svg_23"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                            id: "svg_24",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m146.71,373.43l-28,0c-4.38,0 -7.94,-3.55 -7.94,-7.94c0,-4.38 3.56,-7.94 7.94,-7.94l28,0c4.39,0 7.94,3.56 7.94,7.94c0,4.39 -3.55,7.94 -7.94,7.94z",
                                                    fill: "#FFFFFF",
                                                    id: "svg_25"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m219.65,373.43l-28,0c-4.39,0 -7.94,-3.55 -7.94,-7.94c0,-4.38 3.55,-7.94 7.94,-7.94l28,0c4.38,0 7.94,3.56 7.94,7.94c0,4.39 -3.56,7.94 -7.94,7.94z",
                                                    fill: "#FFFFFF",
                                                    id: "svg_26"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                            id: "svg_27",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "389.37",
                                                    cy: "356.22",
                                                    fill: "#D1D3D3",
                                                    id: "svg_28",
                                                    r: "7.41"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "352.85",
                                                    cy: "356.22",
                                                    fill: "#D1D3D3",
                                                    id: "svg_29",
                                                    r: "7.41"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("circle", {
                                                    cx: "425.89",
                                                    cy: "356.22",
                                                    fill: "#D1D3D3",
                                                    id: "svg_30",
                                                    r: "7.41"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m499.79,449.76l-37.91,0l0,-112.05c0,-10.21 -8.32,-18.52 -18.53,-18.52l-1.59,0l0,-166.58l29.7,0c10.21,0 18.52,-8.31 18.52,-18.52l0,-93.06c0,-10.22 -8.31,-18.53 -18.52,-18.53l-431.27,0c-10.22,0 -18.53,8.31 -18.53,18.53l0,93.06c0,10.21 8.31,18.52 18.53,18.52l296.78,0l0,166.58l-1.59,0c-10.21,0 -18.52,8.31 -18.52,18.52l0,112.05l-66.81,0l0,-56.7c5.96,-2.52 10.97,-6.85 14.71,-12.78c4.89,-7.73 7.71,-18.38 8.18,-30.81c0.31,-8.22 -0.42,-16.95 -2.05,-25.15c0.42,-0.34 0.84,-0.7 1.24,-1.08c4.12,-3.93 6.29,-9.34 6.29,-15.67c0,-11.26 -6.64,-21.12 -12.21,-27.41c-4.67,-5.28 -10.55,-10.19 -16.16,-13.6l0,-8.89c0,-10.85 -8.82,-19.68 -19.67,-19.68l-122.4,0c-10.85,0 -19.67,8.83 -19.67,19.68l0,8.89c-5.6,3.41 -11.48,8.32 -16.16,13.6c-5.57,6.29 -12.21,16.15 -12.21,27.41c0,6.33 2.17,11.74 6.29,15.67c0.4,0.38 0.82,0.74 1.24,1.08c-1.62,8.2 -2.36,16.93 -2.05,25.15c0.47,12.43 3.3,23.08 8.18,30.81c3.74,5.93 8.76,10.26 14.71,12.78l0,56.7l-76.1,0c-6.73,0 -12.21,5.49 -12.21,12.22l0,15.3c0,6.74 5.48,12.22 12.21,12.22l487.58,0c6.73,0 12.21,-5.48 12.21,-12.22l0,-15.3c0,-6.73 -5.48,-12.22 -12.21,-12.22zm-249.74,-163.37c6.67,6.13 12.49,14.27 12.49,21.18c0,2.54 -0.73,3.56 -1.36,4.17c-2.15,2.05 -6.84,2.72 -11.13,2.89l0,-28.24zm0,44.16c1.84,-0.06 3.79,-0.19 5.76,-0.45c2.44,14.61 1.73,31.88 -4.47,41.7c-0.41,0.65 -0.84,1.24 -1.29,1.8l0,-43.06l0,0l0,0.01zm-209.86,-193.82c-1.44,0 -2.65,-1.21 -2.65,-2.64l0,-93.06c0,-1.44 1.21,-2.65 2.65,-2.65l431.26,0c1.44,0 2.65,1.21 2.65,2.65l0,93.06c0,1.43 -1.21,2.64 -2.65,2.64l-431.26,0zm385.69,15.88l0,166.58l-73.03,0l0,-166.58l73.03,0zm-93.14,185.1c0,-1.44 1.21,-2.65 2.64,-2.65l107.97,0c1.43,0 2.65,1.21 2.65,2.65l0,112.05l-113.26,0l0,-112.05zm-228.56,-80.04c0,-2.06 1.74,-3.8 3.8,-3.8l122.4,0c2.06,0 3.8,1.74 3.8,3.8l0,78.26l-130,0l0,-78.26zm130,94.14l0,34.7l-57.06,0l0,-34.7l57.06,0zm-130,0l57.06,0l0,34.7l-57.06,0l0,-34.7zm0,50.57l130,0l0,47.38l-130,0l0,-47.38zm-27,-90.64c-0.63,-0.61 -1.36,-1.63 -1.36,-4.17c0,-6.91 5.82,-15.04 12.49,-21.18l0,28.24c-4.29,-0.17 -8.98,-0.84 -11.13,-2.89zm9.84,60.06c-6.2,-9.82 -6.91,-27.09 -4.47,-41.7c1.97,0.26 3.91,0.39 5.76,0.45l0,43.05c-0.45,-0.56 -0.88,-1.15 -1.29,-1.8zm409.1,101.82l-480.24,0l0,-7.98l480.24,0l0,7.98zm-108.34,-421.75c-2.35,0 -4.57,1.04 -6.08,2.85c-5.37,6.4 -22.87,28.34 -22.87,41.79c0,15.97 12.99,28.96 28.95,28.96s28.96,-12.99 28.96,-28.96c0,-13.45 -17.5,-35.39 -22.87,-41.79c-1.51,-1.81 -3.74,-2.85 -6.09,-2.85zm0,57.72c-7.21,0 -13.07,-5.87 -13.07,-13.08c0,-3.4 5.05,-13.05 13.07,-23.88c8.02,10.83 13.08,20.47 13.08,23.88c0,7.21 -5.86,13.08 -13.08,13.08z",
                                            fill: "#1E252B",
                                            id: "svg_31"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_34",
                                    viewBox: "0 0 999 504",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l990,0l0,495l-990,0l0,-495z",
                                            fill: "#5c6666",
                                            id: "svg_32"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,36l990,0l0,431l-990,0l0,-431z",
                                            fill: "#757f7f",
                                            id: "svg_33"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,76l990,0l0,352l-990,0l0,-352z",
                                            fill: "#919999",
                                            id: "svg_35"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,107l990,0l0,289l-990,0l0,-289z",
                                            fill: "#aab2b2",
                                            id: "svg_36"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,129l990,0l0,247l-990,0l0,-247z",
                                            fill: "#c7cccc",
                                            id: "svg_37"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,149l990,0l0,206l-990,0l0,-206z",
                                            fill: "#e0e5e5",
                                            id: "svg_38"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,181l990,0l0,144l-990,0l0,-144z",
                                            fill: "#fcffff",
                                            id: "svg_39"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l990,0",
                                            fill: "none",
                                            id: "svg_40",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,499l990,0",
                                            fill: "none",
                                            id: "svg_41",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("symbol", {
                                    height: "800px",
                                    id: "svg_44",
                                    viewBox: "0 0 512 512",
                                    width: "800px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                        id: "svg_42",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_43",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                                id: "svg_45",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "m493.8,302.93l-50.07,0l0,-15.93c0,-10.03 -8.16,-18.2 -18.2,-18.2l-31.86,0c-10.04,0 -18.2,8.16 -18.2,18.2l0,15.93l-45.29,0l-15.45,-41.22c33.8,-19.24 57.39,-54.42 60.3,-95.31l-50.76,0c-4.71,0 -8.54,-3.82 -8.54,-8.53s3.83,-8.54 8.54,-8.54l50.76,0c-4.4,-61.89 -56.04,-110.93 -119.03,-110.93s-114.63,49.04 -119.03,110.93l50.76,0c4.71,0 8.54,3.82 8.54,8.54s-3.83,8.53 -8.54,8.53l-50.76,0c2.91,40.89 26.5,76.07 60.3,95.31l-15.45,41.22l-45.29,0l0,-15.93c0,-10.03 -8.16,-18.2 -18.2,-18.2l-31.86,0c-10.04,0 -18.2,8.16 -18.2,18.2l0,15.93l-50.07,0c-10.03,0 -18.2,8.17 -18.2,18.2l0,100.13c0,10.04 8.17,18.21 18.2,18.21l50.07,0l0,15.93c0,10.03 8.16,18.2 18.2,18.2l31.86,0c10.04,0 18.2,-8.16 18.2,-18.2l0,-15.93l238.94,0l0,15.93c0,10.03 8.16,18.2 18.2,18.2l31.86,0c10.04,0 18.2,-8.16 18.2,-18.2l0,-15.93l50.07,0c10.03,0 18.2,-8.17 18.2,-18.21l0,-100.13c0,-10.03 -8.17,-18.2 -18.2,-18.2zm-374.33,8.54l0,119.46l0,24.47c0,0.62 -0.52,1.13 -1.14,1.13l-31.86,0c-0.63,0 -1.14,-0.51 -1.14,-1.13l0,-24.47l0,-119.46l0,-24.47c0,-0.63 0.51,-1.13 1.14,-1.13l31.86,0c0.62,0 1.14,0.5 1.14,1.13l0,24.47zm128,-177.63l0,-27.17c0,-4.72 3.82,-8.54 8.53,-8.54s8.53,3.82 8.53,8.54l0,27.17c9.92,3.53 17.07,12.92 17.07,24.03c0,14.11 -11.49,25.6 -25.6,25.6s-25.6,-11.49 -25.6,-25.6c0,-11.11 7.15,-20.5 17.07,-24.03zm17.06,92.29l0,33.6c-5.68,0.48 -11.38,0.48 -17.06,0l0,-33.6c0,-4.72 3.82,-8.53 8.53,-8.53s8.53,3.81 8.53,8.53zm-64.48,76.8l12.67,-33.78c13.42,5.25 28,8.18 43.28,8.18c-0.08,0 -0.14,-0.04 -0.21,-0.04l0.42,0c-0.07,0 -0.13,0.04 -0.21,0.04c15.28,0 29.86,-2.93 43.28,-8.18l12.67,33.78l-111.9,0zm226.62,8.54l0,119.46l0,24.47c0,0.62 -0.52,1.13 -1.14,1.13l-31.86,0c-0.62,0 -1.14,-0.51 -1.14,-1.13l0,-24.47l0,-119.46l0,-24.47c0,-0.63 0.52,-1.13 1.14,-1.13l31.86,0c0.62,0 1.14,0.5 1.14,1.13l0,24.47z",
                                                        id: "svg_46"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "m256,166.4c4.7,0 8.53,-3.83 8.53,-8.53c0,-4.71 -3.83,-8.54 -8.53,-8.54c-4.7,0 -8.53,3.83 -8.53,8.54c0,4.7 3.83,8.53 8.53,8.53z",
                                                        id: "svg_47"
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("symbol", {
                                    height: "800px",
                                    id: "svg_68",
                                    viewBox: "0 0 503.607 503.607",
                                    width: "800px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                        id: "svg_56",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_63",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "m486.82,159.47l-33.57,0c-9.25,0 -16.79,7.53 -16.79,16.79l0,8.4l-88.47,0c-2.35,-3.35 -4.81,-6.61 -7.48,-9.69l-29.35,29.35c-1.64,1.64 -3.78,2.46 -5.93,2.46s-4.3,-0.82 -5.94,-2.46c-3.28,-3.28 -3.28,-8.59 0,-11.87l29.35,-29.35c-18.64,-16.16 -42.36,-26.52 -68.44,-28.38l0,41.54c0,4.64 -3.76,8.4 -8.4,8.4c-4.63,0 -8.39,-3.76 -8.39,-8.4l0,-41.54c-26.08,1.86 -49.81,12.22 -68.44,28.38l29.35,29.35c3.28,3.28 3.28,8.59 0,11.87c-1.64,1.64 -3.78,2.46 -5.93,2.46c-2.15,0 -4.3,-0.82 -5.94,-2.46l-29.35,-29.35c-2.67,3.08 -5.13,6.34 -7.48,9.69l-88.47,0l0,-8.4c0,-9.26 -7.53,-16.79 -16.79,-16.79l-33.57,0c-9.25,0 -16.79,7.53 -16.79,16.79l0,151.08c0,9.26 7.54,16.79 16.79,16.79l33.57,0c9.26,0 16.79,-7.53 16.79,-16.79l0,-8.39l88.47,0c2.35,3.35 4.81,6.61 7.48,9.69l29.35,-29.35c3.29,-3.28 8.6,-3.28 11.87,0c3.28,3.28 3.28,8.59 0,11.86l-29.35,29.35c18.63,16.17 42.36,26.53 68.44,28.38l0,-41.54c0,-4.64 3.76,-8.39 8.39,-8.39c4.64,0 8.4,3.75 8.4,8.39l0,41.54c26.08,-1.85 49.8,-12.21 68.45,-28.37l-29.36,-29.36c-3.28,-3.27 -3.28,-8.58 0,-11.86c3.28,-3.28 8.59,-3.28 11.87,0l29.35,29.35c2.67,-3.08 5.13,-6.34 7.48,-9.69l88.47,0l0,8.39c0,9.26 7.54,16.79 16.79,16.79l33.57,0c9.26,0 16.79,-7.53 16.79,-16.79l0,-151.08c0,-9.26 -7.53,-16.79 -16.79,-16.79zm-351.85,104.46c0.13,1.18 0.34,2.34 0.49,3.51c0.39,2.85 0.85,5.69 1.44,8.48c0.27,1.32 0.6,2.63 0.92,3.94c0.66,2.66 1.41,5.27 2.25,7.86c0.41,1.28 0.81,2.57 1.27,3.84c1.02,2.79 2.15,5.51 3.37,8.19c0.35,0.79 0.61,1.62 0.99,2.41l-78.55,0l0,-67.15l25.18,0c4.64,0 8.39,-3.75 8.39,-8.39c0,-4.64 -3.75,-8.39 -8.39,-8.39l-25.18,0l0,-16.79l78.55,0c-0.38,0.79 -0.64,1.62 -0.99,2.41c-1.22,2.69 -2.35,5.41 -3.36,8.19c-0.47,1.28 -0.87,2.56 -1.28,3.85c-0.84,2.58 -1.59,5.19 -2.25,7.85c-0.32,1.31 -0.65,2.62 -0.92,3.95c-0.59,2.78 -1.05,5.61 -1.44,8.47c-0.15,1.17 -0.36,2.33 -0.48,3.51c-0.42,3.99 -0.68,8.03 -0.68,12.13c-0.01,4.11 0.26,8.14 0.67,12.13zm41.29,-3.73l-24.78,0c-0.24,-2.79 -0.4,-5.58 -0.4,-8.4c0,-2.81 0.16,-5.6 0.4,-8.39l24.78,0c4.64,0 8.4,3.75 8.4,8.39c0,4.64 -3.76,8.4 -8.4,8.4zm106.66,-27.64l-50.36,50.36c-1.64,1.64 -3.79,2.46 -5.94,2.46c-2.14,0 -4.29,-0.83 -5.93,-2.46c-3.27,-3.28 -3.27,-8.59 0,-11.87l50.36,-50.36c3.28,-3.28 8.6,-3.28 11.87,0c3.28,3.28 3.28,8.59 0,11.87zm69.22,27.64l-24.8,0c-4.63,0 -8.39,-3.76 -8.39,-8.4c0,-4.64 3.76,-8.39 8.39,-8.39l24.8,0c0.23,2.79 0.38,5.58 0.38,8.39c0,2.82 -0.15,5.61 -0.38,8.4zm84.32,-41.97l-16.79,0c-4.63,0 -8.39,3.75 -8.39,8.39c0,4.64 3.76,8.4 8.39,8.4l16.79,0l0,67.14l-78.55,0c0.38,-0.78 0.63,-1.62 0.99,-2.41c1.22,-2.68 2.35,-5.4 3.37,-8.19c0.46,-1.27 0.86,-2.56 1.28,-3.84c0.83,-2.59 1.58,-5.2 2.24,-7.86c0.32,-1.31 0.65,-2.62 0.93,-3.94c0.59,-2.79 1.05,-5.63 1.42,-8.48c0.16,-1.17 0.37,-2.33 0.5,-3.51c0.41,-3.98 0.67,-8.02 0.67,-12.13c0,-4.1 -0.26,-8.14 -0.67,-12.12c-0.13,-1.19 -0.34,-2.35 -0.5,-3.51c-0.05,-0.39 -0.1,-0.77 -0.15,-1.15l18.11,0c4.64,0 8.39,-3.75 8.39,-8.39c0,-4.65 -3.75,-8.4 -8.39,-8.4l-21.77,0c-0.25,-0.79 -0.53,-1.56 -0.79,-2.34c-0.41,-1.28 -0.81,-2.57 -1.27,-3.84c-1.02,-2.79 -2.16,-5.51 -3.37,-8.2c-0.36,-0.78 -0.61,-1.62 -0.99,-2.4l78.55,0l0,16.78z",
                                                id: "svg_64"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_75",
                                    viewBox: "0 0 56.305 112.5",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_74",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "m56.19,9.35c0,0 -6.31,-9.35 -28.09,-9.35c-21.13,0 -28.1,9.35 -28.1,9.35l0,84.46l23.54,18.69l9.23,0l23.42,-18.69l0,-84.46z",
                                                fill: "#C3C3C3",
                                                id: "svg_67",
                                                stroke: "#4C4C4C",
                                                "stroke-width": "0.25"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                            id: "svg_72",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("linearGradient", {
                                                    id: "svg_73",
                                                    x1: "0.52",
                                                    x2: "0.49",
                                                    y1: "1.01",
                                                    y2: "0",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                            offset: "0",
                                                            "stop-color": "#989898"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                            offset: "1",
                                                            "stop-color": "#F1F1F1"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m56.19,16.11l-5.18,0l0,72.97l-3.6,0l0,-72.97l-6.98,0l0,72.97l-3.61,0l0,-72.97l-6.98,0l0,72.97l-3.38,0l0,-72.97l-6.98,0l0,72.97l-3.6,0l0,-72.97l-7.21,0l0,72.97l-3.38,0l0,-72.97l-5.29,0l0,77.7l23.54,18.69l9.23,0l23.42,-18.69l0,-77.7",
                                                    fill: "url(#svg_73)",
                                                    id: "svg_70",
                                                    stroke: "#4C4C4C",
                                                    "stroke-width": "0.25"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_71",
                                    viewBox: "0 0 999 999",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,301l0,-297l594,0l0,297l1,10l1,10l2,10l4,9l4,8l5,9l5,7l7,7l7,7l7,5l9,5l8,4l9,4l10,2l10,1l10,1l297,0l0,594l-297,0l-36,-1l-35,-3l-35,-4l-34,-7l-33,-7l-33,-9l-32,-12l-32,-12l-30,-14l-30,-15l-29,-17l-28,-18l-27,-19l-26,-21l-26,-21l-24,-23l-23,-24l-21,-26l-21,-26l-19,-27l-18,-28l-17,-29l-15,-30l-14,-30l-12,-32l-12,-32l-9,-33l-7,-33l-7,-34l-4,-35l-3,-35l-1,-36z",
                                            fill: "#5c6666",
                                            id: "svg_81"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,956l-34,-1l-33,-2l-33,-4l-32,-6l-32,-7l-31,-9l-30,-11l-30,-11l-29,-13l-28,-15l-28,-16l-26,-16l-26,-19l-25,-19l-24,-21l-22,-22l-22,-22l-21,-24l-19,-25l-19,-26l-16,-26l-16,-28l-15,-28l-13,-29l-11,-30l-11,-30l-9,-31l-7,-32l-6,-32l-4,-33l-2,-33l-1,-34l0,-297l519,0l0,297l0,14l2,14l4,13l4,12l6,12l7,11l8,11l9,9l9,9l11,8l11,7l12,6l12,4l13,4l14,2l14,0l297,0l0,519l-297,0z",
                                            fill: "#777f7f",
                                            id: "svg_82"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,907l-31,-1l-31,-2l-30,-4l-30,-5l-30,-7l-28,-9l-28,-9l-28,-11l-27,-12l-26,-13l-25,-15l-25,-16l-24,-16l-22,-18l-22,-19l-21,-21l-21,-21l-18,-21l-19,-23l-16,-24l-16,-25l-15,-25l-13,-26l-12,-27l-11,-27l-9,-28l-9,-29l-7,-30l-5,-29l-4,-31l-2,-30l-1,-31l0,-298l420,0l0,298l1,18l3,19l4,18l7,17l8,16l9,15l11,14l12,13l13,13l14,10l15,9l17,8l17,7l18,4l18,3l19,1l297,0l0,420l-297,0z",
                                            fill: "#919999",
                                            id: "svg_83"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m128,301l0,-297l347,0l0,297l0,12l1,11l1,11l2,11l3,11l2,10l4,11l4,10l4,10l5,9l5,10l6,9l6,8l7,9l7,8l7,8l8,7l8,7l9,7l8,6l9,6l10,5l9,5l10,5l10,4l11,3l10,3l11,2l11,2l11,2l11,1l11,0l298,0l0,346l-298,0l-29,-1l-29,-2l-28,-4l-28,-5l-28,-6l-27,-8l-26,-9l-26,-10l-25,-11l-25,-13l-23,-14l-23,-14l-22,-16l-22,-17l-21,-18l-19,-19l-19,-19l-18,-21l-17,-22l-16,-22l-14,-23l-14,-24l-13,-24l-11,-26l-10,-25l-9,-27l-8,-27l-6,-27l-5,-28l-4,-29l-2,-28l-1,-30z",
                                            fill: "#aab2b2",
                                            id: "svg_84"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m153,301l0,28l3,28l3,27l5,27l6,26l7,26l9,25l10,25l11,24l11,23l14,23l14,22l15,22l16,20l17,20l18,19l19,18l20,17l20,16l22,15l22,14l23,14l23,11l24,11l25,10l25,9l26,7l26,6l27,5l27,3l28,3l28,0l297,0l0,-297l-297,0l-13,0l-13,-1l-12,-2l-12,-1l-12,-3l-12,-4l-11,-4l-11,-4l-11,-5l-11,-6l-10,-5l-10,-7l-10,-7l-9,-7l-9,-8l-9,-8l-8,-9l-8,-9l-7,-9l-7,-10l-7,-10l-5,-10l-6,-11l-5,-11l-4,-11l-4,-11l-4,-12l-3,-12l-1,-12l-2,-12l-1,-13l0,-13l0,-297l-297,0l0,297z",
                                            fill: "#c7cccc",
                                            id: "svg_85"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m178,301l1,27l2,26l3,26l4,26l6,25l7,24l9,25l9,23l10,23l12,22l12,22l14,21l14,21l16,19l16,19l17,18l18,17l19,16l19,16l21,14l21,14l22,12l22,12l23,10l23,9l25,9l24,7l25,6l26,4l26,3l26,2l27,1l297,1l0,-247l-297,-1l-14,0l-14,-1l-13,-2l-14,-3l-13,-3l-13,-3l-12,-5l-13,-5l-12,-5l-12,-6l-11,-6l-11,-8l-11,-7l-10,-8l-10,-9l-9,-9l-9,-9l-9,-10l-8,-10l-7,-11l-8,-11l-6,-11l-6,-12l-5,-12l-5,-13l-5,-12l-3,-13l-3,-13l-3,-14l-2,-13l-1,-14l0,-14l0,-297l-247,0l0,297z",
                                            fill: "#e0e5e5",
                                            id: "svg_86"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m214,301l1,25l2,25l3,24l4,23l6,24l6,23l8,22l8,22l10,21l11,21l11,20l13,20l13,19l15,18l15,18l16,16l16,16l18,15l18,15l19,13l20,13l20,11l21,11l21,10l22,8l22,8l23,6l24,6l23,4l24,3l25,2l25,1l297,0l0,-174l-297,0l-16,0l-16,-2l-15,-2l-15,-2l-15,-4l-15,-4l-14,-5l-15,-5l-13,-6l-13,-7l-13,-8l-13,-8l-12,-8l-12,-9l-11,-10l-10,-11l-11,-10l-10,-11l-9,-12l-8,-12l-8,-13l-8,-13l-7,-13l-6,-13l-5,-15l-5,-14l-4,-15l-4,-15l-2,-15l-2,-15l-2,-16l0,-16l0,-297l-174,0l0,297z",
                                            fill: "#fcffff",
                                            id: "svg_87"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l0,297l1,36l3,35l4,35l7,34l7,33l9,33l12,32l12,32l14,30l15,30l17,29l18,28l19,27l21,26l21,26l23,24l24,23l26,21l26,21l27,19l28,18l29,17l30,15l30,14l32,12l32,12l33,9l33,7l34,7l35,4l35,3l36,1l297,0",
                                            fill: "none",
                                            id: "svg_88",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m598,4l0,297l1,10l1,10l2,10l4,9l4,8l5,9l5,7l7,7l7,7l7,5l9,5l8,4l9,4l10,2l10,1l10,1l297,0",
                                            fill: "none",
                                            id: "svg_89",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_78",
                                    viewBox: "0 0 999 504",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l990,0l0,495l-990,0l0,-495z",
                                            fill: "#5c6666",
                                            id: "svg_90"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,36l990,0l0,431l-990,0l0,-431z",
                                            fill: "#757f7f",
                                            id: "svg_91"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,76l990,0l0,352l-990,0l0,-352z",
                                            fill: "#919999",
                                            id: "svg_92"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,107l990,0l0,289l-990,0l0,-289z",
                                            fill: "#aab2b2",
                                            id: "svg_93"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,129l990,0l0,247l-990,0l0,-247z",
                                            fill: "#c7cccc",
                                            id: "svg_94"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,149l990,0l0,206l-990,0l0,-206z",
                                            fill: "#e0e5e5",
                                            id: "svg_95"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,181l990,0l0,144l-990,0l0,-144z",
                                            fill: "#fcffff",
                                            id: "svg_96"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l990,0",
                                            fill: "none",
                                            id: "svg_97",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,499l990,0",
                                            fill: "none",
                                            id: "svg_98",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_109",
                                    viewBox: "0 0 504 999",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m499,4l0,990l-495,0l0,-990l495,0z",
                                            fill: "#5c6666",
                                            id: "svg_77"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m468,4l0,990l-433,0l0,-990l433,0z",
                                            fill: "#757f7f",
                                            id: "svg_79"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m427,4l0,990l-351,0l0,-990l351,0z",
                                            fill: "#919999",
                                            id: "svg_99"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m396,4l0,990l-289,0l0,-990l289,0z",
                                            fill: "#aab2b2",
                                            id: "svg_103"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m375,4l0,990l-247,0l0,-990l247,0z",
                                            fill: "#c7cccc",
                                            id: "svg_104"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m355,4l0,990l-207,0l0,-990l207,0z",
                                            fill: "#e0e5e5",
                                            id: "svg_105"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m324,4l0,990l-145,0l0,-990l145,0z",
                                            fill: "#fcffff",
                                            id: "svg_106"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m499,4l0,990",
                                            fill: "none",
                                            id: "svg_121",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l0,990",
                                            fill: "none",
                                            id: "svg_123",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_111",
                                    viewBox: "0 0 999 999",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,4l297,0l0,594l-297,0l-10,1l-10,1l-10,2l-9,3l-9,5l-8,5l-7,5l-7,7l-7,7l-5,7l-5,8l-5,9l-3,9l-2,10l-1,10l-1,10l0,297l-594,0l0,-297l1,-36l3,-35l4,-34l7,-35l7,-33l10,-33l11,-32l12,-32l14,-30l15,-30l17,-29l18,-28l19,-27l21,-26l21,-25l24,-24l24,-24l25,-21l26,-21l27,-19l28,-18l29,-17l30,-15l30,-14l32,-12l32,-11l33,-10l33,-7l35,-7l34,-4l35,-3l36,-1z",
                                            fill: "#5c6666",
                                            id: "svg_124"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m42,697l1,-34l2,-33l5,-33l5,-32l7,-32l9,-31l11,-30l11,-30l14,-29l14,-28l16,-28l17,-26l18,-26l19,-25l21,-24l22,-22l22,-22l24,-21l25,-19l26,-18l26,-17l28,-16l28,-14l29,-14l30,-11l30,-11l31,-9l32,-7l32,-5l33,-5l33,-2l34,-1l297,0l0,518l-297,0l-14,1l-14,2l-13,4l-12,4l-12,6l-11,7l-11,8l-9,8l-9,10l-8,11l-7,11l-6,12l-4,12l-4,13l-2,14l-1,14l0,297l-518,0l0,-297z",
                                            fill: "#777f7f",
                                            id: "svg_125"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m91,697l1,-31l2,-31l4,-30l6,-30l7,-30l8,-28l9,-28l11,-28l12,-27l14,-26l14,-25l16,-25l17,-24l18,-22l19,-22l20,-21l21,-20l22,-19l22,-18l24,-17l25,-16l25,-14l26,-14l27,-12l28,-11l28,-9l28,-8l30,-7l30,-6l30,-4l31,-2l31,-1l297,0l0,420l-297,0l-19,1l-19,2l-18,5l-17,6l-16,8l-15,10l-15,10l-13,12l-12,13l-10,15l-10,15l-8,16l-6,17l-5,18l-2,19l-1,19l0,297l-420,0l0,-297z",
                                            fill: "#919999",
                                            id: "svg_134"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,129l297,0l0,346l-297,0l-12,0l-11,1l-11,1l-11,2l-11,3l-10,2l-11,4l-10,4l-10,4l-9,5l-10,5l-9,6l-9,6l-8,7l-8,7l-8,7l-7,8l-7,8l-7,9l-6,8l-6,9l-6,10l-5,9l-4,10l-4,10l-3,11l-4,10l-2,11l-2,11l-1,11l-1,11l-1,12l0,297l-346,0l2,-297l1,-30l2,-29l4,-28l5,-28l6,-27l7,-27l9,-27l11,-26l11,-25l12,-24l14,-24l15,-23l16,-22l16,-22l18,-20l19,-20l20,-19l20,-18l22,-16l22,-16l23,-15l24,-14l24,-12l25,-11l26,-11l27,-9l27,-7l27,-6l28,-5l28,-4l29,-2l30,-1z",
                                            fill: "#aab2b2",
                                            id: "svg_139"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,153l-28,0l-28,3l-27,3l-27,5l-26,6l-26,7l-25,9l-25,10l-24,11l-24,11l-22,14l-22,14l-22,15l-20,16l-20,17l-19,18l-18,19l-17,20l-16,20l-15,22l-14,22l-14,22l-11,24l-11,24l-10,25l-9,25l-7,26l-6,26l-5,27l-3,27l-3,28l0,28l0,297l297,0l0,-297l0,-13l1,-13l2,-12l1,-12l3,-12l4,-12l4,-11l4,-11l5,-11l6,-11l5,-10l7,-10l7,-10l7,-9l8,-9l8,-9l9,-8l9,-8l9,-7l10,-7l10,-7l10,-5l11,-6l11,-5l11,-4l11,-4l12,-4l12,-3l12,-1l12,-2l13,-1l13,0l297,0l0,-297l-297,0z",
                                            fill: "#c7cccc",
                                            id: "svg_140"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,179l-27,0l-26,2l-26,3l-26,5l-25,6l-24,7l-25,8l-23,9l-23,11l-22,11l-22,12l-21,14l-20,14l-20,16l-19,16l-18,17l-17,18l-16,19l-16,20l-14,20l-14,21l-12,22l-11,22l-11,23l-9,23l-8,25l-7,24l-6,25l-5,26l-3,26l-2,26l0,27l-2,297l247,0l2,-297l0,-14l1,-14l2,-14l2,-13l3,-13l4,-13l4,-12l5,-13l6,-12l5,-12l7,-11l7,-11l8,-11l7,-10l9,-10l9,-9l9,-9l10,-9l10,-7l11,-8l11,-7l11,-7l12,-5l12,-6l13,-5l12,-4l13,-4l13,-3l13,-2l14,-2l14,-1l14,0l297,0l0,-247l-297,0z",
                                            fill: "#e0e5e5",
                                            id: "svg_141"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,214l-25,1l-25,2l-24,3l-23,4l-24,5l-23,7l-22,7l-22,9l-22,10l-20,10l-21,12l-19,13l-19,13l-18,14l-18,15l-17,16l-16,17l-15,18l-14,18l-13,19l-13,19l-12,21l-10,20l-10,22l-9,22l-7,22l-7,23l-5,24l-4,23l-3,24l-2,25l-1,25l0,297l174,0l0,-297l1,-16l1,-16l2,-15l2,-15l4,-15l4,-15l5,-14l6,-14l6,-14l6,-13l8,-13l8,-13l9,-12l9,-11l9,-12l11,-10l10,-11l12,-9l11,-9l12,-9l13,-8l13,-8l13,-6l14,-6l14,-6l14,-5l15,-4l15,-4l15,-2l15,-2l16,-1l16,-1l297,0l0,-174l-297,0z",
                                            fill: "#fcffff",
                                            id: "svg_142"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m994,4l-297,0l-36,1l-35,3l-34,4l-35,7l-33,7l-33,10l-32,11l-32,12l-30,14l-30,15l-29,17l-28,18l-27,19l-26,21l-25,21l-24,24l-24,24l-21,25l-21,26l-19,27l-18,28l-17,29l-15,30l-14,30l-12,32l-11,32l-10,33l-7,33l-7,35l-4,34l-3,35l-1,36l0,297",
                                            fill: "none",
                                            id: "svg_143",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m994,598l-297,0l-10,1l-10,1l-10,2l-9,3l-9,5l-8,5l-7,5l-7,7l-7,7l-5,7l-5,8l-5,9l-3,9l-2,10l-1,10l-1,10l0,297",
                                            fill: "none",
                                            id: "svg_144",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_130",
                                    viewBox: "0 0 15 15",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_129",
                                            "stroke-width": "0"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_128",
                                            stroke: "#CCCCCC",
                                            "stroke-linecap": "round",
                                            "stroke-linejoin": "round",
                                            "stroke-width": "1.74",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "m7.54,2c-0.3,0 -0.49,0.18 -0.62,0.38l-5.84,9.54c-0.08,0.08 -0.08,0.23 -0.08,0.39c0,0.54 0.38,0.69 0.69,0.69l11.62,0c0.38,0 0.69,-0.15 0.69,-0.69c0,-0.16 0,-0.23 -0.08,-0.39l-5.77,-9.54c-0.12,-0.2 -0.36,-0.38 -0.61,-0.38z",
                                                id: "svg_127"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_126",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "m7.54,2c-0.3,0 -0.49,0.18 -0.62,0.38l-5.84,9.54c-0.08,0.08 -0.08,0.23 -0.08,0.39c0,0.54 0.38,0.69 0.69,0.69l11.62,0c0.38,0 0.69,-0.15 0.69,-0.69c0,-0.16 0,-0.23 -0.08,-0.39l-5.77,-9.54c-0.12,-0.2 -0.36,-0.38 -0.61,-0.38z",
                                                id: "path21090-9"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_138",
                                    "stroke-width": "0",
                                    viewBox: "-15.15 -15.15 138.53 138.53",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_137",
                                            "stroke-width": "0"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_136",
                                            stroke: "#CCCCCC",
                                            "stroke-linecap": "round",
                                            "stroke-linejoin": "round",
                                            "stroke-width": "21.65",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                                id: "svg_145",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m27.09,108.23l0,-108.23c14.8,0 27.51,5.3 38.13,15.89c10.61,10.59 15.92,23.33 15.92,38.22c0,14.93 -5.31,27.69 -15.92,38.26c-10.62,10.57 -23.33,15.86 -38.13,15.86z",
                                                    id: "svg_146"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_135",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                                id: "svg_147",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m27.09,108.23l0,-108.23c14.8,0 27.51,5.3 38.13,15.89c10.61,10.59 15.92,23.33 15.92,38.22c0,14.93 -5.31,27.69 -15.92,38.26c-10.62,10.57 -23.33,15.86 -38.13,15.86z",
                                                    id: "svg_148"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_167",
                                    viewBox: "0 0 999 504",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l990,0l0,495l-990,0l0,-495z",
                                            fill: "#5c6666",
                                            id: "svg_149"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,36l990,0l0,431l-990,0l0,-431z",
                                            fill: "#757f7f",
                                            id: "svg_150"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,76l990,0l0,352l-990,0l0,-352z",
                                            fill: "#919999",
                                            id: "svg_151"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,107l990,0l0,289l-990,0l0,-289z",
                                            fill: "#aab2b2",
                                            id: "svg_154"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,129l990,0l0,247l-990,0l0,-247z",
                                            fill: "#c7cccc",
                                            id: "svg_155"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,149l990,0l0,206l-990,0l0,-206z",
                                            fill: "#e0e5e5",
                                            id: "svg_156"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,181l990,0l0,144l-990,0l0,-144z",
                                            fill: "#fcffff",
                                            id: "svg_157"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l990,0",
                                            fill: "none",
                                            id: "svg_158",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,499l990,0",
                                            fill: "none",
                                            id: "svg_159",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_171",
                                    viewBox: "0 0 257 999",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m252,4l0,990l-248,0l0,-990l248,0z",
                                            fill: "#5c6666",
                                            id: "svg_188"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m236,4l0,990l-216,0l0,-990l216,0z",
                                            fill: "#757f7f",
                                            id: "svg_189"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m216,4l0,990l-176,0l0,-990l176,0z",
                                            fill: "#919999",
                                            id: "svg_190"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m200,4l0,990l-144,0l0,-990l144,0z",
                                            fill: "#aab2b2",
                                            id: "svg_191"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m190,4l0,990l-124,0l0,-990l124,0z",
                                            fill: "#c7cccc",
                                            id: "svg_192"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m180,4l0,990l-104,0l0,-990l104,0z",
                                            fill: "#e0e5e5",
                                            id: "svg_193"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m164,4l0,990l-72,0l0,-990l72,0z",
                                            fill: "#fcffff",
                                            id: "svg_194"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m252,4l0,990",
                                            fill: "none",
                                            id: "svg_195",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l0,990",
                                            fill: "none",
                                            id: "svg_196",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_175",
                                    viewBox: "0 0 999 999",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,301l0,-297l594,0l0,297l1,10l1,10l2,10l4,9l4,8l5,9l5,7l7,7l7,7l7,5l9,5l8,4l9,4l10,2l10,1l10,1l297,0l0,594l-297,0l-36,-1l-35,-3l-35,-4l-34,-7l-33,-7l-33,-9l-32,-12l-32,-12l-30,-14l-30,-15l-29,-17l-28,-18l-27,-19l-26,-21l-26,-21l-24,-23l-23,-24l-21,-26l-21,-26l-19,-27l-18,-28l-17,-29l-15,-30l-14,-30l-12,-32l-12,-32l-9,-33l-7,-33l-7,-34l-4,-35l-3,-35l-1,-36z",
                                            fill: "#5c6666",
                                            id: "svg_197"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,956l-34,-1l-33,-2l-33,-4l-32,-6l-32,-7l-31,-9l-30,-11l-30,-11l-29,-13l-28,-15l-28,-16l-26,-16l-26,-19l-25,-19l-24,-21l-22,-22l-22,-22l-21,-24l-19,-25l-19,-26l-16,-26l-16,-28l-15,-28l-13,-29l-11,-30l-11,-30l-9,-31l-7,-32l-6,-32l-4,-33l-2,-33l-1,-34l0,-297l519,0l0,297l0,14l2,14l4,13l4,12l6,12l7,11l8,11l9,9l9,9l11,8l11,7l12,6l12,4l13,4l14,2l14,0l297,0l0,519l-297,0z",
                                            fill: "#777f7f",
                                            id: "svg_198"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m697,907l-31,-1l-31,-2l-30,-4l-30,-5l-30,-7l-28,-9l-28,-9l-28,-11l-27,-12l-26,-13l-25,-15l-25,-16l-24,-16l-22,-18l-22,-19l-21,-21l-21,-21l-18,-21l-19,-23l-16,-24l-16,-25l-15,-25l-13,-26l-12,-27l-11,-27l-9,-28l-9,-29l-7,-30l-5,-29l-4,-31l-2,-30l-1,-31l0,-298l420,0l0,298l1,18l3,19l4,18l7,17l8,16l9,15l11,14l12,13l13,13l14,10l15,9l17,8l17,7l18,4l18,3l19,1l297,0l0,420l-297,0z",
                                            fill: "#919999",
                                            id: "svg_199"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m128,301l0,-297l347,0l0,297l0,12l1,11l1,11l2,11l3,11l2,10l4,11l4,10l4,10l5,9l5,10l6,9l6,8l7,9l7,8l7,8l8,7l8,7l9,7l8,6l9,6l10,5l9,5l10,5l10,4l11,3l10,3l11,2l11,2l11,2l11,1l11,0l298,0l0,346l-298,0l-29,-1l-29,-2l-28,-4l-28,-5l-28,-6l-27,-8l-26,-9l-26,-10l-25,-11l-25,-13l-23,-14l-23,-14l-22,-16l-22,-17l-21,-18l-19,-19l-19,-19l-18,-21l-17,-22l-16,-22l-14,-23l-14,-24l-13,-24l-11,-26l-10,-25l-9,-27l-8,-27l-6,-27l-5,-28l-4,-29l-2,-28l-1,-30z",
                                            fill: "#aab2b2",
                                            id: "svg_200"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m153,301l0,28l3,28l3,27l5,27l6,26l7,26l9,25l10,25l11,24l11,23l14,23l14,22l15,22l16,20l17,20l18,19l19,18l20,17l20,16l22,15l22,14l23,14l23,11l24,11l25,10l25,9l26,7l26,6l27,5l27,3l28,3l28,0l297,0l0,-297l-297,0l-13,0l-13,-1l-12,-2l-12,-1l-12,-3l-12,-4l-11,-4l-11,-4l-11,-5l-11,-6l-10,-5l-10,-7l-10,-7l-9,-7l-9,-8l-9,-8l-8,-9l-8,-9l-7,-9l-7,-10l-7,-10l-5,-10l-6,-11l-5,-11l-4,-11l-4,-11l-4,-12l-3,-12l-1,-12l-2,-12l-1,-13l0,-13l0,-297l-297,0l0,297z",
                                            fill: "#c7cccc",
                                            id: "svg_201"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m178,301l1,27l2,26l3,26l4,26l6,25l7,24l9,25l9,23l10,23l12,22l12,22l14,21l14,21l16,19l16,19l17,18l18,17l19,16l19,16l21,14l21,14l22,12l22,12l23,10l23,9l25,9l24,7l25,6l26,4l26,3l26,2l27,1l297,1l0,-247l-297,-1l-14,0l-14,-1l-13,-2l-14,-3l-13,-3l-13,-3l-12,-5l-13,-5l-12,-5l-12,-6l-11,-6l-11,-8l-11,-7l-10,-8l-10,-9l-9,-9l-9,-9l-9,-10l-8,-10l-7,-11l-8,-11l-6,-11l-6,-12l-5,-12l-5,-13l-5,-12l-3,-13l-3,-13l-3,-14l-2,-13l-1,-14l0,-14l0,-297l-247,0l0,297z",
                                            fill: "#e0e5e5",
                                            id: "svg_202"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m214,301l1,25l2,25l3,24l4,23l6,24l6,23l8,22l8,22l10,21l11,21l11,20l13,20l13,19l15,18l15,18l16,16l16,16l18,15l18,15l19,13l20,13l20,11l21,11l21,10l22,8l22,8l23,6l24,6l23,4l24,3l25,2l25,1l297,0l0,-174l-297,0l-16,0l-16,-2l-15,-2l-15,-2l-15,-4l-15,-4l-14,-5l-15,-5l-13,-6l-13,-7l-13,-8l-13,-8l-12,-8l-12,-9l-11,-10l-10,-11l-11,-10l-10,-11l-9,-12l-8,-12l-8,-13l-8,-13l-7,-13l-6,-13l-5,-15l-5,-14l-4,-15l-4,-15l-2,-15l-2,-15l-2,-16l0,-16l0,-297l-174,0l0,297z",
                                            fill: "#fcffff",
                                            id: "svg_203"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l0,297l1,36l3,35l4,35l7,34l7,33l9,33l12,32l12,32l14,30l15,30l17,29l18,28l19,27l21,26l21,26l23,24l24,23l26,21l26,21l27,19l28,18l29,17l30,15l30,14l32,12l32,12l33,9l33,7l34,7l35,4l35,3l36,1l297,0",
                                            fill: "none",
                                            id: "svg_204",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m598,4l0,297l1,10l1,10l2,10l4,9l4,8l5,9l5,7l7,7l7,7l7,5l9,5l8,4l9,4l10,2l10,1l10,1l297,0",
                                            fill: "none",
                                            id: "svg_205",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_206",
                                    viewBox: "0 0 999 999",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m994,697l0,297l-594,0l0,-297l-1,-10l-1,-10l-2,-10l-4,-9l-4,-8l-5,-9l-5,-7l-7,-7l-7,-7l-7,-5l-9,-5l-8,-4l-9,-4l-10,-2l-10,-1l-10,-1l-297,0l0,-594l297,0l36,1l35,3l35,4l34,7l33,7l33,9l32,12l32,12l30,14l30,15l29,17l28,18l27,19l26,21l26,21l24,23l23,24l21,26l21,26l19,27l18,28l17,29l15,30l14,30l12,32l12,32l9,33l7,33l7,34l4,35l3,35l1,36z",
                                            fill: "#5c6666",
                                            id: "svg_211"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m301,42l34,1l33,2l33,4l32,6l32,7l31,9l30,11l30,11l29,13l28,15l28,16l26,16l26,19l25,19l24,21l22,22l22,22l21,24l19,25l19,26l16,26l16,28l15,28l13,29l11,30l11,30l9,31l7,32l6,32l4,33l2,33l1,34l0,297l-519,0l0,-297l0,-14l-2,-14l-4,-13l-4,-12l-6,-12l-7,-11l-8,-11l-9,-9l-9,-9l-11,-8l-11,-7l-12,-6l-12,-4l-13,-4l-14,-2l-14,0l-297,0l0,-519l297,0z",
                                            fill: "#777f7f",
                                            id: "svg_226"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m301,91l31,1l31,2l30,4l30,5l30,7l28,9l28,9l28,11l27,12l26,13l25,15l25,16l24,16l22,18l22,19l21,21l21,21l18,21l19,23l16,24l16,25l15,25l13,26l12,27l11,27l9,28l9,29l7,30l5,29l4,31l2,30l1,31l0,298l-420,0l0,-298l-1,-18l-3,-19l-4,-18l-7,-17l-8,-16l-9,-15l-11,-14l-12,-13l-13,-13l-14,-10l-15,-9l-17,-8l-17,-7l-18,-4l-18,-3l-19,-1l-297,0l0,-420l297,0z",
                                            fill: "#919999",
                                            id: "svg_227"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m870,697l0,297l-347,0l0,-297l0,-12l-1,-11l-1,-11l-2,-11l-3,-11l-2,-10l-4,-11l-4,-10l-4,-10l-5,-9l-5,-10l-6,-9l-6,-8l-7,-9l-7,-8l-7,-8l-8,-7l-8,-7l-9,-7l-8,-6l-9,-6l-10,-5l-9,-5l-10,-5l-10,-4l-11,-3l-10,-3l-11,-2l-11,-2l-11,-2l-11,-1l-11,0l-298,0l0,-346l298,0l29,1l29,2l28,4l28,5l28,6l27,8l26,9l26,10l25,11l25,13l23,14l23,14l22,16l22,17l21,18l19,19l19,19l18,21l17,22l16,22l14,23l14,24l13,24l11,26l10,25l9,27l8,27l6,27l5,28l4,29l2,28l1,30z",
                                            fill: "#aab2b2",
                                            id: "svg_228"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m845,697l0,-28l-3,-28l-3,-27l-5,-27l-6,-26l-7,-26l-9,-25l-10,-25l-11,-24l-11,-23l-14,-23l-14,-22l-15,-22l-16,-20l-17,-20l-18,-19l-19,-18l-20,-17l-20,-16l-22,-15l-22,-14l-23,-14l-23,-11l-24,-11l-25,-10l-25,-9l-26,-7l-26,-6l-27,-5l-27,-3l-28,-3l-28,0l-297,0l0,297l297,0l13,0l13,1l12,2l12,1l12,3l12,4l11,4l11,4l11,5l11,6l10,5l10,7l10,7l9,7l9,8l9,8l8,9l8,9l7,9l7,10l7,10l5,10l6,11l5,11l4,11l4,11l4,12l3,12l1,12l2,12l1,13l0,13l0,297l297,0l0,-297z",
                                            fill: "#c7cccc",
                                            id: "svg_229"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m820,697l-1,-27l-2,-26l-3,-26l-4,-26l-6,-25l-7,-24l-9,-25l-9,-23l-10,-23l-12,-22l-12,-22l-14,-21l-14,-21l-16,-19l-16,-19l-17,-18l-18,-17l-19,-16l-19,-16l-21,-14l-21,-14l-22,-12l-22,-12l-23,-10l-23,-9l-25,-9l-24,-7l-25,-6l-26,-4l-26,-3l-26,-2l-27,-1l-297,-1l0,247l297,1l14,0l14,1l13,2l14,3l13,3l13,3l12,5l13,5l12,5l12,6l11,6l11,8l11,7l10,8l10,9l9,9l9,9l9,10l8,10l7,11l8,11l6,11l6,12l5,12l5,13l5,12l3,13l3,13l3,14l2,13l1,14l0,14l0,297l247,0l0,-297z",
                                            fill: "#e0e5e5",
                                            id: "svg_230"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m784,697l-1,-25l-2,-25l-3,-24l-4,-23l-6,-24l-6,-23l-8,-22l-8,-22l-10,-21l-11,-21l-11,-20l-13,-20l-13,-19l-15,-18l-15,-18l-16,-16l-16,-16l-18,-15l-18,-15l-19,-13l-20,-13l-20,-11l-21,-11l-21,-10l-22,-8l-22,-8l-23,-6l-24,-6l-23,-4l-24,-3l-25,-2l-25,-1l-297,0l0,174l297,0l16,0l16,2l15,2l15,2l15,4l15,4l14,5l15,5l13,6l13,7l13,8l13,8l12,8l12,9l11,10l10,11l11,10l10,11l9,12l8,12l8,13l8,13l7,13l6,13l5,15l5,14l4,15l4,15l2,15l2,15l2,16l0,16l0,297l174,0l0,-297z",
                                            fill: "#fcffff",
                                            id: "svg_231"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m994,994l0,-297l-1,-36l-3,-35l-4,-35l-7,-34l-7,-33l-9,-33l-12,-32l-12,-32l-14,-30l-15,-30l-17,-29l-18,-28l-19,-27l-21,-26l-21,-26l-23,-24l-24,-23l-26,-21l-26,-21l-27,-19l-28,-18l-29,-17l-30,-15l-30,-14l-32,-12l-32,-12l-33,-9l-33,-7l-34,-7l-35,-4l-35,-3l-36,-1l-297,0",
                                            fill: "none",
                                            id: "svg_232",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m400,994l0,-297l-1,-10l-1,-10l-2,-10l-4,-9l-4,-8l-5,-9l-5,-7l-7,-7l-7,-7l-7,-5l-9,-5l-8,-4l-9,-4l-10,-2l-10,-1l-10,-1l-297,0",
                                            fill: "none",
                                            id: "svg_233",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_209",
                                    viewBox: "0 0 999 999",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m301,994l-297,0l0,-594l297,0l10,-1l10,-1l10,-2l9,-4l8,-4l9,-5l7,-5l7,-7l7,-7l5,-7l5,-9l4,-8l4,-9l2,-10l1,-10l1,-10l0,-297l594,0l0,297l-1,36l-3,35l-4,35l-7,34l-7,33l-9,33l-12,32l-12,32l-14,30l-15,30l-17,29l-18,28l-19,27l-21,26l-21,26l-23,24l-24,23l-26,21l-26,21l-27,19l-28,18l-29,17l-30,15l-30,14l-32,12l-32,12l-33,9l-33,7l-34,7l-35,4l-35,3l-36,1z",
                                            fill: "#5c6666",
                                            id: "svg_234"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m956,301l-1,34l-2,33l-4,33l-6,32l-7,32l-9,31l-11,30l-11,30l-13,29l-15,28l-16,28l-16,26l-19,26l-19,25l-21,24l-22,22l-22,22l-24,21l-25,19l-26,19l-26,16l-28,16l-28,15l-29,13l-30,11l-30,11l-31,9l-32,7l-32,6l-33,4l-33,2l-34,1l-297,0l0,-519l297,0l14,0l14,-2l13,-4l12,-4l12,-6l11,-7l11,-8l9,-9l9,-9l8,-11l7,-11l6,-12l4,-12l4,-13l2,-14l0,-14l0,-297l519,0l0,297z",
                                            fill: "#777f7f",
                                            id: "svg_235"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m907,301l-1,31l-2,31l-4,30l-5,30l-7,30l-9,28l-9,28l-11,28l-12,27l-13,26l-15,25l-16,25l-16,24l-18,22l-19,22l-21,21l-21,21l-21,18l-23,19l-24,16l-25,16l-25,15l-26,13l-27,12l-27,11l-28,9l-29,9l-30,7l-29,5l-31,4l-30,2l-31,1l-298,0l0,-420l298,0l18,-1l19,-3l18,-4l17,-7l16,-8l15,-9l14,-11l13,-12l13,-13l10,-14l9,-15l8,-17l7,-17l4,-18l3,-18l1,-19l0,-297l420,0l0,297z",
                                            fill: "#919999",
                                            id: "svg_236"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m301,870l-297,0l0,-347l297,0l12,0l11,-1l11,-1l11,-2l11,-3l10,-2l11,-4l10,-4l10,-4l9,-5l10,-5l9,-6l8,-6l9,-7l8,-7l8,-7l7,-8l7,-8l7,-9l6,-8l6,-9l5,-10l5,-9l5,-10l4,-10l3,-11l3,-10l2,-11l2,-11l2,-11l1,-11l0,-11l0,-298l346,0l0,298l-1,29l-2,29l-4,28l-5,28l-6,28l-8,27l-9,26l-10,26l-11,25l-13,25l-14,23l-14,23l-16,22l-17,22l-18,21l-19,19l-19,19l-21,18l-22,17l-22,16l-23,14l-24,14l-24,13l-26,11l-25,10l-27,9l-27,8l-27,6l-28,5l-29,4l-28,2l-30,1z",
                                            fill: "#aab2b2",
                                            id: "svg_237"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m301,845l28,0l28,-3l27,-3l27,-5l26,-6l26,-7l25,-9l25,-10l24,-11l23,-11l23,-14l22,-14l22,-15l20,-16l20,-17l19,-18l18,-19l17,-20l16,-20l15,-22l14,-22l14,-23l11,-23l11,-24l10,-25l9,-25l7,-26l6,-26l5,-27l3,-27l3,-28l0,-28l0,-297l-297,0l0,297l0,13l-1,13l-2,12l-1,12l-3,12l-4,12l-4,11l-4,11l-5,11l-6,11l-5,10l-7,10l-7,10l-7,9l-8,9l-8,9l-9,8l-9,8l-9,7l-10,7l-10,7l-10,5l-11,6l-11,5l-11,4l-11,4l-12,4l-12,3l-12,1l-12,2l-13,1l-13,0l-297,0l0,297l297,0z",
                                            fill: "#c7cccc",
                                            id: "svg_238"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m301,820l27,-1l26,-2l26,-3l26,-4l25,-6l24,-7l25,-9l23,-9l23,-10l22,-12l22,-12l21,-14l21,-14l19,-16l19,-16l18,-17l17,-18l16,-19l16,-19l14,-21l14,-21l12,-22l12,-22l10,-23l9,-23l9,-25l7,-24l6,-25l4,-26l3,-26l2,-26l1,-27l1,-297l-247,0l-1,297l0,14l-1,14l-2,13l-3,14l-3,13l-3,13l-5,12l-5,13l-5,12l-6,12l-6,11l-8,11l-7,11l-8,10l-9,10l-9,9l-9,9l-10,9l-10,8l-11,7l-11,8l-11,6l-12,6l-12,5l-13,5l-12,5l-13,3l-13,3l-14,3l-13,2l-14,1l-14,0l-297,0l0,247l297,0z",
                                            fill: "#e0e5e5",
                                            id: "svg_239"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m301,784l25,-1l25,-2l24,-3l23,-4l24,-6l23,-6l22,-8l22,-8l21,-10l21,-11l20,-11l20,-13l19,-13l18,-15l18,-15l16,-16l16,-16l15,-18l15,-18l13,-19l13,-20l11,-20l11,-21l10,-21l8,-22l8,-22l6,-23l6,-24l4,-23l3,-24l2,-25l1,-25l0,-297l-174,0l0,297l0,16l-2,16l-2,15l-2,15l-4,15l-4,15l-5,14l-5,15l-6,13l-7,13l-8,13l-8,13l-8,12l-9,12l-10,11l-11,10l-10,11l-11,10l-12,9l-12,8l-13,8l-13,8l-13,7l-13,6l-15,5l-14,5l-15,4l-15,4l-15,2l-15,2l-16,2l-16,0l-297,0l0,174l297,0z",
                                            fill: "#fcffff",
                                            id: "svg_240"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,994l297,0l36,-1l35,-3l35,-4l34,-7l33,-7l33,-9l32,-12l32,-12l30,-14l30,-15l29,-17l28,-18l27,-19l26,-21l26,-21l24,-23l23,-24l21,-26l21,-26l19,-27l18,-28l17,-29l15,-30l14,-30l12,-32l12,-32l9,-33l7,-33l7,-34l4,-35l3,-35l1,-36l0,-297",
                                            fill: "none",
                                            id: "svg_241",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,400l297,0l10,-1l10,-1l10,-2l9,-4l8,-4l9,-5l7,-5l7,-7l7,-7l5,-7l5,-9l4,-8l4,-9l2,-10l1,-10l1,-10l0,-297",
                                            fill: "none",
                                            id: "svg_242",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_218",
                                    viewBox: "0 0 999 751",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l990,0l0,495l-248,0l0,247l-494,0l0,-247l-248,0l0,-495z",
                                            fill: "#5c6666",
                                            id: "svg_246"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,34l990,0l0,433l-284,0l0,279l-427,0l0,-279l-279,0l0,-433z",
                                            fill: "#757f7f",
                                            id: "svg_247"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,76l990,0l0,350l-320,0l0,320l-350,0l0,-320l-320,0l0,-350z",
                                            fill: "#919999",
                                            id: "svg_248"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,107l990,0l0,289l-351,0l0,350l-288,0l0,-350l-351,0l0,-289z",
                                            fill: "#aab2b2",
                                            id: "svg_249"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,127l990,0l0,247l-371,0l0,372l-248,0l0,-372l-371,0l0,-247z",
                                            fill: "#c7cccc",
                                            id: "svg_250"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,149l990,0l0,206l-392,0l0,391l-206,0l0,-391l-392,0l0,-206z",
                                            fill: "#e0e5e5",
                                            id: "svg_251"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,179l990,0l0,144l-423,0l0,423l-144,0l0,-423l-423,0l0,-144z",
                                            fill: "#fcffff",
                                            id: "svg_252"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m252,746l0,-247l-248,0",
                                            fill: "none",
                                            id: "svg_253",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,4l990,0",
                                            fill: "none",
                                            id: "svg_254",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m994,499l-248,0l0,247",
                                            fill: "none",
                                            id: "svg_255",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("symbol", {
                                    height: "800px",
                                    id: "svg_268",
                                    viewBox: "0 0 503.608 503.608",
                                    width: "800px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                        id: "svg_184",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_221",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "m503.61,310.56l0,-117.51l0,-0.03c-0.01,-0.6 -0.07,-1.19 -0.2,-1.75l0,-0.04l-16.79,-75.54c-0.85,-3.84 -4.26,-6.57 -8.19,-6.57l-100.72,0c-3.94,0 -7.34,2.73 -8.2,6.57l-15.32,68.97l-43.63,0l0,-16.79c0,-4.64 -3.76,-8.39 -8.4,-8.39l-83.93,0c-4.64,0 -8.39,3.76 -8.39,8.39l0,16.79l-41.97,0l0,-16.79c0,-4.64 -3.76,-8.39 -8.39,-8.39l-25.18,0l0,-16.79c0,-4.64 -3.76,-8.39 -8.39,-8.39s-8.4,3.76 -8.4,8.39l0,16.79l-25.18,0l0,-16.79c0,-4.64 -3.76,-8.39 -8.39,-8.39s-8.4,3.76 -8.4,8.39l0,16.79l-25.18,0l0,-16.79c0,-4.64 -3.75,-8.39 -8.39,-8.39c-4.64,0 -8.39,3.76 -8.39,8.39l0,16.79l-25.19,0c-4.63,0 -8.39,3.76 -8.39,8.39l0,167.87c0,4.64 3.76,8.39 8.39,8.39l25.19,0l0,16.79c0,4.64 3.75,8.39 8.39,8.39c4.63,0 8.39,-3.76 8.39,-8.39l0,-16.79l25.18,0l0,16.79c0,4.64 3.76,8.39 8.39,8.39s8.4,-3.76 8.4,-8.39l0,-16.79l25.18,0l0,16.79c0,4.64 3.76,8.39 8.39,8.39s8.39,-3.76 8.39,-8.39l0,-16.79l25.18,0c4.64,0 8.4,-3.76 8.4,-8.39l0,-16.79l41.96,0l0,16.79c0,4.64 3.76,8.39 8.39,8.39l83.94,0c4.64,0 8.39,-3.76 8.39,-8.39l0,-16.79l43.63,0l15.33,68.97c0.85,3.84 4.26,6.57 8.19,6.57l100.72,0c3.94,0 7.34,-2.73 8.2,-6.57l16.78,-75.54l0.01,-0.04c0.12,-0.56 0.19,-1.15 0.19,-1.75l0.01,-0.03zm-134.3,-109.12l117.51,0l0,100.72l-117.51,0l0,-100.72zm15.13,-75.54l87.25,0l13.06,58.76l-113.37,0l13.06,-58.76zm-367.65,201.45l0,-151.09l16.79,0l0,151.09l-16.79,0zm33.57,0l0,-151.09l25.18,0l0,151.09l-25.18,0zm41.97,0l0,-151.09l25.18,0l0,151.09l-25.18,0zm58.75,0l-16.78,0l0,-151.09l16.78,0l0,16.79l0,117.51l0,16.79zm16.79,-25.18l0,-100.73l41.97,0l0,100.72l-41.97,0l0,0.01zm125.9,25.18l-67.15,0l0,-16.79l0,-117.51l0,-16.79l67.15,0l0,16.79l0,117.51l0,16.79zm16.79,-125.91l41.96,0l0,100.72l-41.96,0l0,-100.72zm161.13,176.27l-87.25,0l-13.06,-58.76l113.37,0l-13.06,58.76z",
                                                id: "svg_222"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_274",
                                    viewBox: "0 0 751 999",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m746,4l0,990l-494,0l0,-248l-248,0l0,-494l248,0l0,-248l494,0z",
                                            fill: "#5c6666",
                                            id: "svg_223"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m717,4l0,990l-434,0l0,-284l-279,0l0,-427l279,0l0,-279l434,0z",
                                            fill: "#757f7f",
                                            id: "svg_224"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m675,4l0,990l-350,0l0,-320l-321,0l0,-350l321,0l0,-320l350,0z",
                                            fill: "#919999",
                                            id: "svg_225"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m643,4l0,990l-288,0l0,-351l-351,0l0,-288l351,0l0,-351l288,0z",
                                            fill: "#aab2b2",
                                            id: "svg_256"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m624,4l0,990l-248,0l0,-371l-372,0l0,-248l372,0l0,-371l248,0z",
                                            fill: "#c7cccc",
                                            id: "svg_257"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m602,4l0,990l-206,0l0,-392l-392,0l0,-206l392,0l0,-392l206,0z",
                                            fill: "#e0e5e5",
                                            id: "svg_258"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m572,4l0,990l-144,0l0,-423l-424,0l0,-144l424,0l0,-423l144,0z",
                                            fill: "#fcffff",
                                            id: "svg_259"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m4,252l248,0l0,-248",
                                            fill: "none",
                                            id: "svg_260",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m746,4l0,990",
                                            fill: "none",
                                            id: "svg_261",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m252,994l0,-248l-248,0",
                                            fill: "none",
                                            id: "svg_262",
                                            stroke: "#4c4c4c",
                                            "stroke-width": "2"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_277",
                                    transform: "rotate(90)",
                                    viewBox: "0 0 503.607 503.607",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_270",
                                            "stroke-width": "0"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_267",
                                            "stroke-linecap": "round",
                                            "stroke-linejoin": "round"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_264",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                                id: "svg_216",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                                    id: "svg_263",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "m486.82,159.47l-33.57,0c-9.25,0 -16.79,7.53 -16.79,16.79l0,8.4l-88.47,0c-2.35,-3.35 -4.81,-6.61 -7.48,-9.69l-29.35,29.35c-1.64,1.64 -3.78,2.46 -5.93,2.46s-4.3,-0.82 -5.94,-2.46c-3.28,-3.28 -3.28,-8.59 0,-11.87l29.35,-29.35c-18.64,-16.16 -42.36,-26.52 -68.44,-28.38l0,41.54c0,4.64 -3.76,8.4 -8.4,8.4c-4.63,0 -8.39,-3.76 -8.39,-8.4l0,-41.54c-26.08,1.86 -49.81,12.22 -68.44,28.38l29.35,29.35c3.28,3.28 3.28,8.59 0,11.87c-1.64,1.64 -3.78,2.46 -5.93,2.46c-2.15,0 -4.3,-0.82 -5.94,-2.46l-29.35,-29.35c-2.67,3.08 -5.13,6.34 -7.48,9.69l-88.47,0l0,-8.4c0,-9.26 -7.53,-16.79 -16.79,-16.79l-33.57,0c-9.25,0 -16.79,7.53 -16.79,16.79l0,151.08c0,9.26 7.54,16.79 16.79,16.79l33.57,0c9.26,0 16.79,-7.53 16.79,-16.79l0,-8.39l88.47,0c2.35,3.35 4.81,6.61 7.48,9.69l29.35,-29.35c3.29,-3.28 8.6,-3.28 11.87,0c3.28,3.28 3.28,8.59 0,11.86l-29.35,29.35c18.63,16.17 42.36,26.53 68.44,28.38l0,-41.54c0,-4.64 3.76,-8.39 8.39,-8.39c4.64,0 8.4,3.75 8.4,8.39l0,41.54c26.08,-1.85 49.8,-12.21 68.45,-28.37l-29.36,-29.36c-3.28,-3.27 -3.28,-8.58 0,-11.86c3.28,-3.28 8.59,-3.28 11.87,0l29.35,29.35c2.67,-3.08 5.13,-6.34 7.48,-9.69l88.47,0l0,8.39c0,9.26 7.54,16.79 16.79,16.79l33.57,0c9.26,0 16.79,-7.53 16.79,-16.79l0,-151.08c0,-9.26 -7.53,-16.79 -16.79,-16.79zm-351.85,104.46c0.13,1.18 0.34,2.34 0.49,3.51c0.39,2.85 0.85,5.69 1.44,8.48c0.27,1.32 0.6,2.63 0.92,3.94c0.66,2.66 1.41,5.27 2.25,7.86c0.41,1.28 0.81,2.57 1.27,3.84c1.02,2.79 2.15,5.51 3.37,8.19c0.35,0.79 0.61,1.62 0.99,2.41l-78.55,0l0,-67.15l25.18,0c4.64,0 8.39,-3.75 8.39,-8.39c0,-4.64 -3.75,-8.39 -8.39,-8.39l-25.18,0l0,-16.79l78.55,0c-0.38,0.79 -0.64,1.62 -0.99,2.41c-1.22,2.69 -2.35,5.41 -3.36,8.19c-0.47,1.28 -0.87,2.56 -1.28,3.85c-0.84,2.58 -1.59,5.19 -2.25,7.85c-0.32,1.31 -0.65,2.62 -0.92,3.95c-0.59,2.78 -1.05,5.61 -1.44,8.47c-0.15,1.17 -0.36,2.33 -0.48,3.51c-0.42,3.99 -0.68,8.03 -0.68,12.13c-0.01,4.11 0.26,8.14 0.67,12.13zm41.29,-3.73l-24.78,0c-0.24,-2.79 -0.4,-5.58 -0.4,-8.4c0,-2.81 0.16,-5.6 0.4,-8.39l24.78,0c4.64,0 8.4,3.75 8.4,8.39c0,4.64 -3.76,8.4 -8.4,8.4zm106.66,-27.64l-50.36,50.36c-1.64,1.64 -3.79,2.46 -5.94,2.46c-2.14,0 -4.29,-0.83 -5.93,-2.46c-3.27,-3.28 -3.27,-8.59 0,-11.87l50.36,-50.36c3.28,-3.28 8.6,-3.28 11.87,0c3.28,3.28 3.28,8.59 0,11.87zm69.22,27.64l-24.8,0c-4.63,0 -8.39,-3.76 -8.39,-8.4c0,-4.64 3.76,-8.39 8.39,-8.39l24.8,0c0.23,2.79 0.38,5.58 0.38,8.39c0,2.82 -0.15,5.61 -0.38,8.4zm84.32,-41.97l-16.79,0c-4.63,0 -8.39,3.75 -8.39,8.39c0,4.64 3.76,8.4 8.39,8.4l16.79,0l0,67.14l-78.55,0c0.38,-0.78 0.63,-1.62 0.99,-2.41c1.22,-2.68 2.35,-5.4 3.37,-8.19c0.46,-1.27 0.86,-2.56 1.28,-3.84c0.83,-2.59 1.58,-5.2 2.24,-7.86c0.32,-1.31 0.65,-2.62 0.93,-3.94c0.59,-2.79 1.05,-5.63 1.42,-8.48c0.16,-1.17 0.37,-2.33 0.5,-3.51c0.41,-3.98 0.67,-8.02 0.67,-12.13c0,-4.1 -0.26,-8.14 -0.67,-12.12c-0.13,-1.19 -0.34,-2.35 -0.5,-3.51c-0.05,-0.39 -0.1,-0.77 -0.15,-1.15l18.11,0c4.64,0 8.39,-3.75 8.39,-8.39c0,-4.65 -3.75,-8.4 -8.39,-8.4l-21.77,0c-0.25,-0.79 -0.53,-1.56 -0.79,-2.34c-0.41,-1.28 -0.81,-2.57 -1.27,-3.84c-1.02,-2.79 -2.16,-5.51 -3.37,-8.2c-0.36,-0.78 -0.61,-1.62 -0.99,-2.4l78.55,0l0,16.78z",
                                                        id: "svg_282"
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("symbol", {
                                    height: "800px",
                                    id: "svg_314",
                                    viewBox: "0 0 503.607 503.607",
                                    width: "800px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                        id: "svg_330",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_331",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                                id: "svg_332",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "m485.7,297.97l-49.24,0l0,-15.67c0,-9.89 -8.01,-17.91 -17.9,-17.91l-31.35,0c-9.89,0 -17.9,8.02 -17.9,17.91l0,15.67l-44.54,0l-15.14,-40.38c35.63,-20.18 59.68,-58.44 59.68,-102.31c0,-64.9 -52.61,-117.51 -117.51,-117.51c-64.9,0 -117.5,52.61 -117.5,117.51c0,43.87 24.05,82.13 59.68,102.31l-15.14,40.38l-44.54,0l0,-15.67c0,-9.89 -8.02,-17.91 -17.91,-17.91l-31.34,0c-9.89,0 -17.9,8.02 -17.9,17.91l0,15.67l-49.25,0c-9.89,0 -17.9,8.01 -17.9,17.9l0,98.49c0,9.89 8.01,17.9 17.9,17.9l49.25,0l0,15.67c0,9.89 8.01,17.91 17.9,17.91l31.34,0c9.89,0 17.9,-8.02 17.9,-17.91l0,-15.67l235.02,0l0,15.67c0,9.89 8.01,17.91 17.9,17.91l31.34,0c9.89,0 17.91,-8.02 17.91,-17.91l0,-15.67l49.24,0c9.89,0 17.9,-8.01 17.9,-17.9l0,-98.49c0.01,-9.89 -8.01,-17.9 -17.9,-17.9zm-334.27,-134.3l33.23,0c4.63,0 8.39,-3.76 8.39,-8.39s-3.76,-8.4 -8.39,-8.4l-33.23,0c4.27,-51.7 47.57,-92.32 100.37,-92.32c52.81,0 96.11,40.62 100.37,92.32l-33.22,0c-4.64,0 -8.39,3.76 -8.39,8.4s3.75,8.39 8.39,8.39l33.22,0c-2.96,35.9 -24.75,66.46 -55.47,81.79c-0.41,0.12 -0.82,0.27 -1.22,0.46c-11.15,5.38 -23.03,8.68 -35.28,9.72l0,-33.21c0,-4.64 -3.76,-8.4 -8.4,-8.4c-4.63,0 -8.39,3.76 -8.39,8.4l0,33.21c-12.25,-1.04 -24.14,-4.34 -35.28,-9.72c-0.4,-0.19 -0.81,-0.34 -1.23,-0.46c-30.72,-15.33 -52.5,-45.89 -55.47,-81.79zm57.76,101.15c11.57,4.5 24.02,7.22 37.02,7.83c0.32,0.01 0.63,0.02 0.95,0.04c0.59,0.02 1.19,0.04 1.79,0.06c0.95,0.02 1.9,0.03 2.85,0.03s1.91,-0.01 2.86,-0.03c0.6,-0.02 1.19,-0.04 1.79,-0.06c0.31,-0.02 0.63,-0.03 0.95,-0.04c13,-0.61 25.45,-3.33 37.01,-7.83l12.43,33.15l-110.07,0l12.42,-33.15zm-191.29,150.66c-0.62,0 -1.11,-0.5 -1.11,-1.12l0,-98.49c0,-0.62 0.49,-1.12 1.11,-1.12l49.25,0l0,100.73l-49.25,0zm98.49,33.57l-31.34,0c-0.62,0 -1.11,-0.5 -1.11,-1.12l0,-24.06l0,-117.51l0,-24.06c0,-0.62 0.49,-1.12 1.11,-1.12l31.34,0c0.62,0 1.12,0.5 1.12,1.12l0,24.03c0,0.01 0,0.02 0,0.03l0,117.51c0,0.01 0,0.02 0,0.03l0,24.03c0,0.62 -0.5,1.12 -1.12,1.12zm252.92,-33.57l-235.02,0l0,-100.73l50.37,0l134.29,0l50.36,0l0,100.73zm50.36,32.45c0,0.62 -0.5,1.12 -1.11,1.12l-31.34,0c-0.62,0 -1.12,-0.5 -1.12,-1.12l0,-165.63c0,-0.62 0.5,-1.12 1.12,-1.12l31.34,0c0.62,0 1.11,0.5 1.11,1.12l0,24.06l0,117.51l0,24.06zm67.15,-33.57c0,0.62 -0.5,1.11 -1.12,1.11l-49.24,0l0,-100.72l49.24,0c0.62,0 1.12,0.5 1.12,1.12l0,98.49z",
                                                        id: "svg_333"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "m251.8,180.46c13.9,0 25.18,-11.28 25.18,-25.18c0,-10.96 -7.01,-20.28 -16.78,-23.74l0,-26.62c0,-4.64 -3.76,-8.4 -8.4,-8.4c-4.63,0 -8.39,3.76 -8.39,8.4l0,26.62c-9.78,3.46 -16.79,12.78 -16.79,23.74c0,13.9 11.28,25.18 25.18,25.18zm0,-33.58c4.63,0 8.4,3.77 8.4,8.4s-3.77,8.39 -8.4,8.39c-4.63,0 -8.39,-3.76 -8.39,-8.39s3.76,-8.4 8.39,-8.4z",
                                                        id: "svg_334"
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "64px",
                                    id: "svg_367",
                                    viewBox: "0 0 45.513 45.512",
                                    width: "64px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_366",
                                            "stroke-width": "0"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_365",
                                            "stroke-linecap": "round",
                                            "stroke-linejoin": "round"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_364",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                                id: "svg_153",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m44.27,19.74l-14.06,-14.06c-0.91,-0.91 -2.27,-1.18 -3.46,-0.69c-1.19,0.49 -1.96,1.65 -1.96,2.94l0.02,5.9l-21.64,0.05c-1.76,0.01 -3.17,1.43 -3.17,3.19l0.03,11.52c0,0.84 0.34,1.65 0.93,2.24s1.41,0.93 2.25,0.92l21.64,-0.05l0.01,5.9c0.01,1.29 0.78,2.44 1.98,2.93c1.18,0.49 2.55,0.21 3.46,-0.7l13.99,-14.14c1.64,-1.65 1.63,-4.31 -0.02,-5.95z",
                                                    id: "svg_163"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("symbol", {
                                    height: "800px",
                                    id: "svg_370",
                                    viewBox: "0 0 512 512",
                                    width: "800px",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("polygon", {
                                            fill: "#36A1CB",
                                            id: "svg_164",
                                            points: "268.242,443.238 266.684,443.238 245.316,443.238 243.758,443.238 183.781,443.238   166.535,473.576 243.758,473.576 245.316,473.576 266.684,473.576 268.242,473.576 345.465,473.576 328.219,443.238 "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m202.31,482.26c-1,-1.92 -0.96,-4.22 0.1,-6.12l15.77,-28.31c1.26,-2.26 3.76,-3.56 6.34,-3.28l-26.26,-2.81c-2.58,-0.28 -5.08,1.02 -6.34,3.28l-15.77,28.31c-1.06,1.9 -1.09,4.2 -0.1,6.12c1,1.93 2.9,3.23 5.06,3.46l26.26,2.81c-2.16,-0.23 -4.06,-1.53 -5.06,-3.46z",
                                            fill: "#2393B5",
                                            id: "svg_281"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m390.77,253.91c9.3,-19.46 14.52,-41.23 14.52,-64.2c0,-82.32 -66.97,-149.29 -149.29,-149.29s-149.29,66.97 -149.29,149.29s66.97,149.29 149.29,149.29c49.49,0 93.43,-24.21 120.61,-61.4",
                                            fill: "#DFDBCC",
                                            id: "svg_288"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m256,371.33c-100.15,0 -181.62,-81.47 -181.62,-181.62c0,-100.15 81.47,-181.63 181.62,-181.63c100.15,0 181.63,81.48 181.63,181.63c0,100.15 -81.48,181.62 -181.63,181.62zm134.77,-117.42c9.3,-19.46 14.52,-41.23 14.52,-64.2c0,-82.32 -66.97,-149.29 -149.29,-149.29s-149.29,66.97 -149.29,149.29s66.97,149.29 149.29,149.29c49.49,0 93.43,-24.21 120.61,-61.4",
                                            fill: "#CCC3A8",
                                            id: "svg_289"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m372.45,291.54c4.18,-4.46 8.09,-9.16 11.69,-14.1l14.16,-23.68c9.31,-19.46 14.52,-41.23 14.52,-64.2c0,-72.71 -52.24,-133.43 -121.16,-146.62c-49.98,18.4 -85.72,66.49 -85.72,122.78c0,72.11 58.67,130.78 130.78,130.78c12.39,0 24.37,-1.74 35.73,-4.96z",
                                            fill: "#E5E2DC",
                                            id: "svg_290"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m154.48,83.85l13.15,17.18c0,0 -39.02,49.51 -40.63,84.46l-16.71,0c0,0 4.85,-63.6 44.19,-101.64z",
                                            fill: "#36A1CB",
                                            id: "svg_293"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m253.71,39.74l-1.07,21.61c0,0 -61.77,12.57 -85.59,38.19l-12.75,-10.8c0,0 44.8,-45.4 99.41,-49z",
                                            fill: "#4BAF78",
                                            id: "svg_295"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m361.18,81.51l-16.07,14.48c0,0 -52.49,-34.89 -87.45,-33.69l-1.35,-16.65c0,0 63.79,-0.29 104.87,35.86z",
                                            fill: "#FFB92E",
                                            id: "svg_296"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m403.36,186.26l-21.56,-1.76c0,0 -10.6,-62.13 -35.45,-86.75l11.19,-12.4c0,0 43.96,46.22 45.82,100.91z",
                                            fill: "#EA6428",
                                            id: "svg_299"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m248.91,221.66c-0.04,-0.02 -0.09,-0.03 -0.13,-0.05c-0.16,-0.06 -0.31,-0.12 -0.47,-0.19c-0.15,-0.06 -0.31,-0.12 -0.46,-0.19c-0.08,-0.04 -0.17,-0.08 -0.26,-0.11c-0.21,-0.1 -0.43,-0.2 -0.64,-0.31c-0.05,-0.02 -0.1,-0.05 -0.16,-0.08c-0.23,-0.12 -0.47,-0.24 -0.69,-0.37c-0.06,-0.03 -0.11,-0.06 -0.16,-0.09c-0.22,-0.13 -0.44,-0.26 -0.65,-0.39c-0.07,-0.05 -0.13,-0.09 -0.2,-0.13c-0.19,-0.13 -0.38,-0.25 -0.56,-0.38c-0.09,-0.07 -0.18,-0.13 -0.27,-0.2c-0.16,-0.11 -0.31,-0.23 -0.46,-0.34c-0.12,-0.09 -0.23,-0.19 -0.35,-0.28c-0.11,-0.1 -0.23,-0.19 -0.34,-0.29c-0.15,-0.12 -0.29,-0.25 -0.43,-0.38c-0.08,-0.07 -0.16,-0.15 -0.24,-0.22c-0.17,-0.16 -0.33,-0.32 -0.49,-0.48c-0.05,-0.05 -0.11,-0.11 -0.16,-0.17c-0.18,-0.18 -0.35,-0.37 -0.52,-0.56c-0.04,-0.04 -0.08,-0.08 -0.12,-0.13c-0.17,-0.2 -0.34,-0.4 -0.5,-0.61c-0.04,-0.04 -0.08,-0.09 -0.12,-0.14c-0.14,-0.18 -0.29,-0.37 -0.42,-0.56c-0.06,-0.08 -0.12,-0.16 -0.17,-0.24c-0.1,-0.13 -0.19,-0.27 -0.28,-0.41c-0.09,-0.14 -0.19,-0.28 -0.28,-0.42c-0.02,-0.04 -0.04,-0.08 -0.07,-0.12c-3.33,-5.41 -3.86,-12.38 -0.79,-18.47l0.32,-0.64c1.19,-2.14 2.8,-4.09 4.84,-5.7l67.25,-53.14l-38.58,76.53c-1.18,2.32 -2.76,4.3 -4.62,5.89l-0.56,0.44c-5.36,4.23 -12.29,5.11 -18.26,2.93z",
                                            fill: "#E35F46",
                                            id: "svg_302"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m256,371.33c-6.19,0 -12.3,-0.31 -18.32,-0.91l0,72.82l36.64,0l0,-72.82c-6.02,0.6 -12.14,0.91 -18.32,0.91z",
                                            fill: "#7C7A75",
                                            id: "svg_305"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m419.93,503.92l70.48,0c7.46,0 13.51,-6.05 13.51,-13.51l0,-3.32c0,-7.46 -6.05,-13.51 -13.51,-13.51l-81.2,0l-306.42,0l-81.2,0c-7.46,0 -13.51,6.05 -13.51,13.51l0,3.32c0,7.46 6.05,13.51 13.51,13.51l81.2,0l289.83,0",
                                            fill: "#CCC3A8",
                                            id: "svg_306"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "m37.9,490.25l0,-3.32c0,-7.46 6.04,-13.51 13.51,-13.51l-0.72,0l-21.56,0c-7.46,0 -13.51,6.05 -13.51,13.51l0,3.32c0,7.46 6.05,13.51 13.51,13.51l21.56,0l0.72,0c-7.46,0 -13.51,-6.05 -13.51,-13.51z",
                                            fill: "#C9B585",
                                            id: "svg_307"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                            id: "svg_310",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m256,347.08c50,0 97.53,-24.19 127.14,-64.71c2.63,-3.61 1.85,-8.67 -1.76,-11.3c-3.61,-2.63 -8.66,-1.85 -11.3,1.76c-26.57,36.37 -69.22,58.08 -114.08,58.08c-75.49,0 -137.33,-59.54 -141.03,-134.14l21.98,0c4.47,0 8.09,-3.62 8.09,-8.08c0,-3.54 -2.28,-6.54 -5.44,-7.63c1.77,-26.64 12.28,-50.65 28.68,-69.29c1.12,0.54 2.33,0.82 3.54,0.82c2.07,0 4.14,-0.79 5.72,-2.36c2.49,-2.5 3.01,-6.22 1.56,-9.23c18.74,-16.37 42.82,-26.76 69.38,-28.42c1.17,3.01 4.1,5.14 7.52,5.14c3.43,0 6.34,-2.13 7.52,-5.13c26.24,1.72 50.33,12.35 69.17,28.89c-1.18,2.92 -0.59,6.38 1.78,8.74c1.58,1.58 3.65,2.37 5.71,2.37c1.05,0 2.09,-0.2 3.07,-0.6c16.6,18.74 27.35,42.76 29.16,69.07c-3.17,1.09 -5.44,4.09 -5.44,7.63c0,4.46 3.62,8.08 8.08,8.08l21.98,0c-0.92,18.71 -5.46,36.73 -13.55,53.65c-1.93,4.03 -0.23,8.86 3.8,10.78c4.03,1.93 8.85,0.23 10.78,-3.8c10.16,-21.24 15.32,-44.02 15.32,-67.69c0,-86.78 -70.6,-157.37 -157.38,-157.37s-157.37,70.59 -157.37,157.37s70.59,157.37 157.37,157.37zm-104.87,-251.82l5.58,5.57c-19.77,22.2 -31.43,50.07 -33.29,79.78l-8.32,0c2.09,-32.71 15.36,-62.43 36.03,-85.35zm245.77,85.34l-8.32,0c-1.86,-29.7 -13.51,-57.57 -33.29,-79.77l5.58,-5.57c20.67,22.92 33.94,52.64 36.03,85.34zm-53.06,-91.18c-22.29,-19.71 -50.16,-31.22 -79.76,-33l0,-7.68c32.6,1.85 62.28,14.81 85.29,35.14l-5.53,5.54zm-95.92,-33c-29.59,1.78 -57.47,13.3 -79.76,33l-5.53,-5.54c23.01,-20.33 52.69,-33.29 85.29,-35.14l0,7.68z",
                                                    fill: "#231F20",
                                                    id: "svg_311"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m316.04,129.61c-2.95,-2.4 -7.15,-2.44 -10.13,-0.08l-67.25,53.14c-2.84,2.25 -5.16,4.98 -6.9,8.13c-0.04,0.09 -0.09,0.18 -0.14,0.26l-0.32,0.65c-4.25,8.43 -3.84,18.28 1.11,26.33c0.04,0.06 0.08,0.13 0.11,0.17c0.11,0.18 0.22,0.36 0.34,0.53l0.09,0.13c0.12,0.18 0.24,0.36 0.37,0.55c0.07,0.1 0.15,0.21 0.25,0.35c0.19,0.25 0.38,0.51 0.58,0.77c0.06,0.07 0.12,0.15 0.2,0.24c0.23,0.3 0.47,0.59 0.72,0.87l0.02,0.02c0.05,0.06 0.11,0.13 0.16,0.19c0.24,0.26 0.47,0.52 0.71,0.76l0.21,0.22c0.23,0.22 0.45,0.45 0.68,0.66c0.05,0.05 0.09,0.09 0.14,0.14l0.25,0.22c0.19,0.18 0.38,0.35 0.59,0.52c0.03,0.03 0.11,0.1 0.15,0.13c0.14,0.12 0.28,0.24 0.43,0.35l0.37,0.31c0.04,0.03 0.07,0.05 0.11,0.08c0.19,0.15 0.38,0.29 0.64,0.48l0.33,0.23c0.26,0.19 0.53,0.37 0.81,0.55c0.04,0.03 0.06,0.04 0.1,0.06c0.03,0.03 0.16,0.11 0.19,0.13c0.3,0.19 0.61,0.38 0.99,0.6l0.12,0.07l0,0c0.32,0.18 0.64,0.35 0.96,0.52c0.12,0.06 0.23,0.12 0.35,0.17c0.27,0.14 0.55,0.27 0.83,0.4c0.04,0.02 0.07,0.03 0.11,0.05l0.25,0.11c0.23,0.11 0.47,0.2 0.8,0.34c0.18,0.07 0.36,0.15 0.53,0.21c0.11,0.04 0.21,0.08 0.32,0.11c2.96,1.07 6.06,1.62 9.22,1.62c6.04,0 11.99,-2.07 16.73,-5.82l0.56,-0.44c0.08,-0.07 0.17,-0.13 0.25,-0.2c2.73,-2.34 4.95,-5.16 6.58,-8.4l38.58,-76.53c1.71,-3.39 0.83,-7.51 -2.1,-9.9zm-50.91,79.15c-0.64,1.27 -1.5,2.37 -2.54,3.29l-0.44,0.34c-1.93,1.53 -4.25,2.34 -6.71,2.34c-1.27,0 -2.52,-0.22 -3.71,-0.65c-0.05,-0.02 -0.1,-0.04 -0.14,-0.05l-0.24,-0.1c-0.02,-0.01 -0.09,-0.04 -0.11,-0.04l-0.26,-0.12l0,0c-0.13,-0.05 -0.26,-0.11 -0.38,-0.18c-0.04,-0.01 -0.08,-0.03 -0.11,-0.05c-0.13,-0.06 -0.25,-0.13 -0.37,-0.2c-0.03,-0.01 -0.06,-0.03 -0.09,-0.05c-0.01,-0.01 -0.03,-0.01 -0.04,-0.02c-0.13,-0.07 -0.25,-0.15 -0.35,-0.21l-0.12,-0.08c-0.11,-0.07 -0.22,-0.14 -0.26,-0.17l-0.69,-0.52c-0.03,-0.02 -0.06,-0.05 -0.09,-0.07l-0.51,-0.45c-0.08,-0.08 -0.16,-0.16 -0.25,-0.25c-0.01,-0.01 -0.1,-0.11 -0.12,-0.12c-0.1,-0.1 -0.19,-0.21 -0.29,-0.31c-0.02,-0.03 -0.05,-0.07 -0.08,-0.1c-0.09,-0.11 -0.19,-0.22 -0.3,-0.37c-0.02,-0.02 -0.04,-0.04 -0.06,-0.06c-0.08,-0.1 -0.15,-0.21 -0.18,-0.25l-0.12,-0.16c-0.01,-0.02 -0.03,-0.04 -0.04,-0.07l-0.25,-0.36c0,0 -0.02,-0.03 -0.04,-0.06c-0.01,-0.02 -0.03,-0.05 -0.04,-0.07c-2,-3.25 -2.17,-7.21 -0.46,-10.59l0.24,-0.49c0.69,-1.22 1.6,-2.28 2.71,-3.16l38.56,-30.46l-22.12,43.87z",
                                                    fill: "#231F20",
                                                    id: "svg_341"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m300.94,260.15c0,-4.46 -3.62,-8.08 -8.09,-8.08l-73.3,0c-4.46,0 -8.08,3.62 -8.08,8.08c0,4.47 3.62,8.09 8.08,8.09l73.3,0c4.47,0 8.09,-3.62 8.09,-8.09z",
                                                    fill: "#231F20",
                                                    id: "svg_344"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m237.68,280.3c-4.47,0 -8.09,3.62 -8.09,8.08c0,4.47 3.62,8.09 8.09,8.09l36.64,0c4.47,0 8.09,-3.62 8.09,-8.09c0,-4.46 -3.62,-8.08 -8.09,-8.08l-36.64,0z",
                                                    fill: "#231F20",
                                                    id: "svg_360"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "m490.41,465.49l-140.24,0l-14.92,-26.25c-1.44,-2.53 -4.12,-4.09 -7.03,-4.09l-45.81,0l0,-57.58c92.15,-12.89 163.3,-92.22 163.3,-187.86c0,-104.61 -85.1,-189.71 -189.71,-189.71s-189.71,85.1 -189.71,189.71c0,95.64 71.15,174.97 163.3,187.86l0,57.58l-45.81,0c-2.91,0 -5.59,1.56 -7.03,4.09l-14.92,26.25l-140.24,0c-11.9,0 -21.59,9.69 -21.59,21.59l0,3.32c0,11.91 9.69,21.6 21.59,21.6l371.03,0c4.46,0 8.08,-3.62 8.08,-8.08s-3.62,-8.09 -8.08,-8.09l-371.03,0c-2.99,0 -5.42,-2.43 -5.42,-5.42l0,-3.32c0,-2.99 2.43,-5.43 5.42,-5.43l144.94,0l178.93,0l144.95,0c2.99,0 5.42,2.44 5.42,5.43l0,3.32c0,2.99 -2.43,5.42 -5.42,5.42l-70.48,0c-4.47,0 -8.09,3.62 -8.09,8.09s3.62,8.08 8.09,8.08l70.48,0c11.9,0 21.59,-9.69 21.59,-21.59l0,-3.32c0,-11.91 -9.69,-21.6 -21.59,-21.6zm-407.95,-275.78c0,-95.69 77.85,-173.54 173.54,-173.54s173.54,77.85 173.54,173.54c0,89.94 -68.78,164.11 -156.5,172.7c-11.29,1.11 -22.79,1.11 -34.08,0c-87.72,-8.59 -156.5,-82.76 -156.5,-172.7zm163.3,189.43c0.04,0 0.08,0 0.12,0.01c1.49,0.08 2.99,0.13 4.49,0.18c0.19,0 0.37,0.01 0.56,0.02c1.68,0.04 3.37,0.07 5.07,0.07c1.7,0 3.39,-0.03 5.07,-0.07c0.19,-0.01 0.37,-0.02 0.56,-0.02c1.5,-0.05 3,-0.1 4.49,-0.18c0.04,-0.01 0.08,-0.01 0.12,-0.01l0,56.01l-20.48,0l0,-56.01zm-65.33,86.35l8.06,-14.17l49.19,0l36.64,0l49.2,0l8.05,14.17l-151.14,0z",
                                                    fill: "#231F20",
                                                    id: "svg_361"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                            className: "layer",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("title", {
                                    children: "Layer 1"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                    id: "svg_80"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_183",
                                    transform: "rotate(-25 2724 1539.91)",
                                    x: "2692.32",
                                    href: "#svg_111",
                                    y: "1507.94"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_273",
                                    transform: "rotate(35 3207 1508.53)",
                                    x: "3175.46",
                                    href: "#svg_218",
                                    y: "1476.56"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_101",
                                    transform: "rotate(-90 273.649 -6690.77) matrix(1.13944 0 0 0.378697 1150.24 -14.0407)",
                                    x: "-624.33",
                                    href: "#svg_78",
                                    y: "-594.83"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "0",
                                    id: "svg_185",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "0",
                                    x: "624.49",
                                    y: "266.77"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("ellipse", {
                                    cx: "619.79",
                                    cy: "260.89",
                                    fill: "#ede8e8",
                                    id: "svg_187",
                                    opacity: "0.5",
                                    rx: "0",
                                    ry: "0",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_469",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "353.53",
                                    x: "542.7",
                                    y: "195.29"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "0",
                                    id: "svg_470",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "9.41",
                                    x: "249.46",
                                    y: "141.74"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#b71616",
                                    height: "30.59",
                                    id: "svg_473",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "3.53",
                                    x: "688.87",
                                    y: "517.03"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#b71616",
                                    height: "32.94",
                                    id: "svg_478",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "3.53",
                                    x: "689.46",
                                    y: "228.47"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#b71616",
                                    height: "22.35",
                                    id: "svg_484",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "4.12",
                                    x: "521.49",
                                    y: "404.29"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_3",
                                    transform: "matrix(0.0744318 0 0 0.082906 19.502 294.248)",
                                    x: "-198.26",
                                    href: "#svg_2",
                                    y: "1507.59"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_66",
                                    transform: "matrix(0.0601252 0 0 0.0604648 48.8747 100.135)",
                                    x: "1780.81",
                                    href: "#svg_44",
                                    y: "5566.14"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_69",
                                    transform: "matrix(0.00142835 0.0503946 -0.0475773 0.00145901 586.046 -593.379)",
                                    x: "18100.86",
                                    href: "#svg_68",
                                    y: "6606.32"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_76",
                                    transform: "matrix(2.26307 0 0 2.31587 135.93 -498.134)",
                                    x: "62.41",
                                    href: "#svg_75",
                                    y: "369.54"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_161",
                                    transform: "matrix(0.0484696 0 0 0.0518252 9.33008 -3.37917)",
                                    x: "5463.48",
                                    href: "#svg_68",
                                    y: "8763.7"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_166",
                                    transform: "matrix(0.0484696 0 0 0.0518252 9.33008 -3.37917)",
                                    x: "7760.78",
                                    href: "#svg_68",
                                    y: "7116.78"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                    id: "svg_116",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                        id: "svg_117",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                                id: "svg_118",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                        id: "svg_119",
                                                        transform: "matrix(0.368377 0 0 0.355538 -195.352 15.3305)",
                                                        x: "1271.67",
                                                        href: "#svg_71",
                                                        y: "994.41"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                        id: "svg_120",
                                                        transform: "matrix(0.26393 0 0 0.422948 74.4517 9.07804)",
                                                        x: "840.4",
                                                        href: "#svg_78",
                                                        y: "856.31"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                fill: "#FF0000",
                                                height: "0",
                                                id: "svg_122",
                                                stroke: "#000000",
                                                width: "0",
                                                x: "236.76",
                                                y: "366.83"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_131",
                                    transform: "matrix(0.519084 0 0 0.562241 193.632 294.5)",
                                    x: "131.71",
                                    href: "#svg_130",
                                    y: "-52.37"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_343",
                                    transform: "matrix(0.519084 0 0 0.562241 193.632 294.5)",
                                    x: "1782.37",
                                    href: "#svg_130",
                                    y: "-234.63"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_162",
                                    transform: "matrix(0.452467 0 0 0.491235 1.78513 -95.1361)",
                                    x: "579.82",
                                    href: "#svg_109",
                                    y: "801.5"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_174",
                                    transform: "matrix(0.405544 0 0 0.440132 -296.692 -396.502)",
                                    x: "1830.21",
                                    href: "#svg_111",
                                    y: "1488.41"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_176",
                                    transform: "matrix(0.405034 0 0 0.441467 -265.486 -1276.69)",
                                    x: "1755.5",
                                    href: "#svg_175",
                                    y: "4012.06"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_207",
                                    transform: "matrix(0.441527 0 0 0.433241 -513.823 -1000.98)",
                                    x: "3091.22",
                                    href: "#svg_206",
                                    y: "2910.15"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_210",
                                    transform: "matrix(0.430247 0 0 0.454952 -707.414 -602.424)",
                                    x: "3624.09",
                                    href: "#svg_209",
                                    y: "2409.07"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_217",
                                    transform: "matrix(0.986925 0 0 2.46642 -65.1386 -752.474)",
                                    x: "845.81",
                                    href: "#svg_171",
                                    y: "415.88"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_220",
                                    transform: "matrix(0.428929 0 0 0.441872 -601.032 -1229.82)",
                                    x: "3225.18",
                                    href: "#svg_209",
                                    y: "3753.44"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_265",
                                    transform: "matrix(1.6762 0 0 0.516401 -3074.23 -516.383)",
                                    x: "2237.6",
                                    href: "#svg_167",
                                    y: "1836.44"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_269",
                                    transform: "matrix(0.0422181 0 0 0.0461079 153.973 74.0357)",
                                    x: "11637.45",
                                    href: "#svg_268",
                                    y: "7717.18"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_272",
                                    transform: "matrix(0.446535 0 0 0.440132 -378.136 -396.686)",
                                    x: "2095.48",
                                    href: "#svg_111",
                                    y: "1901.44"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_276",
                                    transform: "matrix(1.04272 0 0 0.629405 -148.079 154.36)",
                                    x: "653.33",
                                    href: "#svg_171",
                                    y: "497.09"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_285",
                                    transform: "matrix(1.043 0 0 0.836401 -125.712 73.605)",
                                    x: "591.67",
                                    href: "#svg_171",
                                    y: "159.72"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_278",
                                    transform: "matrix(-0.00406084 0.563427 -0.612504 -0.00520346 792.161 -347.295)",
                                    x: "925.58",
                                    href: "#svg_277",
                                    y: "398.35"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_294",
                                    transform: "matrix(0.427419 0 0 0.474948 -339.324 -537.984)",
                                    x: "2847.63",
                                    href: "#svg_167",
                                    y: "1916.85"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_297",
                                    transform: "matrix(1.03752 0 0 2.70141 -114.96 -877.448)",
                                    x: "956.73",
                                    href: "#svg_171",
                                    y: "440.6"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_300",
                                    transform: "matrix(0.431329 0 0 0.441438 -371.335 -563.978)",
                                    x: "2953.07",
                                    href: "#svg_175",
                                    y: "2349.18"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_303",
                                    transform: "matrix(0.431712 0 0 0.440046 -337.449 -1113.06)",
                                    x: "2871.92",
                                    href: "#svg_111",
                                    y: "3184.72"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_308",
                                    transform: "matrix(0.441527 0 0 0.433241 -513.546 -998.266)",
                                    x: "3464.46",
                                    href: "#svg_206",
                                    y: "2970.27"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_319",
                                    transform: "matrix(0.443431 0 0 0.454952 -757.602 -605.996)",
                                    x: "3998.8",
                                    href: "#svg_209",
                                    y: "2368.61"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_335",
                                    transform: "matrix(0 0.483443 -0.498953 0 818.691 222.562)",
                                    x: "296.28",
                                    href: "#svg_274",
                                    y: "-548.74"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_336",
                                    transform: "matrix(0 0.502315 -0.498953 0 818.691 216.472)",
                                    x: "296.07",
                                    href: "#svg_274",
                                    y: "-668.36"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_337",
                                    transform: "matrix(1.03752 0 0 0.557804 -114.96 128.12)",
                                    x: "1116.43",
                                    href: "#svg_171",
                                    y: "387.16"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_338",
                                    transform: "matrix(1.03752 0 0 1.82198 -114.96 -551.759)",
                                    x: "1173.21",
                                    href: "#svg_171",
                                    y: "408.99"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_339",
                                    transform: "matrix(0.000223074 0.563445 -0.640857 0.000299066 1485.65 -809.47)",
                                    x: "1985.7",
                                    href: "#svg_277",
                                    y: "607.79"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_340",
                                    transform: "matrix(1.03752 0 0 0.53354 -114.96 97.4352)",
                                    x: "1172.99",
                                    href: "#svg_171",
                                    y: "461.91"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_342",
                                    transform: "matrix(0.0000514839 0.563445 -0.640858 0.0000690222 1546.95 -812.773)",
                                    x: "1991.81",
                                    href: "#svg_277",
                                    y: "610.47"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_359",
                                    transform: "matrix(3.38455 0 0 0.516546 -7039.32 -1228.34)",
                                    x: "2386.9",
                                    href: "#svg_167",
                                    y: "3092.52"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_368",
                                    transform: "matrix(1.07951 0 0 0.832341 1.08626 -65.1839)",
                                    x: "1160.62",
                                    href: "#svg_367",
                                    y: "509.01"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                    id: "svg_347",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                            id: "svg_348",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                    id: "svg_349",
                                                    transform: "matrix(0.351184 0 0 0.31834 -177.479 34.5086)",
                                                    x: "1119.25",
                                                    href: "#svg_71",
                                                    y: "684.06"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                    id: "svg_350",
                                                    transform: "matrix(0.251612 0 0 0.378698 81.3168 107.9)",
                                                    x: "621.36",
                                                    href: "#svg_78",
                                                    y: "386.81"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                    id: "svg_351",
                                                    transform: "matrix(0.251612 0 0 0.378697 374.071 -14.0407)",
                                                    x: "-545.79",
                                                    href: "#svg_78",
                                                    y: "553.09"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                            fill: "#FF0000",
                                            height: "0",
                                            id: "svg_352",
                                            stroke: "#000000",
                                            width: "0",
                                            x: "217.05",
                                            y: "268.34"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                            id: "svg_353",
                                            transform: "matrix(0.420688 0 0 0.493675 -79.606 -312.968)",
                                            x: "685.77",
                                            href: "#svg_109",
                                            y: "1083.08"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                            id: "svg_354",
                                            transform: "matrix(0.353337 0 0 0.322881 -250.265 -68.7027)",
                                            x: "1318.18",
                                            href: "#svg_111",
                                            y: "836.56"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_51",
                                    transform: "rotate(-90 221.806 554.348) matrix(0.351184 0 0 0.31834 -177.479 34.5086)",
                                    x: "1105",
                                    href: "#svg_71",
                                    y: "1601"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_52",
                                    transform: "rotate(-90 225.662 510.349) matrix(1.0834 0 0 0.378698 -478.482 109.9)",
                                    x: "618.18",
                                    href: "#svg_78",
                                    y: "1025.89"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#FF0000",
                                    height: "0",
                                    id: "svg_54",
                                    stroke: "#000000",
                                    transform: "rotate(-90 190.699 564.696)",
                                    width: "0",
                                    x: "190.7",
                                    y: "564.7"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_57",
                                    transform: "matrix(2.16357e-17 -0.353337 0.322881 1.97708e-17 -435.35 1022.19)",
                                    x: "1291.64",
                                    href: "#svg_111",
                                    y: "1726"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_499",
                                    transform: "rotate(-90 254.479 509.528) matrix(1.0834 0 0 0.378698 -478.482 109.9)",
                                    x: "644.65",
                                    href: "#svg_78",
                                    y: "1023.61"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_355",
                                    transform: "matrix(-0.00334312 0.502314 -0.46086 -0.00359458 487.164 -481.675)",
                                    x: "1455.67",
                                    href: "#svg_130",
                                    y: "438.82"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    fill: "#ffffff",
                                    id: "svg_356",
                                    transform: "matrix(0.597011 0 0 0.627796 199.104 151.955)",
                                    x: "73.35",
                                    href: "#svg_138",
                                    y: "51.76"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#FF0000",
                                    height: "0",
                                    id: "svg_102",
                                    stroke: "#000000",
                                    transform: "rotate(-90 315.666 564.603)",
                                    width: "0",
                                    x: "315.67",
                                    y: "564.6"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_110",
                                    transform: "matrix(2.16357e-17 -0.353337 0.322881 1.97708e-17 -388.044 1139.14)",
                                    x: "1622.63",
                                    href: "#svg_111",
                                    y: "1969.65"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_61",
                                    transform: "matrix(2.15038e-17 -0.351184 0.31834 1.94927e-17 -113.748 1250.55)",
                                    x: "1948.73",
                                    href: "#svg_71",
                                    y: "1675.89"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_100",
                                    transform: "matrix(0 -2.50997 0.378698 0 46.5193 2669.03)",
                                    x: "844.75",
                                    href: "#svg_78",
                                    y: "991.4"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_107",
                                    transform: "matrix(0 -0.420688 2.53508 0 -4501.28 1016.93)",
                                    x: "1055.77",
                                    href: "#svg_109",
                                    y: "1880.45"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_108",
                                    transform: "matrix(0.0556097 0 0 0.0573096 366.886 31.3889)",
                                    x: "-742.25",
                                    href: "#svg_314",
                                    y: "8647.23"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_316",
                                    transform: "matrix(0.0556097 0 0 0.0573096 366.886 31.3889)",
                                    x: "10509.03",
                                    href: "#svg_314",
                                    y: "4048.76"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                    id: "svg_321",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("g", {
                                            id: "svg_357",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                                id: "svg_358",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                                                        id: "svg_363",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                                id: "svg_369",
                                                                transform: "matrix(0.351184 0 0 0.31834 -177.479 34.5086)",
                                                                x: "3548.18",
                                                                href: "#svg_71",
                                                                y: "362.08"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                                id: "svg_374",
                                                                transform: "matrix(0.251612 0 0 0.378698 82.3168 104.9)",
                                                                x: "4007.53",
                                                                href: "#svg_78",
                                                                y: "124.08"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                                id: "svg_375",
                                                                transform: "matrix(0.251612 0 0 0.378697 375.071 -17.0407)",
                                                                x: "2840.38",
                                                                href: "#svg_78",
                                                                y: "290.36"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                        fill: "#FF0000",
                                                        height: "0",
                                                        id: "svg_376",
                                                        stroke: "#000000",
                                                        width: "0",
                                                        x: "1070.05",
                                                        y: "165.84"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                        id: "svg_377",
                                                        transform: "matrix(0.420688 0 0 0.493675 -79.606 -312.968)",
                                                        x: "2713.39",
                                                        href: "#svg_109",
                                                        y: "875.45"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                        id: "svg_378",
                                                        transform: "matrix(0.353337 0 0 0.322881 -250.265 -68.7027)",
                                                        x: "3732.31",
                                                        href: "#svg_111",
                                                        y: "519.11"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                            id: "svg_379",
                                            transform: "matrix(-0.00334312 0.502314 -0.46086 -0.00359458 464.165 -485.174)",
                                            x: "1248.94",
                                            href: "#svg_130",
                                            y: "-1464.81"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                            fill: "#ffffff",
                                            id: "svg_380",
                                            transform: "matrix(0.597011 0 0 0.627796 199.104 151.955)",
                                            x: "1505.48",
                                            href: "#svg_138",
                                            y: "-108.32"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_271",
                                    transform: "matrix(0.946107 0 0 0.516242 -1445.88 -1232.19)",
                                    x: "2146.9",
                                    href: "#svg_167",
                                    y: "3223.57"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_172",
                                    transform: "matrix(0.937107 0 0 3.3207 -21.5634 -1103.71)",
                                    x: "474.74",
                                    href: "#svg_171",
                                    y: "418.08"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_208",
                                    transform: "matrix(1.03752 0 0 3.33576 -109.623 -1112.95)",
                                    x: "912.95",
                                    href: "#svg_171",
                                    y: "417.99"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_320",
                                    transform: "matrix(1.03752 0 0 2.52047 -114.96 -796.936)",
                                    x: "1076.94",
                                    href: "#svg_171",
                                    y: "441.05"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_309",
                                    transform: "matrix(0.46112 0 0 0.516546 -165.051 -1232.76)",
                                    x: "2504.11",
                                    href: "#svg_167",
                                    y: "2928.84"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_301",
                                    transform: "matrix(0.46112 0 0 0.516546 -165.051 -1232.76)",
                                    x: "2371.78",
                                    href: "#svg_167",
                                    y: "2928.84"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_279",
                                    transform: "matrix(0 0.52059 -0.498953 0 818.691 216.188)",
                                    x: "532.2",
                                    href: "#svg_274",
                                    y: "558.85"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_371",
                                    transform: "matrix(0.0415566 0 0 0.0439526 126.367 81.3167)",
                                    x: "9155.39",
                                    href: "#svg_370",
                                    y: "7865.24"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_372",
                                    transform: "matrix(-0.000116236 0.563445 -0.612523 -0.000148943 1090.03 -769.972)",
                                    x: "2185.65",
                                    href: "#svg_277",
                                    y: "891.85"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_180",
                                    transform: "matrix(4.97414 0 0 0.516546 -10516.5 -520.116)",
                                    x: "2215.04",
                                    href: "#svg_167",
                                    y: "1970.46"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_65",
                                    transform: "matrix(1.23 0 0 0.493988 -624.192 -568.149)",
                                    x: "666.96",
                                    href: "#svg_34",
                                    y: "2072.71"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_384",
                                    transform: "matrix(0.0415566 0 0 0.0439526 126.367 81.3167)",
                                    x: "22460.06",
                                    href: "#svg_370",
                                    y: "4424.87"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_385",
                                    transform: "matrix(0.0484696 0 0 0.0518252 9.33008 -3.37917)",
                                    x: "9462.32",
                                    href: "#svg_68",
                                    y: "9590.54"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_386",
                                    transform: "matrix(0.0472809 0 0 0.0518252 31.4156 -3.37917)",
                                    x: "16635.15",
                                    href: "#svg_68",
                                    y: "9590.54"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_387",
                                    transform: "matrix(0.0472809 0 0 0.0518252 31.4156 -3.37917)",
                                    x: "16603.43",
                                    href: "#svg_68",
                                    y: "4824.51"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_388",
                                    transform: "matrix(0.0472809 0 0 0.0518252 31.4156 -3.37917)",
                                    x: "9285.46",
                                    href: "#svg_68",
                                    y: "4824.51"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_168",
                                    transform: "matrix(0.340828 0 0 0.529643 1380.82 -729.377)",
                                    x: "-2807.37",
                                    href: "#svg_167",
                                    y: "2074.45"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_113",
                                    transform: "matrix(0.0556097 0 0 0.0573096 366.886 31.3889)",
                                    x: "10504.79",
                                    href: "#svg_314",
                                    y: "7446.7"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_318",
                                    transform: "matrix(0.446333 0 0 0.516546 -155.268 -521.116)",
                                    x: "2561.1",
                                    href: "#svg_167",
                                    y: "1929.27"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_304",
                                    transform: "matrix(0.46112 0 0 0.516546 -159.463 -1197.12)",
                                    x: "2361.81",
                                    href: "#svg_167",
                                    y: "3239.89"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_177",
                                    transform: "matrix(4.91108 0 0 0.516546 -10375.8 -520.116)",
                                    x: "2215.71",
                                    href: "#svg_167",
                                    y: "1492.51"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_383",
                                    transform: "matrix(0.0415566 0 0 0.0439526 126.367 81.3167)",
                                    x: "9201.04",
                                    href: "#svg_370",
                                    y: "1262.38"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#b71616",
                                    height: "22.35",
                                    id: "svg_481",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "3.53",
                                    x: "523.84",
                                    y: "113.76"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#b71616",
                                    height: "14.71",
                                    id: "svg_487",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "3.53",
                                    x: "1075.02",
                                    y: "260.63"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_497",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "228.24",
                                    x: "308.38",
                                    y: "90"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_498",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "228.24",
                                    x: "503.38",
                                    y: "371.41"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ffff00",
                                    height: "40",
                                    id: "svg_212",
                                    rx: "5",
                                    ry: "5",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "116.47",
                                    x: "630.96",
                                    y: "246.77"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ffff00",
                                    height: "40",
                                    id: "svg_472",
                                    rx: "5",
                                    ry: "5",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "116.47",
                                    x: "631.23",
                                    y: "492.33"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_490",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "353.53",
                                    x: "542.5",
                                    y: "160"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_491",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "353.53",
                                    x: "542.5",
                                    y: "125"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_492",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "353",
                                    x: "542.5",
                                    y: "90"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_493",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "353.53",
                                    x: "542.5",
                                    y: "547.29"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_494",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "353.53",
                                    x: "542.5",
                                    y: "582.59"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_495",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "353.53",
                                    x: "543.09",
                                    y: "617.88"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_496",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "353.53",
                                    x: "543.09",
                                    y: "653"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                    fill: "#ede8e8",
                                    height: "32.94",
                                    id: "svg_49",
                                    rx: "3",
                                    ry: "3",
                                    stroke: "#e5e5e5",
                                    "stroke-linecap": "round",
                                    width: "186.99",
                                    x: "928.38",
                                    y: "228.65"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_55",
                                    transform: "matrix(0 -0.420688 1.23424 0 -2131.62 801.776)",
                                    x: "545.57",
                                    href: "#svg_109",
                                    y: "1839.77"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_178",
                                    transform: "matrix(0.0556097 0 0 0.0558888 366.886 45.8319)",
                                    x: "-3809.26",
                                    href: "#svg_314",
                                    y: "8605.89"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_53",
                                    transform: "rotate(-90 128.187 510.117) matrix(1.0834 0 0 0.378698 -478.482 109.9)",
                                    x: "528",
                                    href: "#svg_78",
                                    y: "1024.86"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                    id: "svg_62",
                                    transform: "matrix(1.23328 0 0 0.493988 -586.942 -569.149)",
                                    x: "543.69",
                                    href: "#svg_34",
                                    y: "2073.09"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(DataOTK, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(TextGraphic, {})
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const page = (GraphicOTK);


/***/ }),

/***/ 1853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\OTSUKA\graphic-otk\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 95083:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,6065,2547,4972,63], () => (__webpack_exec__(12989)));
module.exports = __webpack_exports__;

})();