(() => {
var exports = {};
exports.id = 7805;
exports.ids = [7805,2547,5377];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 97880:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'uikit',
        {
        children: [
        'table',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 51396)), "D:\\sogec\\sogec-web\\app\\(main)\\uikit\\table\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\uikit\\table\\page.tsx"];
    
    const originalPathname = "/(main)/uikit/table/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 11151:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 29121))

/***/ }),

/***/ 29121:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(90284);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18176);
/* harmony import */ var primereact_calendar__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(52186);
/* harmony import */ var primereact_column__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(59210);
/* harmony import */ var primereact_datatable__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(14760);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1042);
/* harmony import */ var primereact_inputnumber__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(14719);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(71785);
/* harmony import */ var primereact_multiselect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(61326);
/* harmony import */ var primereact_progressbar__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(72085);
/* harmony import */ var primereact_rating__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(59141);
/* harmony import */ var primereact_slider__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(34713);
/* harmony import */ var primereact_togglebutton__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(556);
/* harmony import */ var primereact_tristatecheckbox__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(10895);
/* harmony import */ var primereact_utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7666);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _demo_service_CustomerService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(85192);
/* harmony import */ var _demo_service_ProductService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(95377);
/* __next_internal_client_entry_do_not_use__ default auto */ 


















const TableDemo = ()=>{
    const [customers1, setCustomers1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [customers2, setCustomers2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [customers3, setCustomers3] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [filters1, setFilters1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [loading1, setLoading1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [loading2, setLoading2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [idFrozen, setIdFrozen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [products, setProducts] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [globalFilterValue1, setGlobalFilterValue1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [expandedRows, setExpandedRows] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [allExpanded, setAllExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const representatives = [
        {
            name: "Amy Elsner",
            image: "amyelsner.png"
        },
        {
            name: "Anna Fali",
            image: "annafali.png"
        },
        {
            name: "Asiya Javayant",
            image: "asiyajavayant.png"
        },
        {
            name: "Bernardo Dominic",
            image: "bernardodominic.png"
        },
        {
            name: "Elwin Sharvill",
            image: "elwinsharvill.png"
        },
        {
            name: "Ioni Bowcher",
            image: "ionibowcher.png"
        },
        {
            name: "Ivan Magalhaes",
            image: "ivanmagalhaes.png"
        },
        {
            name: "Onyama Limba",
            image: "onyamalimba.png"
        },
        {
            name: "Stephen Shaw",
            image: "stephenshaw.png"
        },
        {
            name: "XuXue Feng",
            image: "xuxuefeng.png"
        }
    ];
    const statuses = [
        "unqualified",
        "qualified",
        "new",
        "negotiation",
        "renewal",
        "proposal"
    ];
    const clearFilter1 = ()=>{
        initFilters1();
    };
    const onGlobalFilterChange1 = (e)=>{
        const value = e.target.value;
        let _filters1 = {
            ...filters1
        };
        _filters1["global"].value = value;
        setFilters1(_filters1);
        setGlobalFilterValue1(value);
    };
    const renderHeader1 = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-content-between",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_4__.Button, {
                    type: "button",
                    icon: "pi pi-filter-slash",
                    label: "Clear",
                    outlined: true,
                    onClick: clearFilter1
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "p-input-icon-left",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                            className: "pi pi-search"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_5__.InputText, {
                            value: globalFilterValue1,
                            onChange: onGlobalFilterChange1,
                            placeholder: "Keyword Search"
                        })
                    ]
                })
            ]
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLoading2(true);
        _demo_service_CustomerService__WEBPACK_IMPORTED_MODULE_2__/* .CustomerService */ .v.getCustomersLarge().then((data)=>{
            setCustomers1(getCustomers(data));
            setLoading1(false);
        });
        _demo_service_CustomerService__WEBPACK_IMPORTED_MODULE_2__/* .CustomerService */ .v.getCustomersLarge().then((data)=>{
            setCustomers2(getCustomers(data));
            setLoading2(false);
        });
        _demo_service_CustomerService__WEBPACK_IMPORTED_MODULE_2__/* .CustomerService */ .v.getCustomersMedium().then((data)=>setCustomers3(data));
        _demo_service_ProductService__WEBPACK_IMPORTED_MODULE_3__/* .ProductService */ .M.getProductsWithOrdersSmall().then((data)=>setProducts(data));
        initFilters1();
    }, []);
    const balanceTemplate = (rowData)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-bold",
                children: formatCurrency(rowData.balance)
            })
        });
    };
    const getCustomers = (data)=>{
        return [
            ...data || []
        ].map((d)=>{
            d.date = new Date(d.date);
            return d;
        });
    };
    const formatDate = (value)=>{
        return value.toLocaleDateString("en-US", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric"
        });
    };
    const formatCurrency = (value)=>{
        return value.toLocaleString("en-US", {
            style: "currency",
            currency: "USD"
        });
    };
    const initFilters1 = ()=>{
        setFilters1({
            global: {
                value: null,
                matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.CONTAINS
            },
            name: {
                operator: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterOperator.AND,
                constraints: [
                    {
                        value: null,
                        matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.STARTS_WITH
                    }
                ]
            },
            "country.name": {
                operator: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterOperator.AND,
                constraints: [
                    {
                        value: null,
                        matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.STARTS_WITH
                    }
                ]
            },
            representative: {
                value: null,
                matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.IN
            },
            date: {
                operator: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterOperator.AND,
                constraints: [
                    {
                        value: null,
                        matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.DATE_IS
                    }
                ]
            },
            balance: {
                operator: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterOperator.AND,
                constraints: [
                    {
                        value: null,
                        matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.EQUALS
                    }
                ]
            },
            status: {
                operator: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterOperator.OR,
                constraints: [
                    {
                        value: null,
                        matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.EQUALS
                    }
                ]
            },
            activity: {
                value: null,
                matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.BETWEEN
            },
            verified: {
                value: null,
                matchMode: primereact_api__WEBPACK_IMPORTED_MODULE_6__.FilterMatchMode.EQUALS
            }
        });
        setGlobalFilterValue1("");
    };
    const countryBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    alt: "flag",
                    src: `/demo/images/flag/flag_placeholder.png`,
                    className: `flag flag-${rowData.country.code}`,
                    width: 30
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    style: {
                        marginLeft: ".5em",
                        verticalAlign: "middle"
                    },
                    children: rowData.country.name
                })
            ]
        });
    };
    const filterClearTemplate = (options)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_4__.Button, {
            type: "button",
            icon: "pi pi-times",
            onClick: options.filterClearCallback,
            severity: "secondary"
        });
    };
    const filterApplyTemplate = (options)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_4__.Button, {
            type: "button",
            icon: "pi pi-check",
            onClick: options.filterApplyCallback,
            severity: "success"
        });
    };
    const representativeBodyTemplate = (rowData)=>{
        const representative = rowData.representative;
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    alt: representative.name,
                    src: `/demo/images/avatar/${representative.image}`,
                    onError: (e)=>e.target.src = "https://www.primefaces.org/wp-content/uploads/2020/05/placeholder.png",
                    width: 32,
                    style: {
                        verticalAlign: "middle"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    style: {
                        marginLeft: ".5em",
                        verticalAlign: "middle"
                    },
                    children: representative.name
                })
            ]
        });
    };
    const representativeFilterTemplate = (options)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-3 text-bold",
                    children: "Agent Picker"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_multiselect__WEBPACK_IMPORTED_MODULE_7__/* .MultiSelect */ .N, {
                    value: options.value,
                    options: representatives,
                    itemTemplate: representativesItemTemplate,
                    onChange: (e)=>options.filterCallback(e.value),
                    optionLabel: "name",
                    placeholder: "Any",
                    className: "p-column-filter"
                })
            ]
        });
    };
    const representativesItemTemplate = (option)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "p-multiselect-representative-option",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    alt: option.name,
                    src: `/demo/images/avatar/${option.image}`,
                    width: 32,
                    style: {
                        verticalAlign: "middle"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    style: {
                        marginLeft: ".5em",
                        verticalAlign: "middle"
                    },
                    children: option.name
                })
            ]
        });
    };
    const dateBodyTemplate = (rowData)=>{
        return formatDate(rowData.date);
    };
    const dateFilterTemplate = (options)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_calendar__WEBPACK_IMPORTED_MODULE_8__/* .Calendar */ .f, {
            value: options.value,
            onChange: (e)=>options.filterCallback(e.value, options.index),
            dateFormat: "mm/dd/yy",
            placeholder: "mm/dd/yyyy",
            mask: "99/99/9999"
        });
    };
    const balanceBodyTemplate = (rowData)=>{
        return formatCurrency(rowData.balance);
    };
    const balanceFilterTemplate = (options)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputnumber__WEBPACK_IMPORTED_MODULE_9__.InputNumber, {
            value: options.value,
            onChange: (e)=>options.filterCallback(e.value, options.index),
            mode: "currency",
            currency: "USD",
            locale: "en-US"
        });
    };
    const statusBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: `customer-badge status-${rowData.status}`,
            children: rowData.status
        });
    };
    const statusFilterTemplate = (options)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_10__.Dropdown, {
            value: options.value,
            options: statuses,
            onChange: (e)=>options.filterCallback(e.value, options.index),
            itemTemplate: statusItemTemplate,
            placeholder: "Select a Status",
            className: "p-column-filter",
            showClear: true
        });
    };
    const statusItemTemplate = (option)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: `customer-badge status-${option}`,
            children: option
        });
    };
    const activityBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_progressbar__WEBPACK_IMPORTED_MODULE_11__.ProgressBar, {
            value: rowData.activity,
            showValue: false,
            style: {
                height: ".5rem"
            }
        });
    };
    const activityFilterTemplate = (options)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_slider__WEBPACK_IMPORTED_MODULE_12__/* .Slider */ .i, {
                    value: options.value,
                    onChange: (e)=>options.filterCallback(e.value),
                    range: true,
                    className: "m-3"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex align-items-center justify-content-between px-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: options.value ? options.value[0] : 0
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: options.value ? options.value[1] : 100
                        })
                    ]
                })
            ]
        });
    };
    const verifiedBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
            className: (0,primereact_utils__WEBPACK_IMPORTED_MODULE_13__.classNames)("pi", {
                "text-green-500 pi-check-circle": rowData.verified,
                "text-pink-500 pi-times-circle": !rowData.verified
            })
        });
    };
    const verifiedFilterTemplate = (options)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_tristatecheckbox__WEBPACK_IMPORTED_MODULE_14__/* .TriStateCheckbox */ .I, {
            value: options.value,
            onChange: (e)=>options.filterCallback(e.value)
        });
    };
    const toggleAll = ()=>{
        if (allExpanded) collapseAll();
        else expandAll();
    };
    const expandAll = ()=>{
        let _expandedRows = {};
        products.forEach((p)=>_expandedRows[`${p.id}`] = true);
        setExpandedRows(_expandedRows);
        setAllExpanded(true);
    };
    const collapseAll = ()=>{
        setExpandedRows([]);
        setAllExpanded(false);
    };
    const amountBodyTemplate = (rowData)=>{
        return formatCurrency(rowData.amount);
    };
    const statusOrderBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: `order-badge order-${rowData.status?.toLowerCase()}`,
            children: rowData.status
        });
    };
    const searchBodyTemplate = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_4__.Button, {
            icon: "pi pi-search"
        });
    };
    const imageBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            src: `/demo/images/product/${rowData.image}`,
            onError: (e)=>e.target.src = "https://www.primefaces.org/wp-content/uploads/2020/05/placeholder.png",
            alt: rowData.image,
            className: "shadow-2",
            width: 100
        });
    };
    const priceBodyTemplate = (rowData)=>{
        return formatCurrency(rowData.price);
    };
    const ratingBodyTemplate = (rowData)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_rating__WEBPACK_IMPORTED_MODULE_15__/* .Rating */ .i, {
            value: rowData.rating,
            readOnly: true,
            cancel: false
        });
    };
    const statusBodyTemplate2 = (rowData)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: `product-badge status-${rowData.inventoryStatus?.toLowerCase()}`,
            children: rowData.inventoryStatus
        });
    };
    const rowExpansionTemplate = (data)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "orders-subtable",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h5", {
                    children: [
                        "Orders for ",
                        data.name
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_datatable__WEBPACK_IMPORTED_MODULE_16__/* .DataTable */ .w, {
                    value: data.orders,
                    responsiveLayout: "scroll",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                            field: "id",
                            header: "Id",
                            sortable: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                            field: "customer",
                            header: "Customer",
                            sortable: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                            field: "date",
                            header: "Date",
                            sortable: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                            field: "amount",
                            header: "Amount",
                            body: amountBodyTemplate,
                            sortable: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                            field: "status",
                            header: "Status",
                            body: statusOrderBodyTemplate,
                            sortable: true
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                            headerStyle: {
                                width: "4rem"
                            },
                            body: searchBodyTemplate
                        })
                    ]
                })
            ]
        });
    };
    const header = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_4__.Button, {
        icon: allExpanded ? "pi pi-minus" : "pi pi-plus",
        label: allExpanded ? "Collapse All" : "Expand All",
        onClick: toggleAll,
        className: "w-11rem"
    });
    const headerTemplate = (data)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    alt: data.representative.name,
                    src: `/demo/images/avatar/${data.representative.image}`,
                    width: "32",
                    style: {
                        verticalAlign: "middle"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "font-bold ml-2",
                    children: data.representative.name
                })
            ]
        });
    };
    const footerTemplate = (data)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    colSpan: 4,
                    style: {
                        textAlign: "right"
                    },
                    className: "text-bold pr-6",
                    children: "Total Customers"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                    children: calculateCustomerTotal(data.representative.name)
                })
            ]
        });
    };
    const calculateCustomerTotal = (name)=>{
        let total = 0;
        if (customers3) {
            for (let customer of customers3){
                if (customer.representative.name === name) {
                    total++;
                }
            }
        }
        return total;
    };
    const header1 = renderHeader1();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            children: "Filter Menu"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_datatable__WEBPACK_IMPORTED_MODULE_16__/* .DataTable */ .w, {
                            value: customers1,
                            paginator: true,
                            className: "p-datatable-gridlines",
                            showGridlines: true,
                            rows: 10,
                            dataKey: "id",
                            filters: filters1,
                            filterDisplay: "menu",
                            loading: loading1,
                            responsiveLayout: "scroll",
                            emptyMessage: "No customers found.",
                            header: header1,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "name",
                                    header: "Name",
                                    filter: true,
                                    filterPlaceholder: "Search by name",
                                    style: {
                                        minWidth: "12rem"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    header: "Country",
                                    filterField: "country.name",
                                    style: {
                                        minWidth: "12rem"
                                    },
                                    body: countryBodyTemplate,
                                    filter: true,
                                    filterPlaceholder: "Search by country",
                                    filterClear: filterClearTemplate,
                                    filterApply: filterApplyTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    header: "Agent",
                                    filterField: "representative",
                                    showFilterMatchModes: false,
                                    filterMenuStyle: {
                                        width: "14rem"
                                    },
                                    style: {
                                        minWidth: "14rem"
                                    },
                                    body: representativeBodyTemplate,
                                    filter: true,
                                    filterElement: representativeFilterTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    header: "Date",
                                    filterField: "date",
                                    dataType: "date",
                                    style: {
                                        minWidth: "10rem"
                                    },
                                    body: dateBodyTemplate,
                                    filter: true,
                                    filterElement: dateFilterTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    header: "Balance",
                                    filterField: "balance",
                                    dataType: "numeric",
                                    style: {
                                        minWidth: "10rem"
                                    },
                                    body: balanceBodyTemplate,
                                    filter: true,
                                    filterElement: balanceFilterTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "status",
                                    header: "Status",
                                    filterMenuStyle: {
                                        width: "14rem"
                                    },
                                    style: {
                                        minWidth: "12rem"
                                    },
                                    body: statusBodyTemplate,
                                    filter: true,
                                    filterElement: statusFilterTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "activity",
                                    header: "Activity",
                                    showFilterMatchModes: false,
                                    style: {
                                        minWidth: "12rem"
                                    },
                                    body: activityBodyTemplate,
                                    filter: true,
                                    filterElement: activityFilterTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "verified",
                                    header: "Verified",
                                    dataType: "boolean",
                                    bodyClassName: "text-center",
                                    style: {
                                        minWidth: "8rem"
                                    },
                                    body: verifiedBodyTemplate,
                                    filter: true,
                                    filterElement: verifiedFilterTemplate
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            children: "Frozen Columns"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_togglebutton__WEBPACK_IMPORTED_MODULE_18__/* .ToggleButton */ .C, {
                            checked: idFrozen,
                            onChange: (e)=>setIdFrozen(e.value),
                            onIcon: "pi pi-lock",
                            offIcon: "pi pi-lock-open",
                            onLabel: "Unfreeze Id",
                            offLabel: "Freeze Id",
                            style: {
                                width: "10rem"
                            }
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_datatable__WEBPACK_IMPORTED_MODULE_16__/* .DataTable */ .w, {
                            value: customers2,
                            scrollable: true,
                            scrollHeight: "400px",
                            loading: loading2,
                            className: "mt-3",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "name",
                                    header: "Name",
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "160px"
                                    },
                                    frozen: true,
                                    className: "font-bold"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "id",
                                    header: "Id",
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "100px"
                                    },
                                    frozen: idFrozen,
                                    alignFrozen: "left",
                                    bodyClassName: (0,primereact_utils__WEBPACK_IMPORTED_MODULE_13__.classNames)({
                                        "font-bold": idFrozen
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "country.name",
                                    header: "Country",
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "200px"
                                    },
                                    body: countryBodyTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "date",
                                    header: "Date",
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "200px"
                                    },
                                    body: dateBodyTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "company",
                                    header: "Company",
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "200px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "status",
                                    header: "Status",
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "200px"
                                    },
                                    body: statusBodyTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "activity",
                                    header: "Activity",
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "200px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "representative.name",
                                    header: "Representative",
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "200px"
                                    },
                                    body: representativeBodyTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "balance",
                                    header: "Balance",
                                    body: balanceTemplate,
                                    frozen: true,
                                    style: {
                                        flexGrow: 1,
                                        flexBasis: "120px"
                                    },
                                    className: "font-bold",
                                    alignFrozen: "right"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            children: "Row Expand"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_datatable__WEBPACK_IMPORTED_MODULE_16__/* .DataTable */ .w, {
                            value: products,
                            expandedRows: expandedRows,
                            onRowToggle: (e)=>setExpandedRows(e.data),
                            responsiveLayout: "scroll",
                            rowExpansionTemplate: rowExpansionTemplate,
                            dataKey: "id",
                            header: header,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    expander: true,
                                    style: {
                                        width: "3em"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "name",
                                    header: "Name",
                                    sortable: true
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    header: "Image",
                                    body: imageBodyTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "price",
                                    header: "Price",
                                    sortable: true,
                                    body: priceBodyTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "category",
                                    header: "Category",
                                    sortable: true
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "rating",
                                    header: "Reviews",
                                    sortable: true,
                                    body: ratingBodyTemplate
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "inventoryStatus",
                                    header: "Status",
                                    sortable: true,
                                    body: statusBodyTemplate2
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            children: "Subheader Grouping"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_datatable__WEBPACK_IMPORTED_MODULE_16__/* .DataTable */ .w, {
                            value: customers3,
                            rowGroupMode: "subheader",
                            groupRowsBy: "representative.name",
                            sortMode: "single",
                            sortField: "representative.name",
                            sortOrder: 1,
                            scrollable: true,
                            scrollHeight: "400px",
                            rowGroupHeaderTemplate: headerTemplate,
                            rowGroupFooterTemplate: footerTemplate,
                            responsiveLayout: "scroll",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "name",
                                    header: "Name",
                                    style: {
                                        minWidth: "200px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "country",
                                    header: "Country",
                                    body: countryBodyTemplate,
                                    style: {
                                        minWidth: "200px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "company",
                                    header: "Company",
                                    style: {
                                        minWidth: "200px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "status",
                                    header: "Status",
                                    body: statusBodyTemplate,
                                    style: {
                                        minWidth: "200px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_column__WEBPACK_IMPORTED_MODULE_17__/* .Column */ .s, {
                                    field: "date",
                                    header: "Date",
                                    style: {
                                        minWidth: "200px"
                                    }
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TableDemo);


/***/ }),

/***/ 85192:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   v: () => (/* binding */ CustomerService)
/* harmony export */ });
const CustomerService = {
    getCustomersMedium () {
        return fetch("/demo/data/customers-medium.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getCustomersLarge () {
        return fetch("/demo/data/customers-large.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    }
};


/***/ }),

/***/ 95377:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ ProductService)
/* harmony export */ });
const ProductService = {
    getProductsSmall () {
        return fetch("/demo/data/products-small.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getProducts () {
        return fetch("/demo/data/products.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getProductsMixed () {
        return fetch("/demo/data/products-mixed.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getProductsWithOrdersSmall () {
        return fetch("/demo/data/products-orders-small.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getProductsWithOrdersLarge () {
        return fetch("/demo/data/products-orders.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    }
};


/***/ }),

/***/ 92547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90284);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18176);
/* harmony import */ var primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63579);
/* harmony import */ var primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23064);
/* harmony import */ var primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63862);
/* harmony import */ var primereact_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7666);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6538);
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AppConfig = (props)=>{
    const { layoutConfig, setLayoutConfig, layoutState, setLayoutState, isSlim, isSlimPlus, isHorizontal } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__/* .LayoutContext */ .V);
    const { changeTheme } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(primereact_api__WEBPACK_IMPORTED_MODULE_3__.PrimeReactContext);
    const scales = [
        12,
        13,
        14,
        15,
        16
    ];
    const componentThemes = [
        {
            name: "indigo",
            color: "#6366F1"
        },
        {
            name: "blue",
            color: "#3B82F6"
        },
        {
            name: "purple",
            color: "#8B5CF6"
        },
        {
            name: "teal",
            color: "#14B8A6"
        },
        {
            name: "cyan",
            color: "#06b6d4"
        },
        {
            name: "green",
            color: "#10b981"
        },
        {
            name: "orange",
            color: "#f59e0b"
        },
        {
            name: "pink",
            color: "#d946ef"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isSlim() || isSlimPlus() || isHorizontal()) {
            setLayoutState((prevState)=>({
                    ...prevState,
                    resetMenu: true
                }));
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.menuMode
    ]);
    const onConfigButtonClick = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: true
            }));
    };
    const onConfigSidebarHide = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: false
            }));
    };
    const changeInputStyle = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                inputStyle: e.value
            }));
    };
    const changeRipple = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                ripple: e.value
            }));
    };
    const changeMenuMode = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuMode: e.value
            }));
    };
    const changeMenuTheme = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuTheme: e.value
            }));
    };
    const changeColorScheme = (colorScheme)=>{
        changeTheme?.(layoutConfig.colorScheme, colorScheme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    colorScheme
                }));
        });
    };
    const _changeTheme = (theme)=>{
        changeTheme?.(layoutConfig.theme, theme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    theme
                }));
        });
    };
    const decrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale - 1
            }));
    };
    const incrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale + 1
            }));
    };
    const applyScale = ()=>{
        document.documentElement.style.fontSize = layoutConfig.scale + "px";
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        applyScale();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.scale
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "layout-config-button config-link",
                type: "button",
                onClick: onConfigButtonClick,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "pi pi-cog"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__/* .Sidebar */ .Y, {
                visible: layoutState.configSidebarVisible,
                onHide: onConfigSidebarHide,
                position: "right",
                className: "layout-config-sidebar w-18rem",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Themes"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap row-gap-3",
                        children: componentThemes.map((theme, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    className: "cursor-pointer p-link w-2rem h-2rem border-circle flex-shrink-0 flex align-items-center justify-content-center",
                                    onClick: ()=>_changeTheme(theme.name),
                                    style: {
                                        backgroundColor: theme.color
                                    },
                                    children: theme.name == layoutConfig.theme && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "pi pi-check text-white"
                                    })
                                })
                            }, i);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Scale"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex align-items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-minus",
                                type: "button",
                                onClick: decrementScale,
                                className: "w-2rem h-2rem mr-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[0]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex gap-2 align-items-center",
                                children: scales.map((s, i)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: (0,primereact_utils__WEBPACK_IMPORTED_MODULE_6__.classNames)("pi pi-circle-fill text-300", {
                                            "text-primary-500": s === layoutConfig.scale
                                        })
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-plus",
                                type: "button",
                                onClick: incrementScale,
                                className: "w-2rem h-2rem ml-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[scales.length - 1]
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Type"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap row-gap-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "static",
                                                checked: layoutConfig.menuMode === "static",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode1",
                                                children: "Static"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "overlay",
                                                checked: layoutConfig.menuMode === "overlay",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode2",
                                                children: "Overlay"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim",
                                                checked: layoutConfig.menuMode === "slim",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode3"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode3",
                                                children: "Slim"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim-plus",
                                                checked: layoutConfig.menuMode === "slim-plus",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode4"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode4",
                                                children: "Slim +"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "drawer",
                                                checked: layoutConfig.menuMode === "drawer",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode7"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode7",
                                                children: "Drawer"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "reveal",
                                                checked: layoutConfig.menuMode === "reveal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode6",
                                                children: "Reveal"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "horizontal",
                                                checked: layoutConfig.menuMode === "horizontal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode5",
                                                children: "Horizontal"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Theme"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "colorScheme",
                                        checked: layoutConfig.menuTheme === "colorScheme",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-colorscheme"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-colorscheme",
                                        children: "Color Scheme"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "primaryColor",
                                        checked: layoutConfig.menuTheme === "primaryColor",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-primarycolor"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-primarycolor",
                                        children: "Primary Color"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "transparent",
                                        checked: layoutConfig.menuTheme === "transparent",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-transparent"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-transparent",
                                        children: "Transparent"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Color Scheme"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "light",
                                checked: layoutConfig.colorScheme === "light",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-light"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-light",
                                children: "Light"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dim",
                                checked: layoutConfig.colorScheme === "dim",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dim"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dim",
                                children: "Dim"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dark",
                                checked: layoutConfig.colorScheme === "dark",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dark"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dark",
                                children: "Dark"
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Input Style"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "outlined",
                                                checked: layoutConfig.inputStyle === "outlined",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "outlined_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "outlined_input",
                                                children: "Outlined"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "filled",
                                                checked: layoutConfig.inputStyle === "filled",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "filled_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "filled_input",
                                                children: "Filled"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Ripple Effect"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__/* .InputSwitch */ .Q, {
                                checked: layoutConfig.ripple,
                                onChange: changeRipple
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppConfig);


/***/ }),

/***/ 51396:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\uikit\table\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,7933,1042,6903,4719,4524,5129,1501,1003,1993,4760,590,2085,6946,2186,9141,1326,8350,895,6065,4972], () => (__webpack_exec__(97880)));
module.exports = __webpack_exports__;

})();