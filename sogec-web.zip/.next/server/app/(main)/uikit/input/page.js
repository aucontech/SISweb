(() => {
var exports = {};
exports.id = 2606;
exports.ids = [2606];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 48203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'uikit',
        {
        children: [
        'input',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78192)), "D:\\sogec\\sogec-web\\app\\(main)\\uikit\\input\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\uikit\\input\\page.tsx"];
    
    const originalPathname = "/(main)/uikit/input/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 53187:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 52299))

/***/ }),

/***/ 52299:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_autocomplete__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(37);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(18176);
/* harmony import */ var primereact_calendar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(52186);
/* harmony import */ var primereact_checkbox__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(27636);
/* harmony import */ var primereact_chips__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(98646);
/* harmony import */ var primereact_colorpicker__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(39509);
/* harmony import */ var primereact_dropdown__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1042);
/* harmony import */ var primereact_inputnumber__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(14719);
/* harmony import */ var primereact_inputswitch__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(63579);
/* harmony import */ var primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71785);
/* harmony import */ var primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(43285);
/* harmony import */ var primereact_knob__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(60170);
/* harmony import */ var primereact_listbox__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1818);
/* harmony import */ var primereact_multiselect__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(61326);
/* harmony import */ var primereact_radiobutton__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(23064);
/* harmony import */ var primereact_rating__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(59141);
/* harmony import */ var primereact_selectbutton__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(71139);
/* harmony import */ var primereact_slider__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(34713);
/* harmony import */ var primereact_togglebutton__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(556);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _demo_service_CountryService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(34723);
/* __next_internal_client_entry_do_not_use__ default auto */ 





















const InputDemo = ()=>{
    const [floatValue, setFloatValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [autoValue, setAutoValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectedAutoValue, setSelectedAutoValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [autoFilteredValue, setAutoFilteredValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [calendarValue, setCalendarValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [inputNumberValue, setInputNumberValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [chipsValue, setChipsValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [sliderValue, setSliderValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [ratingValue, setRatingValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [colorValue, setColorValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("1976D2");
    const [knobValue, setKnobValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(20);
    const [radioValue, setRadioValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [checkboxValue, setCheckboxValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [switchValue, setSwitchValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [listboxValue, setListboxValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [dropdownValue, setDropdownValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [multiselectValue, setMultiselectValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [toggleValue, setToggleValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectButtonValue1, setSelectButtonValue1] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [selectButtonValue2, setSelectButtonValue2] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [inputGroupValue, setInputGroupValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const listboxValues = [
        {
            name: "New York",
            code: "NY"
        },
        {
            name: "Rome",
            code: "RM"
        },
        {
            name: "London",
            code: "LDN"
        },
        {
            name: "Istanbul",
            code: "IST"
        },
        {
            name: "Paris",
            code: "PRS"
        }
    ];
    const dropdownValues = [
        {
            name: "New York",
            code: "NY"
        },
        {
            name: "Rome",
            code: "RM"
        },
        {
            name: "London",
            code: "LDN"
        },
        {
            name: "Istanbul",
            code: "IST"
        },
        {
            name: "Paris",
            code: "PRS"
        }
    ];
    const multiselectValues = [
        {
            name: "Australia",
            code: "AU"
        },
        {
            name: "Brazil",
            code: "BR"
        },
        {
            name: "China",
            code: "CN"
        },
        {
            name: "Egypt",
            code: "EG"
        },
        {
            name: "France",
            code: "FR"
        },
        {
            name: "Germany",
            code: "DE"
        },
        {
            name: "India",
            code: "IN"
        },
        {
            name: "Japan",
            code: "JP"
        },
        {
            name: "Spain",
            code: "ES"
        },
        {
            name: "United States",
            code: "US"
        }
    ];
    const selectButtonValues1 = [
        {
            name: "Option 1",
            code: "O1"
        },
        {
            name: "Option 2",
            code: "O2"
        },
        {
            name: "Option 3",
            code: "O3"
        }
    ];
    const selectButtonValues2 = [
        {
            name: "Option 1",
            code: "O1"
        },
        {
            name: "Option 2",
            code: "O2"
        },
        {
            name: "Option 3",
            code: "O3"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        _demo_service_CountryService__WEBPACK_IMPORTED_MODULE_2__/* .CountryService */ .T.getCountries().then((data)=>setAutoValue(data));
    }, []);
    const searchCountry = (event)=>{
        setTimeout(()=>{
            if (!event.query.trim().length) {
                setAutoFilteredValue([
                    ...autoValue
                ]);
            } else {
                setAutoFilteredValue(autoValue.filter((country)=>{
                    return country.name.toLowerCase().startsWith(event.query.toLowerCase());
                }));
            }
        }, 250);
    };
    const onCheckboxChange = (e)=>{
        let selectedValue = [
            ...checkboxValue
        ];
        if (e.checked) selectedValue.push(e.value);
        else selectedValue.splice(selectedValue.indexOf(e.value), 1);
        setCheckboxValue(selectedValue);
    };
    const itemTemplate = (option)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex align-items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    alt: option.name,
                    src: `/demo/images/flag/flag_placeholder.png`,
                    onError: (e)=>e.currentTarget.src = "https://www.primefaces.org/wp-content/uploads/2020/05/placeholder.png",
                    className: `flag flag-${option.code.toLowerCase()}`,
                    style: {
                        width: "21px"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "ml-2",
                    children: option.name
                })
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid p-fluid input-demo",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "col-12 md:col-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "InputText"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "grid formgrid",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 mb-2 lg:col-4 lg:mb-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                            type: "text",
                                            placeholder: "Default"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 mb-2 lg:col-4 lg:mb-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                            type: "text",
                                            placeholder: "Disabled",
                                            disabled: true
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 mb-2 lg:col-4 lg:mb-0",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                            type: "text",
                                            placeholder: "Invalid",
                                            className: "p-invalid"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Icons"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "grid formgrid",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 mb-2 lg:col-4 lg:mb-0",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "p-input-icon-left",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "pi pi-user"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                                    type: "text",
                                                    placeholder: "Username"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 mb-2 lg:col-4 lg:mb-0",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "p-input-icon-right",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                                    type: "text",
                                                    placeholder: "Search"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "pi pi-search"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 mb-2 lg:col-4 lg:mb-0",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "p-input-icon-left p-input-icon-right",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "pi pi-user"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                                    type: "text",
                                                    placeholder: "Search"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "pi pi-search"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Float Label"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "p-float-label",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                        id: "username",
                                        type: "text",
                                        value: floatValue,
                                        onChange: (e)=>setFloatValue(e.target.value)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "username",
                                        children: "Username"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Textarea"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtextarea__WEBPACK_IMPORTED_MODULE_4__/* .InputTextarea */ .g, {
                                placeholder: "Your Message",
                                rows: 5,
                                cols: 30
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "AutoComplete"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_autocomplete__WEBPACK_IMPORTED_MODULE_5__/* .AutoComplete */ .Q, {
                                placeholder: "Search",
                                id: "dd",
                                dropdown: true,
                                multiple: true,
                                value: selectedAutoValue,
                                onChange: (e)=>setSelectedAutoValue(e.value),
                                suggestions: autoFilteredValue,
                                completeMethod: searchCountry,
                                field: "name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Calendar"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_calendar__WEBPACK_IMPORTED_MODULE_6__/* .Calendar */ .f, {
                                showIcon: true,
                                showButtonBar: true,
                                value: calendarValue,
                                onChange: (e)=>setCalendarValue(e.value ?? null)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "InputNumber"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputnumber__WEBPACK_IMPORTED_MODULE_7__.InputNumber, {
                                value: inputNumberValue,
                                onValueChange: (e)=>setInputNumberValue(e.value ?? null),
                                showButtons: true,
                                mode: "decimal"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Chips"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_chips__WEBPACK_IMPORTED_MODULE_8__/* .Chips */ .c, {
                                value: chipsValue,
                                onChange: (e)=>setChipsValue(e.value ?? [])
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "card",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "grid",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-12",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                            children: "Slider"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                            value: sliderValue,
                                            onChange: (e)=>setSliderValue(parseInt(e.target.value, 10))
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_slider__WEBPACK_IMPORTED_MODULE_9__/* .Slider */ .i, {
                                            value: sliderValue,
                                            onChange: (e)=>setSliderValue(e.value)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-12 md:col-6",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                            children: "Rating"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_rating__WEBPACK_IMPORTED_MODULE_10__/* .Rating */ .i, {
                                            value: ratingValue,
                                            onChange: (e)=>setRatingValue(e.value ?? 0)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-12 md:col-6",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                            children: "ColorPicker"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_colorpicker__WEBPACK_IMPORTED_MODULE_11__/* .ColorPicker */ .z, {
                                            value: colorValue,
                                            onChange: (e)=>setColorValue(e.value ?? ""),
                                            style: {
                                                width: "2rem"
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-12",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                            children: "Knob"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_knob__WEBPACK_IMPORTED_MODULE_12__/* .Knob */ .l, {
                                            value: knobValue,
                                            valueTemplate: "{value}%",
                                            onChange: (e)=>setKnobValue(e.value),
                                            step: 10,
                                            min: -50,
                                            max: 50
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "col-12 md:col-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "RadioButton"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "grid",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 md:col-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "field-radiobutton",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_13__/* .RadioButton */ .E, {
                                                    inputId: "option1",
                                                    name: "option",
                                                    value: "Chicago",
                                                    checked: radioValue === "Chicago",
                                                    onChange: (e)=>setRadioValue(e.value)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "option1",
                                                    children: "Chicago"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 md:col-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "field-radiobutton",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_13__/* .RadioButton */ .E, {
                                                    inputId: "option2",
                                                    name: "option",
                                                    value: "Los Angeles",
                                                    checked: radioValue === "Los Angeles",
                                                    onChange: (e)=>setRadioValue(e.value)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "option2",
                                                    children: "Los Angeles"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 md:col-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "field-radiobutton",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_13__/* .RadioButton */ .E, {
                                                    inputId: "option3",
                                                    name: "option",
                                                    value: "New York",
                                                    checked: radioValue === "New York",
                                                    onChange: (e)=>setRadioValue(e.value)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "option3",
                                                    children: "New York"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Checkbox"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "grid",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 md:col-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "field-checkbox",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_checkbox__WEBPACK_IMPORTED_MODULE_14__/* .Checkbox */ .X, {
                                                    inputId: "checkOption1",
                                                    name: "option",
                                                    value: "Chicago",
                                                    checked: checkboxValue.indexOf("Chicago") !== -1,
                                                    onChange: onCheckboxChange
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "checkOption1",
                                                    children: "Chicago"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 md:col-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "field-checkbox",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_checkbox__WEBPACK_IMPORTED_MODULE_14__/* .Checkbox */ .X, {
                                                    inputId: "checkOption2",
                                                    name: "option",
                                                    value: "Los Angeles",
                                                    checked: checkboxValue.indexOf("Los Angeles") !== -1,
                                                    onChange: onCheckboxChange
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "checkOption2",
                                                    children: "Los Angeles"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 md:col-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "field-checkbox",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_checkbox__WEBPACK_IMPORTED_MODULE_14__/* .Checkbox */ .X, {
                                                    inputId: "checkOption3",
                                                    name: "option",
                                                    value: "New York",
                                                    checked: checkboxValue.indexOf("New York") !== -1,
                                                    onChange: onCheckboxChange
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "checkOption3",
                                                    children: "New York"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Input Switch"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputswitch__WEBPACK_IMPORTED_MODULE_15__/* .InputSwitch */ .Q, {
                                checked: switchValue,
                                onChange: (e)=>setSwitchValue(e.value ?? false)
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Listbox"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_listbox__WEBPACK_IMPORTED_MODULE_16__/* .ListBox */ .w, {
                                value: listboxValue,
                                onChange: (e)=>setListboxValue(e.value),
                                options: listboxValues,
                                optionLabel: "name",
                                filter: true
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Dropdown"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_dropdown__WEBPACK_IMPORTED_MODULE_17__.Dropdown, {
                                value: dropdownValue,
                                onChange: (e)=>setDropdownValue(e.value),
                                options: dropdownValues,
                                optionLabel: "name",
                                placeholder: "Select"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "MultiSelect"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_multiselect__WEBPACK_IMPORTED_MODULE_18__/* .MultiSelect */ .N, {
                                value: multiselectValue,
                                onChange: (e)=>setMultiselectValue(e.value),
                                options: multiselectValues,
                                itemTemplate: itemTemplate,
                                optionLabel: "name",
                                placeholder: "Select Countries",
                                filter: true,
                                className: "multiselect-custom",
                                display: "chip"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "ToggleButton"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_togglebutton__WEBPACK_IMPORTED_MODULE_19__/* .ToggleButton */ .C, {
                                checked: toggleValue,
                                onChange: (e)=>setToggleValue(e.value),
                                onLabel: "Yes",
                                offLabel: "No"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "SelectButton"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_selectbutton__WEBPACK_IMPORTED_MODULE_20__/* .SelectButton */ .U, {
                                value: selectButtonValue1,
                                onChange: (e)=>setSelectButtonValue1(e.value),
                                options: selectButtonValues1,
                                optionLabel: "name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "SelectButton - Multiple"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_selectbutton__WEBPACK_IMPORTED_MODULE_20__/* .SelectButton */ .U, {
                                value: selectButtonValue2,
                                onChange: (e)=>setSelectButtonValue2(e.value),
                                options: selectButtonValues2,
                                optionLabel: "name",
                                multiple: true
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            children: "Input Groups"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "grid p-fluid",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 md:col-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "p-inputgroup",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "p-inputgroup-addon",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "pi pi-user"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                                placeholder: "Username"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 md:col-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "p-inputgroup",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "p-inputgroup-addon",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "pi pi-shopping-cart"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "p-inputgroup-addon",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    className: "pi pi-globe"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                                placeholder: "Price"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "p-inputgroup-addon",
                                                children: "$"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "p-inputgroup-addon",
                                                children: ".00"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 md:col-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "p-inputgroup",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_21__.Button, {
                                                label: "Search"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                                placeholder: "Keyword"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-12 md:col-6",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "p-inputgroup",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "p-inputgroup-addon p-inputgroup-addon-checkbox",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_checkbox__WEBPACK_IMPORTED_MODULE_14__/* .Checkbox */ .X, {
                                                    checked: inputGroupValue,
                                                    onChange: (e)=>setInputGroupValue(e.checked ?? false)
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputtext__WEBPACK_IMPORTED_MODULE_3__.InputText, {
                                                placeholder: "Confirm"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputDemo);


/***/ }),

/***/ 34723:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: () => (/* binding */ CountryService)
/* harmony export */ });
const CountryService = {
    getCountries () {
        return fetch("/demo/data/countries.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    }
};


/***/ }),

/***/ 78192:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\uikit\input\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,7933,1042,6903,4719,590,3285,6946,2186,7636,37,9141,1326,8646,8350,2518,6065,2547,4972], () => (__webpack_exec__(48203)));
module.exports = __webpack_exports__;

})();