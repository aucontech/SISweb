(() => {
var exports = {};
exports.id = 5187;
exports.ids = [5187];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 68387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'uikit',
        {
        children: [
        'media',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49230)), "D:\\sogec\\sogec-web\\app\\(main)\\uikit\\media\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\uikit\\media\\page.tsx"];
    
    const originalPathname = "/(main)/uikit/media/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 39453:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 34635))

/***/ }),

/***/ 34635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/carousel/carousel.cjs.js
var carousel_cjs = __webpack_require__(31480);
// EXTERNAL MODULE: ./node_modules/primereact/galleria/galleria.cjs.js
var galleria_cjs = __webpack_require__(37633);
// EXTERNAL MODULE: ./node_modules/primereact/image/image.cjs.js
var image_cjs = __webpack_require__(93216);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./demo/service/PhotoService.ts
const PhotoService = {
    getImages () {
        return fetch("/demo/data/photos.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    }
};

// EXTERNAL MODULE: ./demo/service/ProductService.ts
var ProductService = __webpack_require__(95377);
;// CONCATENATED MODULE: ./app/(main)/uikit/media/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 







const MediaDemo = ()=>{
    const [products, setProducts] = (0,react_.useState)([]);
    const [images, setImages] = (0,react_.useState)([]);
    const galleriaResponsiveOptions = [
        {
            breakpoint: "1024px",
            numVisible: 5
        },
        {
            breakpoint: "960px",
            numVisible: 4
        },
        {
            breakpoint: "768px",
            numVisible: 3
        },
        {
            breakpoint: "560px",
            numVisible: 1
        }
    ];
    const carouselResponsiveOptions = [
        {
            breakpoint: "1024px",
            numVisible: 3,
            numScroll: 3
        },
        {
            breakpoint: "768px",
            numVisible: 2,
            numScroll: 2
        },
        {
            breakpoint: "560px",
            numVisible: 1,
            numScroll: 1
        }
    ];
    (0,react_.useEffect)(()=>{
        ProductService/* ProductService */.M.getProductsSmall().then((products)=>setProducts(products));
        PhotoService.getImages().then((images)=>setImages(images));
    }, []);
    const carouselItemTemplate = (product)=>{
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "border-1 surface-border border-round m-1 text-center py-5",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "mb-3",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: `/demo/images/product/${product.image}`,
                        alt: product.name,
                        className: "w-6 shadow-2"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                            className: "p-mb-1",
                            children: product.name
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h6", {
                            className: "mt-0 mb-3",
                            children: [
                                "$",
                                product.price
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: `product-badge status-${product.inventoryStatus?.toLowerCase()}`,
                            children: product.inventoryStatus
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "car-buttons mt-5",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                    type: "button",
                                    rounded: true,
                                    className: " mr-2",
                                    icon: "pi pi-search"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                    type: "button",
                                    rounded: true,
                                    severity: "success",
                                    className: "mr-2",
                                    icon: "pi pi-star"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                    type: "button",
                                    rounded: true,
                                    severity: "help",
                                    icon: "pi pi-cog"
                                })
                            ]
                        })
                    ]
                })
            ]
        });
    };
    const galleriaItemTemplate = (item)=>/*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: `/${item.itemImageSrc}`,
            alt: item.alt,
            style: {
                width: "100%",
                display: "block"
            }
        });
    const galleriaThumbnailTemplate = (item)=>/*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: `/${item.thumbnailImageSrc}`,
            alt: item.alt,
            style: {
                width: "100%",
                display: "block"
            }
        });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "grid p-fluid",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            children: "Carousel"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(carousel_cjs/* Carousel */.l, {
                            value: products,
                            numVisible: 3,
                            numScroll: 3,
                            responsiveOptions: carouselResponsiveOptions,
                            itemTemplate: carouselItemTemplate
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            children: "Image"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex justify-content-center",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(image_cjs/* Image */.E, {
                                src: `/demo/images/galleria/galleria10.jpg`,
                                alt: "Image",
                                width: "250",
                                preview: true
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "col-12",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                            children: "Galleria"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(galleria_cjs/* Galleria */.d, {
                            value: images,
                            responsiveOptions: galleriaResponsiveOptions,
                            numVisible: 7,
                            circular: true,
                            style: {
                                maxWidth: "800px",
                                margin: "auto"
                            },
                            item: galleriaItemTemplate,
                            thumbnail: galleriaThumbnailTemplate
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const page = (MediaDemo);


/***/ }),

/***/ 49230:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\uikit\media\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1399,5665,590,6946,9860,792,6065,2547,4972,5377], () => (__webpack_exec__(68387)));
module.exports = __webpack_exports__;

})();