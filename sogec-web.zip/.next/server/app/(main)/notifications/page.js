(() => {
var exports = {};
exports.id = 3128;
exports.ids = [3128,1130];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 51660:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'notifications',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7490)), "D:\\sogec\\sogec-web\\app\\(main)\\notifications\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\notifications\\page.tsx"];
    
    const originalPathname = "/(main)/notifications/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 1462:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 79094))

/***/ }),

/***/ 79094:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/primereact/tabview/tabview.cjs.js
var tabview_cjs = __webpack_require__(11184);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./api/http.api.ts
var http_api = __webpack_require__(49213);
;// CONCATENATED MODULE: ./api/notification.api.ts

const getNotifications = (reqParams)=>{
    return http_api/* httpApi */.Y.get("/notifications", {
        params: {
            ...reqParams
        }
    });
};
const deleteNotifications = (id)=>{
    return http_api/* httpApi */.Y.delete(`/notification/${id}`);
};

// EXTERNAL MODULE: ./node_modules/primereact/datatable/datatable.cjs.js
var datatable_cjs = __webpack_require__(14760);
// EXTERNAL MODULE: ./node_modules/primereact/column/column.cjs.js
var column_cjs = __webpack_require__(59210);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/toast/toast.cjs.js
var toast_cjs = __webpack_require__(11459);
// EXTERNAL MODULE: ./node_modules/primereact/confirmdialog/confirmdialog.cjs.js
var confirmdialog_cjs = __webpack_require__(82558);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
// EXTERNAL MODULE: ./service/Utils.ts
var Utils = __webpack_require__(31130);
;// CONCATENATED MODULE: ./app/(main)/notifications/components/NotificationList.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 









const NotificationList = ({ unreadOnly })=>{
    const [notifications, setNotifications] = (0,react_.useState)();
    const toast = (0,react_.useRef)(null);
    const [totalElements, setTotalElements] = (0,react_.useState)(0);
    const [textSearch, setTextSearch] = (0,react_.useState)("");
    const [typingTimer, setTypingTimer] = (0,react_.useState)(null);
    const [lazyState, setlazyState] = (0,react_.useState)({
        first: 0,
        rows: 10,
        page: 0,
        sortField: null,
        sortOrder: null,
        filters: {}
    });
    const _fetchDataNotification = (0,react_.useCallback)(({ pageSize, page, unreadOnly, sortOrder, textSearch })=>{
        getNotifications({
            pageSize,
            page,
            sortProperty: "createdTime",
            sortOrder: "DESC",
            unreadOnly,
            textSearch
        }).then((resp)=>resp.data).then((res)=>{
            console.log(res);
            setNotifications([
                ...res.data
            ]);
            setTotalElements(res.totalElements);
        }).catch((err)=>{
            Utils/* UIUtils */.e.showError({
                error: err?.message,
                toast: toast.current
            });
        });
    }, []);
    const deleteAlarm = (id)=>{
        deleteNotifications(id).then((resp)=>resp.data).then((res)=>{
            const updateTable = notifications.filter((item)=>item.id !== id);
            setNotifications(updateTable);
            _fetchDataNotification({
                pageSize: lazyState.rows,
                page: lazyState.page,
                unreadOnly,
                textSearch
            });
            toast.current?.show({
                severity: "warn",
                summary: "Rejected",
                detail: "Deleted successfully",
                life: 3000
            });
        }).catch((err)=>{
            toast.current?.show({
                severity: "warn",
                summary: "Rejected",
                detail: "Error deleting alarm",
                life: 3000
            });
        });
    };
    const confirm2 = (id)=>{
        (0,confirmdialog_cjs/* confirmDialog */.VG)({
            message: "Do you want to delete this record?",
            header: "Delete Confirmation",
            icon: "pi pi-info-circle",
            acceptClassName: "p-button-danger",
            accept: ()=>deleteAlarm(id.id)
        });
    };
    const _renderCreatedTime = (row)=>{
        let createdTime = row.createdTime;
        return createdTime ? Utils/* Utils */.c.formatUnixTimeToString(createdTime) : "";
    };
    (0,react_.useEffect)(()=>{
        if (typingTimer) {
            clearTimeout(typingTimer);
        }
        const timer = setTimeout(()=>{
            _fetchDataNotification({
                pageSize: lazyState.rows,
                page: lazyState.page,
                unreadOnly,
                textSearch
            });
        }, 300);
        setTypingTimer(timer);
        return ()=>{
            if (typingTimer) {
                clearTimeout(typingTimer);
            }
        };
    }, [
        lazyState,
        textSearch
    ]);
    const _onInvsPaging = (event)=>{
        setlazyState(event);
    };
    const deleteButtonTemplate = (rowData)=>{
        return /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
            onClick: ()=>confirm2(rowData.id),
            icon: "pi pi-trash",
            className: "p-button-rounded p-button-danger"
        });
    };
    const handleSearchInputChange = (e)=>{
        setTextSearch(e.target.value);
    };
    const renderSearch = ()=>{
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "flex flex-wrap gap-2 align-items-center justify-content-between",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                className: "p-input-icon-left w-full sm:w-20rem flex-order-1 sm:flex-order-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "pi pi-search"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                        placeholder: "Global Search",
                        value: textSearch,
                        onChange: handleSearchInputChange,
                        className: "w-full"
                    })
                ]
            })
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "card",
        style: {
            width: "100%"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(toast_cjs/* Toast */.F, {
                ref: toast
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(confirmdialog_cjs/* ConfirmDialog */.QH, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(datatable_cjs/* DataTable */.w, {
                    rows: lazyState.rows,
                    rowsPerPageOptions: [
                        5,
                        10,
                        25,
                        50
                    ],
                    header: renderSearch,
                    value: notifications,
                    paginator: true,
                    lazy: true,
                    className: "datatable-responsive",
                    emptyMessage: "No products found.",
                    paginatorTemplate: "CurrentPageReport RowsPerPageDropdown FirstPageLink PrevPageLink PageLinks  NextPageLink LastPageLink",
                    currentPageReportTemplate: "Showing {first} to {last} of {totalRecords}",
                    totalRecords: totalElements,
                    first: lazyState.first,
                    dataKey: "id",
                    onPage: _onInvsPaging,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                            sortable: true,
                            header: "Created Time",
                            body: _renderCreatedTime
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                            field: "type",
                            header: "Type"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                            field: "subject",
                            header: " Subject",
                            //body={amountBodyTemplate}
                            headerClassName: "white-space-nowrap w-4"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                            field: "text",
                            header: "Message"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(column_cjs/* Column */.s, {
                            header: "Edit",
                            body: deleteButtonTemplate
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_NotificationList = (NotificationList);

;// CONCATENATED MODULE: ./app/(main)/notifications/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


const Banking = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            style: {
                width: "100%"
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(tabview_cjs/* TabView */.xf, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(tabview_cjs/* TabPanel */.x4, {
                        header: "Read",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_NotificationList, {
                            unreadOnly: false
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(tabview_cjs/* TabPanel */.x4, {
                        header: "UnRead",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_NotificationList, {
                            unreadOnly: true
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const page = (Banking);


/***/ }),

/***/ 31130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (/* binding */ Utils),
/* harmony export */   e: () => (/* binding */ UIUtils)
/* harmony export */ });
/* harmony import */ var date_fns_format__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4230);

const showError = ({ error, summary, detail, toast, severity, sticky })=>{
    summary = summary || "Error";
    severity = severity || "error";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    if (error) {
        toast.show({
            severity,
            summary,
            detail: error,
            sticky,
            life
        });
        return;
    }
    return;
};
const showInfo = ({ summary, detail, toast, sticky })=>{
    let severity = "info";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    summary = summary || "Information";
    if (toast) {
        toast.show({
            severity,
            summary,
            detail,
            life,
            sticky
        });
    }
};
const showWarning = ({ summary, detail, toast, sticky })=>{
    let severity = "warn";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    summary = summary || "Warning";
    if (toast) {
        toast.show({
            severity,
            summary,
            detail,
            life,
            sticky
        });
    }
};
const getUnixTimeMilliseconds = ()=>new Date().getTime();
const getUnixTimeMillisecondsGMT7 = ()=>{
    const currentTime = new Date().getTime();
    const offset = 7 * 3600000; // 7 hours * 3600 seconds/hour * 1000 milliseconds/second
    const timeInGMT7 = currentTime + offset;
    return timeInGMT7;
};
const formatUnixTimeToString = (unixTime, fmt)=>{
    const date = new Date(unixTime);
    if (fmt) {
        return (0,date_fns_format__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)(date, fmt);
    }
    fmt = "dd-MM-yyyy HH:mm:ss";
    return (0,date_fns_format__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)(date, fmt);
};
const formatDurationWithWords = (duration)=>{
    let seconds = Math.floor(duration / 1000 % 60);
    let minutes = Math.floor(duration / (1000 * 60) % 60);
    let hours = Math.floor(duration / (1000 * 60 * 60));
    const hoursText = hours > 0 ? `${hours} hours` : "";
    const minutesText = minutes > 0 ? `${minutes} minutes` : "";
    const secondsText = seconds > 0 ? `${seconds} seconds` : "";
    return [
        hoursText,
        minutesText,
        secondsText
    ].filter(Boolean).join(", ");
};
const calculateDurationFromUnixWithWords = (startTime, endTime)=>{
    const start = new Date(startTime);
    const end = new Date(endTime);
    const duration = end - start; // Khoảng thời gian tính bằng miligiây
    return formatDurationWithWords(duration);
};
const UIUtils = {
    showError,
    showInfo,
    showWarning
};
const Utils = {
    formatUnixTimeToString,
    getUnixTimeMilliseconds,
    getUnixTimeMillisecondsGMT7,
    calculateDurationFromUnixWithWords
};



/***/ }),

/***/ 7490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\notifications\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,1399,5767,5665,7978,7933,1042,6903,4719,4524,5129,1501,6408,1003,1993,1459,4760,6120,590,4230,1184,2558,6065,2547,4972], () => (__webpack_exec__(51660)));
module.exports = __webpack_exports__;

})();