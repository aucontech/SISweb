(() => {
var exports = {};
exports.id = 4568;
exports.ids = [4568];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 98704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 41844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 96624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 57085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 20199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 66864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 39569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 52210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 35359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 17160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 30893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 12336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 17887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 98735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 60120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 68231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 53750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 70982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 79618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 78423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 98658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 39491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 82361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 57147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 13685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 95687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 22037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 71017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 57310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 73837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 59796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 75218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52673);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(89419);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_1__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(main)',
        {
        children: [
        'blocks',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 80911)), "D:\\sogec\\sogec-web\\app\\(main)\\blocks\\page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23308)), "D:\\sogec\\sogec-web\\app\\(main)\\layout.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60729)), "D:\\sogec\\sogec-web\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 49986)), "D:\\sogec\\sogec-web\\app\\not-found.tsx"],
          metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 83174))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
        }
      ]
      }.children;
    const pages = ["D:\\sogec\\sogec-web\\app\\(main)\\blocks\\page.tsx"];
    
    const originalPathname = "/(main)/blocks/page"
    const __next_app__ = {
      require: __webpack_require__,
      // all modules are in the entry chunk, so we never actually need to load chunks in webpack
      loadChunk: () => Promise.resolve()
    }

    
  

/***/ }),

/***/ 92272:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 24727))

/***/ }),

/***/ 24727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/checkbox/checkbox.cjs.js
var checkbox_cjs = __webpack_require__(27636);
// EXTERNAL MODULE: ./node_modules/primereact/chip/chip.cjs.js
var chip_cjs = __webpack_require__(79842);
// EXTERNAL MODULE: ./node_modules/primereact/inputtext/inputtext.cjs.js
var inputtext_cjs = __webpack_require__(71785);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/primereact/tooltip/tooltip.cjs.js
var tooltip_cjs = __webpack_require__(64935);
// EXTERNAL MODULE: ./node_modules/primereact/utils/utils.cjs.js
var utils_cjs = __webpack_require__(7666);
;// CONCATENATED MODULE: ./demo/components/BlockViewer.tsx




const BlockViewer = (props)=>{
    const [blockView, setBlockView] = (0,react_.useState)("PREVIEW");
    const actionCopyRef = (0,react_.useRef)(null);
    const copyCode = async (event)=>{
        await navigator.clipboard.writeText(props.code);
        event.preventDefault();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "block-viewer",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "block-section",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "block-header",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "block-title",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: props.header
                                }),
                                props.new && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "badge-new",
                                    children: "New"
                                }),
                                props.free && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "badge-free",
                                    children: "Free"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "block-actions",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    tabIndex: 0,
                                    className: (0,utils_cjs.classNames)("p-link", {
                                        "block-action-active": blockView === "PREVIEW"
                                    }),
                                    onClick: ()=>setBlockView("PREVIEW"),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Preview"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: (0,utils_cjs.classNames)("p-link", {
                                        "block-action-active": blockView === "CODE"
                                    }),
                                    onClick: ()=>setBlockView("CODE"),
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Code"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    ref: actionCopyRef,
                                    tabIndex: 0,
                                    className: "p-link block-action-copy",
                                    onClick: copyCode,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "pi pi-copy"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(tooltip_cjs.Tooltip, {
                                    target: actionCopyRef,
                                    position: "bottom",
                                    content: "Copied to clipboard",
                                    event: "focus"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "block-content",
                    children: [
                        blockView === "PREVIEW" && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: props.containerClassName,
                            style: props.previewStyle,
                            children: props.children
                        }),
                        blockView === "CODE" && /*#__PURE__*/ jsx_runtime_.jsx("pre", {
                            className: "app-code",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("code", {
                                children: props.code
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const components_BlockViewer = (BlockViewer);

;// CONCATENATED MODULE: ./app/(main)/blocks/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 






const BlocksDemo = ()=>{
    const [checked, setChecked] = (0,react_.useState)(false);
    const block1 = `
    <div className="grid grid-nogutter surface-0 text-800">
        <div className="col-12 md:col-6 p-6 text-center md:text-left flex align-items-center ">
            <section>
                <span className="block text-6xl font-bold mb-1">Create the screens</span>
                <div className="text-6xl text-primary font-bold mb-3">your visitors deserve to see</div>
                <p className="mt-0 mb-4 text-700 line-height-3">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    
                <Button label="Learn More" type="button" className="mr-3" raised />
                <Button label="Live Demo" type="button" outlined />
            </section>
        </div>
        <div className="col-12 md:col-6 overflow-hidden">
            <img src="assets/images/blocks/hero/hero-1.png" alt="hero-1" className="md:ml-auto block md:h-full" style={{ clipPath: 'polygon(8% 0, 100% 0%, 100% 100%, 0 100%)' }} />
        </div>
    </div>
        `;
    const block2 = `
    <div className="surface-section px-4 py-8 md:px-6 lg:px-8 text-center">
        <div className="mb-3 font-bold text-3xl">
            <span className="text-900">One Product, </span>
            <span className="text-blue-600">Many Solutions</span>
        </div>
        <div className="text-700 mb-6">Ac turpis egestas maecenas pharetra convallis posuere morbi leo urna.</div>
        <div className="grid">
            <div className="col-12 md:col-4 mb-4 px-5">
                <span className="p-3 shadow-2 mb-3 inline-block" style={{ borderRadius: '10px' }}>
                    <i className="pi pi-desktop text-4xl text-blue-500"></i>
                </span>
                <div className="text-900 text-xl mb-3 font-medium">Built for Developers</div>
                <span className="text-700 line-height-3">Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</span>
            </div>
            <div className="col-12 md:col-4 mb-4 px-5">
                <span className="p-3 shadow-2 mb-3 inline-block" style={{ borderRadius: '10px' }}>
                    <i className="pi pi-lock text-4xl text-blue-500"></i>
                </span>
                <div className="text-900 text-xl mb-3 font-medium">End-to-End Encryption</div>
                <span className="text-700 line-height-3">Risus nec feugiat in fermentum posuere urna nec. Posuere sollicitudin aliquam ultrices sagittis.</span>
            </div>
            <div className="col-12 md:col-4 mb-4 px-5">
                <span className="p-3 shadow-2 mb-3 inline-block" style={{ borderRadius: '10px' }}>
                    <i className="pi pi-check-circle text-4xl text-blue-500"></i>
                </span>
                <div className="text-900 text-xl mb-3 font-medium">Easy to Use</div>
                <span className="text-700 line-height-3">Ornare suspendisse sed nisi lacus sed viverra tellus. Neque volutpat ac tincidunt vitae semper.</span>
            </div>
            <div className="col-12 md:col-4 mb-4 px-5">
                <span className="p-3 shadow-2 mb-3 inline-block" style={{ borderRadius: '10px' }}>
                    <i className="pi pi-globe text-4xl text-blue-500"></i>
                </span>
                <div className="text-900 text-xl mb-3 font-medium">Fast & Global Support</div>
                <span className="text-700 line-height-3">Fermentum et sollicitudin ac orci phasellus egestas tellus rutrum tellus.</span>
            </div>
            <div className="col-12 md:col-4 mb-4 px-5">
                <span className="p-3 shadow-2 mb-3 inline-block" style={{ borderRadius: '10px' }}>
                    <i className="pi pi-github text-4xl text-blue-500"></i>
                </span>
                <div className="text-900 text-xl mb-3 font-medium">Open Source</div>
                <span className="text-700 line-height-3">Nec tincidunt praesent semper feugiat. Sed adipiscing diam donec adipiscing tristique risus nec feugiat. </span>
            </div>
            <div className="col-12 md:col-4 md:mb-4 mb-0 px-3">
                <span className="p-3 shadow-2 mb-3 inline-block" style={{ borderRadius: '10px' }}>
                    <i className="pi pi-shield text-4xl text-blue-500"></i>
                </span>
                <div className="text-900 text-xl mb-3 font-medium">Trusted Securitty</div>
                <span className="text-700 line-height-3">Mattis rhoncus urna neque viverra justo nec ultrices. Id cursus metus aliquam eleifend.</span>
            </div>
        </div>
    </div>
        `;
    const block3 = `
    <div className="surface-0">
        <div className="text-900 font-bold text-6xl mb-4 text-center">Pricing Plans</div>
        <div className="text-700 text-xl mb-6 text-center line-height-3">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit numquam eligendi quos.</div>
    
        <div className="grid">
            <div className="col-12 lg:col-4">
                <div className="p-3 h-full">
                    <div className="shadow-2 p-3 h-full flex flex-column" style={{ borderRadius: '6px' }}>
                        <div className="text-900 font-medium text-xl mb-2">Basic</div>
                        <div className="text-600">Plan description</div>
                        <hr className="my-3 mx-0 border-top-1 border-bottom-none border-300" />
                        <div className="flex align-items-center">
                            <span className="font-bold text-2xl text-900">$9</span>
                            <span className="ml-2 font-medium text-600">per month</span>
                        </div>
                        <hr className="my-3 mx-0 border-top-1 border-bottom-none border-300" />
                        <ul className="list-none p-0 m-0 flex-grow-1">
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Arcu vitae elementum</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Dui faucibus in ornare</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Morbi tincidunt augue</span>
                            </li>
                        </ul>
                        <hr className="mb-3 mx-0 border-top-1 border-bottom-none border-300 mt-auto" />
                        <Button label="Buy Now" className="p-3 w-full mt-auto" />
                    </div>
                </div>
            </div>
    
            <div className="col-12 lg:col-4">
                <div className="p-3 h-full">
                    <div className="shadow-2 p-3 h-full flex flex-column" style={{ borderRadius: '6px' }}>
                        <div className="text-900 font-medium text-xl mb-2">Premium</div>
                        <div className="text-600">Plan description</div>
                        <hr className="my-3 mx-0 border-top-1 border-bottom-none border-300" />
                        <div className="flex align-items-center">
                            <span className="font-bold text-2xl text-900">$29</span>
                            <span className="ml-2 font-medium text-600">per month</span>
                        </div>
                        <hr className="my-3 mx-0 border-top-1 border-bottom-none border-300" />
                        <ul className="list-none p-0 m-0 flex-grow-1">
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Arcu vitae elementum</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Dui faucibus in ornare</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Morbi tincidunt augue</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Duis ultricies lacus sed</span>
                            </li>
                        </ul>
                        <hr className="mb-3 mx-0 border-top-1 border-bottom-none border-300" />
                        <Button label="Buy Now" className="p-3 w-full" />
                    </div>
                </div>
            </div>
    
            <div className="col-12 lg:col-4">
                <div className="p-3 h-full">
                    <div className="shadow-2 p-3 flex flex-column" style={{ borderRadius: '6px' }}>
                        <div className="text-900 font-medium text-xl mb-2">Enterprise</div>
                        <div className="text-600">Plan description</div>
                        <hr className="my-3 mx-0 border-top-1 border-bottom-none border-300" />
                        <div className="flex align-items-center">
                            <span className="font-bold text-2xl text-900">$49</span>
                            <span className="ml-2 font-medium text-600">per month</span>
                        </div>
                        <hr className="my-3 mx-0 border-top-1 border-bottom-none border-300" />
                        <ul className="list-none p-0 m-0 flex-grow-1">
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Arcu vitae elementum</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Dui faucibus in ornare</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Morbi tincidunt augue</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Duis ultricies lacus sed</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Imperdiet proin</span>
                            </li>
                            <li className="flex align-items-center mb-3">
                                <i className="pi pi-check-circle text-green-500 mr-2"></i>
                                <span className="text-900">Nisi scelerisque</span>
                            </li>
                        </ul>
                        <hr className="mb-3 mx-0 border-top-1 border-bottom-none border-300" />
                        <Button label="Buy Now" className="p-3 w-full" outlined />
                    </div>
                </div>
            </div>
        </div>
    </div>
        `;
    const block4 = `
    <div className="surface-0 text-700 text-center">
        <div className="text-blue-600 font-bold mb-3"><i className="pi pi-discord"></i>&nbsp;POWERED BY DISCORD</div>
        <div className="text-900 font-bold text-5xl mb-3">Join Our Design Community</div>
        <div className="text-700 text-2xl mb-5">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit numquam eligendi quos.</div>
        <Button label="Join Now" icon="pi pi-discord" className="font-bold px-5 py-3 white-space-nowrap" rounded raised />
    </div>
        `;
    const block5 = `
    <div className="bg-bluegray-900 text-gray-100 p-3 flex justify-content-between lg:justify-content-center align-items-center flex-wrap">
        <div className="font-bold mr-8">🔥 Hot Deals!</div>
        <div className="align-items-center hidden lg:flex">
            <span className="line-height-3">Libero voluptatum atque exercitationem praesentium provident odit.</span>
        </div>
        <a className="flex align-items-center ml-2 mr-8">
            <span className="underline font-bold">Learn More</span>
        </a>
        <a className="flex align-items-center no-underline justify-content-center border-circle text-100 hover:bg-bluegray-700 cursor-pointer transition-colors transition-duration-150" style={{ width: '2rem', height: '2rem' }}>
            <i className="pi pi-times"></i>
        </a>
    </div>
        `;
    const block6 = `
    <div className="surface-0">
        <ul className="list-none p-0 m-0 flex align-items-center font-medium mb-3">
            <li>
                <a className="text-500 no-underline line-height-3 cursor-pointer">Application</a>
            </li>
            <li className="px-2">
                <i className="pi pi-angle-right text-500 line-height-3"></i>
            </li>
            <li>
                <span className="text-900 line-height-3">Analytics</span>
            </li>
        </ul>
        <div className="flex align-items-start flex-column lg:justify-content-between lg:flex-row">
            <div>
                <div className="font-medium text-3xl text-900">Customers</div>
                <div className="flex align-items-center text-700 flex-wrap">
                    <div className="mr-5 flex align-items-center mt-3">
                        <i className="pi pi-users mr-2"></i>
                        <span>332 Active Users</span>
                    </div>
                    <div className="mr-5 flex align-items-center mt-3">
                        <i className="pi pi-globe mr-2"></i>
                        <span>9402 Sessions</span>
                    </div>
                    <div className="flex align-items-center mt-3">
                        <i className="pi pi-clock mr-2"></i>
                        <span>2.32m Avg. Duration</span>
                    </div>
                </div>
            </div>
            <div className="mt-3 lg:mt-0">
                <Button label="Add" className="mr-2" outlined icon="pi pi-user-plus" />
                <Button label="Save" icon="pi pi-check" />
            </div>
        </div>
    </div>
        `;
    const block7 = `
    <div className="grid">
        <div className="col-12 md:col-6 lg:col-3">
            <div className="surface-0 shadow-2 p-3 border-1 border-50 border-round">
                <div className="flex justify-content-between mb-3">
                    <div>
                        <span className="block text-500 font-medium mb-3">Orders</span>
                        <div className="text-900 font-medium text-xl">152</div>
                    </div>
                    <div className="flex align-items-center justify-content-center bg-blue-100 border-round" style={{ width: '2.5rem', height: '2.5rem' }}>
                        <i className="pi pi-shopping-cart text-blue-500 text-xl"></i>
                    </div>
                </div>
                <span className="text-green-500 font-medium">24 new </span>
                <span className="text-500">since last visit</span>
            </div>
        </div>
        <div className="col-12 md:col-6 lg:col-3">
            <div className="surface-0 shadow-2 p-3 border-1 border-50 border-round">
                <div className="flex justify-content-between mb-3">
                    <div>
                        <span className="block text-500 font-medium mb-3">Revenue</span>
                        <div className="text-900 font-medium text-xl">$2.100</div>
                    </div>
                    <div className="flex align-items-center justify-content-center bg-orange-100 border-round" style={{ width: '2.5rem', height: '2.5rem' }}>
                        <i className="pi pi-map-marker text-orange-500 text-xl"></i>
                    </div>
                </div>
                <span className="text-green-500 font-medium">%52+ </span>
                <span className="text-500">since last week</span>
            </div>
        </div>
        <div className="col-12 md:col-6 lg:col-3">
            <div className="surface-0 shadow-2 p-3 border-1 border-50 border-round">
                <div className="flex justify-content-between mb-3">
                    <div>
                        <span className="block text-500 font-medium mb-3">Customers</span>
                        <div className="text-900 font-medium text-xl">28441</div>
                    </div>
                    <div className="flex align-items-center justify-content-center bg-cyan-100 border-round" style={{ width: '2.5rem', height: '2.5rem' }}>
                        <i className="pi pi-inbox text-cyan-500 text-xl"></i>
                    </div>
                </div>
                <span className="text-green-500 font-medium">520  </span>
                <span className="text-500">newly registered</span>
            </div>
        </div>
        <div className="col-12 md:col-6 lg:col-3">
            <div className="surface-0 shadow-2 p-3 border-1 border-50 border-round">
                <div className="flex justify-content-between mb-3">
                    <div>
                        <span className="block text-500 font-medium mb-3">Comments</span>
                        <div className="text-900 font-medium text-xl">152 Unread</div>
                    </div>
                    <div className="flex align-items-center justify-content-center bg-purple-100 border-round" style={{ width: '2.5rem', height: '2.5rem' }}>
                        <i className="pi pi-comment text-purple-500 text-xl"></i>
                    </div>
                </div>
                <span className="text-green-500 font-medium">85 </span>
                <span className="text-500">responded</span>
            </div>
        </div>
    </div>
        `;
    const block8 = `
    <div className="flex align-items-center justify-content-center">
        <div className="surface-card p-4 shadow-2 border-round w-full lg:w-6">
            <div className="text-center mb-5">
                <img src="assets/images/blocks/logos/hyper.svg" alt="hyper" height={50} className="mb-3" />
                <div className="text-900 text-3xl font-medium mb-3">Welcome Back</div>
                <span className="text-600 font-medium line-height-3">Do not have an account?</span>
                <a className="font-medium no-underline ml-2 text-blue-500 cursor-pointer">Create today!</a>
            </div>
    
            <div>
                <label htmlFor="email" className="block text-900 font-medium mb-2">Email</label>
                <InputText id="email" type="text" placeholder="Email address" className="w-full mb-3" />
    
                <label htmlFor="password" className="block text-900 font-medium mb-2">Password</label>
                <InputText id="password" type="password" placeholder="Password" className="w-full mb-3" />
    
                <div className="flex align-items-center justify-content-between mb-6">
                    <div className="flex align-items-center">
                        <Checkbox id="rememberme" onChange={e => setChecked(e.checked)} checked={checked} className="mr-2" />
                        <label htmlFor="rememberme" className="text-900">Remember me</label>
                    </div>
                    <a className="font-medium no-underline ml-2 text-blue-500 text-right cursor-pointer">Forgot your password?</a>
                </div>
    
                <Button label="Sign In" icon="pi pi-user" className="w-full" />
            </div>
        </div>
    </div>
        `;
    const block9 = `
    <div className="surface-0">
        <div className="font-medium text-3xl text-900 mb-3">Movie Information</div>
        <div className="text-500 mb-5">Morbi tristique blandit turpis. In viverra ligula id nulla hendrerit rutrum.</div>
        <ul className="list-none p-0 m-0">
            <li className="flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap">
                <div className="text-500 w-6 md:w-2 font-medium">Title</div>
                <div className="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">Heat</div>
                <div className="w-6 md:w-2 flex justify-content-end">
                    <Button label="Edit" icon="pi pi-pencil" text />
                </div>
            </li>
            <li className="flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap">
                <div className="text-500 w-6 md:w-2 font-medium">Genre</div>
                <div className="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">
                    <Chip label="Crime" className="mr-2" />
                    <Chip label="Drama" className="mr-2" />
                    <Chip label="Thriller" />
                </div>
                <div className="w-6 md:w-2 flex justify-content-end">
                    <Button label="Edit" icon="pi pi-pencil" text />
                </div>
            </li>
            <li className="flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap">
                <div className="text-500 w-6 md:w-2 font-medium">Director</div>
                <div className="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">Michael Mann</div>
                <div className="w-6 md:w-2 flex justify-content-end">
                    <Button label="Edit" icon="pi pi-pencil" text />
                </div>
            </li>
            <li className="flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap">
                <div className="text-500 w-6 md:w-2 font-medium">Actors</div>
                <div className="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">Robert De Niro, Al Pacino</div>
                <div className="w-6 md:w-2 flex justify-content-end">
                    <Button label="Edit" icon="pi pi-pencil" text />
                </div>
            </li>
            <li className="flex align-items-center py-3 px-2 border-top-1 border-bottom-1 border-300 flex-wrap">
                <div className="text-500 w-6 md:w-2 font-medium">Plot</div>
                <div className="text-900 w-full md:w-8 md:flex-order-0 flex-order-1 line-height-3">
                    A group of professional bank robbers start to feel the heat from police
                    when they unknowingly leave a clue at their latest heist.</div>
                <div className="w-6 md:w-2 flex justify-content-end">
                    <Button label="Edit" icon="pi pi-pencil" text />
                </div>
            </li>
        </ul>
    </div>
        `;
    const block10 = `
    <div className="surface-0 p-4 shadow-2 border-round">
        <div className="text-3xl font-medium text-900 mb-3">Card Title</div>
        <div className="font-medium text-500 mb-3">Vivamus id nisl interdum, blandit augue sit amet, eleifend mi.</div>
        <div style={{ height: '150px' }} className="border-2 border-dashed border-300"></div>
    </div>
        `;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Hero",
                code: block1,
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-nogutter surface-0 text-800",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 md:col-6 p-6 text-center md:text-left flex align-items-center ",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "block text-6xl font-bold mb-1",
                                        children: "Create the screens"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-6xl text-primary font-bold mb-3",
                                        children: "your visitors deserve to see"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "mt-0 mb-4 text-700 line-height-3",
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        label: "Learn More",
                                        type: "button",
                                        className: "mr-3",
                                        raised: true
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        label: "Live Demo",
                                        type: "button",
                                        outlined: true
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 md:col-6 overflow-hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/demo/images/blocks/hero/hero-1.png",
                                alt: "hero-1",
                                className: "md:ml-auto block md:h-full",
                                style: {
                                    clipPath: "polygon(8% 0, 100% 0%, 100% 100%, 0 100%)"
                                }
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Feature",
                code: block2,
                containerClassName: "surface-0 px-4 py-8 md:px-6 lg:px-8",
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "surface-section px-4 py-8 md:px-6 lg:px-8 text-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mb-3 font-bold text-3xl",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-900",
                                    children: "One Product, "
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-blue-600",
                                    children: "Many Solutions"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-700 mb-6",
                            children: "Ac turpis egestas maecenas pharetra convallis posuere morbi leo urna."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-12 md:col-4 mb-4 px-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "p-3 shadow-2 mb-3 inline-block",
                                            style: {
                                                borderRadius: "10px"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-desktop text-4xl text-blue-500"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 text-xl mb-3 font-medium",
                                            children: "Built for Developers"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-700 line-height-3",
                                            children: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-12 md:col-4 mb-4 px-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "p-3 shadow-2 mb-3 inline-block",
                                            style: {
                                                borderRadius: "10px"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-lock text-4xl text-blue-500"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 text-xl mb-3 font-medium",
                                            children: "End-to-End Encryption"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-700 line-height-3",
                                            children: "Risus nec feugiat in fermentum posuere urna nec. Posuere sollicitudin aliquam ultrices sagittis."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-12 md:col-4 mb-4 px-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "p-3 shadow-2 mb-3 inline-block",
                                            style: {
                                                borderRadius: "10px"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-check-circle text-4xl text-blue-500"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 text-xl mb-3 font-medium",
                                            children: "Easy to Use"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-700 line-height-3",
                                            children: "Ornare suspendisse sed nisi lacus sed viverra tellus. Neque volutpat ac tincidunt vitae semper."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-12 md:col-4 mb-4 px-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "p-3 shadow-2 mb-3 inline-block",
                                            style: {
                                                borderRadius: "10px"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-globe text-4xl text-blue-500"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 text-xl mb-3 font-medium",
                                            children: "Fast & Global Support"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-700 line-height-3",
                                            children: "Fermentum et sollicitudin ac orci phasellus egestas tellus rutrum tellus."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-12 md:col-4 mb-4 px-5",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "p-3 shadow-2 mb-3 inline-block",
                                            style: {
                                                borderRadius: "10px"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-github text-4xl text-blue-500"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 text-xl mb-3 font-medium",
                                            children: "Open Source"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                            className: "text-700 line-height-3",
                                            children: [
                                                "Nec tincidunt praesent semper feugiat. Sed adipiscing diam donec adipiscing tristique risus nec feugiat.",
                                                " "
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "col-12 md:col-4 md:mb-4 mb-0 px-3",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "p-3 shadow-2 mb-3 inline-block",
                                            style: {
                                                borderRadius: "10px"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-shield text-4xl text-blue-500"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 text-xl mb-3 font-medium",
                                            children: "Trusted Securitty"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-700 line-height-3",
                                            children: "Mattis rhoncus urna neque viverra justo nec ultrices. Id cursus metus aliquam eleifend."
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Pricing",
                code: block3,
                containerClassName: "surface-0 px-4 py-8 md:px-6 lg:px-8",
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "surface-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-900 font-bold text-6xl mb-4 text-center",
                            children: "Pricing Plans"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-700 text-xl mb-6 text-center line-height-3",
                            children: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit numquam eligendi quos."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "grid",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-12 lg:col-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "p-3 h-full",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "shadow-2 p-3 h-full flex flex-column",
                                            style: {
                                                borderRadius: "6px"
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-900 font-medium text-xl mb-2",
                                                    children: "Basic"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-600",
                                                    children: "Plan description"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "my-3 mx-0 border-top-1 border-bottom-none border-300"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex align-items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-bold text-2xl text-900",
                                                            children: "$9"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "ml-2 font-medium text-600",
                                                            children: "per month"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "my-3 mx-0 border-top-1 border-bottom-none border-300"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "list-none p-0 m-0 flex-grow-1",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Arcu vitae elementum"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Dui faucibus in ornare"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Morbi tincidunt augue"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "mb-3 mx-0 border-top-1 border-bottom-none border-300 mt-auto"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                    label: "Buy Now",
                                                    className: "p-3 w-full mt-auto"
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-12 lg:col-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "p-3 h-full",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "shadow-2 p-3 h-full flex flex-column",
                                            style: {
                                                borderRadius: "6px"
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-900 font-medium text-xl mb-2",
                                                    children: "Premium"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-600",
                                                    children: "Plan description"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "my-3 mx-0 border-top-1 border-bottom-none border-300"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex align-items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-bold text-2xl text-900",
                                                            children: "$29"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "ml-2 font-medium text-600",
                                                            children: "per month"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "my-3 mx-0 border-top-1 border-bottom-none border-300"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "list-none p-0 m-0 flex-grow-1",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Arcu vitae elementum"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Dui faucibus in ornare"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Morbi tincidunt augue"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Duis ultricies lacus sed"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "mb-3 mx-0 border-top-1 border-bottom-none border-300"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                    label: "Buy Now",
                                                    className: "p-3 w-full"
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-12 lg:col-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "p-3 h-full",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "shadow-2 p-3 flex flex-column",
                                            style: {
                                                borderRadius: "6px"
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-900 font-medium text-xl mb-2",
                                                    children: "Enterprise"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text-600",
                                                    children: "Plan description"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "my-3 mx-0 border-top-1 border-bottom-none border-300"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex align-items-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "font-bold text-2xl text-900",
                                                            children: "$49"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: "ml-2 font-medium text-600",
                                                            children: "per month"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "my-3 mx-0 border-top-1 border-bottom-none border-300"
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                    className: "list-none p-0 m-0 flex-grow-1",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Arcu vitae elementum"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Dui faucibus in ornare"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Morbi tincidunt augue"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Duis ultricies lacus sed"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Imperdiet proin"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                            className: "flex align-items-center mb-3",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "pi pi-check-circle text-green-500 mr-2"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-900",
                                                                    children: "Nisi scelerisque"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                                    className: "mb-3 mx-0 border-top-1 border-bottom-none border-300"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                    label: "Buy Now",
                                                    className: "p-3 w-full",
                                                    outlined: true
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Call to Action",
                code: block4,
                containerClassName: "surface-0 px-4 py-8 md:px-6 lg:px-8",
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "surface-0 text-700 text-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "text-blue-600 font-bold mb-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "pi pi-discord"
                                }),
                                "\xa0POWERED BY DISCORD"
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-900 font-bold text-5xl mb-3",
                            children: "Join Our Design Community"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-700 text-2xl mb-5",
                            children: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit numquam eligendi quos."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                            label: "Join Now",
                            icon: "pi pi-discord",
                            className: "font-bold px-5 py-3 white-space-nowrap",
                            raised: true,
                            rounded: true
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Banner",
                code: block5,
                containerClassName: "surface-0 py-8",
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "bg-bluegray-900 text-gray-100 p-3 flex justify-content-between lg:justify-content-center align-items-center flex-wrap",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "font-bold mr-8",
                            children: "\uD83D\uDD25 Hot Deals!"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "align-items-center hidden lg:flex",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "line-height-3",
                                children: "Libero voluptatum atque exercitationem praesentium provident odit."
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "flex align-items-center ml-2 mr-8",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "underline font-bold",
                                children: "Learn More"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "flex align-items-center no-underline justify-content-center border-circle text-100 hover:bg-bluegray-700 cursor-pointer transition-colors transition-duration-150",
                            style: {
                                width: "2rem",
                                height: "2rem"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "pi pi-times"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "block-category-title",
                children: "Application UI"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Page Heading",
                code: block6,
                containerClassName: "surface-0 px-4 py-5 md:px-6 lg:px-8",
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "surface-0",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-none p-0 m-0 flex align-items-center font-medium mb-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "text-500 no-underline line-height-3 cursor-pointer",
                                        children: "Application"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "px-2",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "pi pi-angle-right text-500 line-height-3"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-900 line-height-3",
                                        children: "Analytics"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex align-items-start flex-column lg:justify-content-between lg:flex-row",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "font-medium text-3xl text-900",
                                            children: "Customers"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex align-items-center text-700 flex-wrap",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "mr-5 flex align-items-center mt-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "pi pi-users mr-2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "332 Active Users"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "mr-5 flex align-items-center mt-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "pi pi-globe mr-2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "9402 Sessions"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex align-items-center mt-3",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "pi pi-clock mr-2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            children: "2.32m Avg. Duration"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "mt-3 lg:mt-0",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                            label: "Add",
                                            className: "mr-2",
                                            outlined: true,
                                            icon: "pi pi-user-plus"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                            label: "Save",
                                            icon: "pi pi-check"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Stats",
                code: block7,
                containerClassName: "px-4 py-5 md:px-6 lg:px-8",
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 md:col-6 lg:col-3",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "surface-0 shadow-2 p-3 border-1 border-50 border-round",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex justify-content-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "block text-500 font-medium mb-3",
                                                        children: "Orders"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-900 font-medium text-xl",
                                                        children: "152"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex align-items-center justify-content-center bg-blue-100 border-round",
                                                style: {
                                                    width: "2.5rem",
                                                    height: "2.5rem"
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "pi pi-shopping-cart text-blue-500 text-xl"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-green-500 font-medium",
                                        children: [
                                            "24 new",
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-500",
                                        children: "since last visit"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 md:col-6 lg:col-3",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "surface-0 shadow-2 p-3 border-1 border-50 border-round",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex justify-content-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "block text-500 font-medium mb-3",
                                                        children: "Revenue"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-900 font-medium text-xl",
                                                        children: "$2.100"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex align-items-center justify-content-center bg-orange-100 border-round",
                                                style: {
                                                    width: "2.5rem",
                                                    height: "2.5rem"
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "pi pi-map-marker text-orange-500 text-xl"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-green-500 font-medium",
                                        children: [
                                            "%52+",
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-500",
                                        children: "since last week"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 md:col-6 lg:col-3",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "surface-0 shadow-2 p-3 border-1 border-50 border-round",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex justify-content-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "block text-500 font-medium mb-3",
                                                        children: "Customers"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-900 font-medium text-xl",
                                                        children: "28441"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex align-items-center justify-content-center bg-cyan-100 border-round",
                                                style: {
                                                    width: "2.5rem",
                                                    height: "2.5rem"
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "pi pi-inbox text-cyan-500 text-xl"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-green-500 font-medium",
                                        children: [
                                            "520",
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-500",
                                        children: "newly registered"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-12 md:col-6 lg:col-3",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "surface-0 shadow-2 p-3 border-1 border-50 border-round",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex justify-content-between mb-3",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "block text-500 font-medium mb-3",
                                                        children: "Comments"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "text-900 font-medium text-xl",
                                                        children: "152 Unread"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex align-items-center justify-content-center bg-purple-100 border-round",
                                                style: {
                                                    width: "2.5rem",
                                                    height: "2.5rem"
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "pi pi-comment text-purple-500 text-xl"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-green-500 font-medium",
                                        children: [
                                            "85",
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-500",
                                        children: "responded"
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Sign-In",
                code: block8,
                containerClassName: "px-4 py-8 md:px-6 lg:px-8",
                free: true,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex align-items-center justify-content-center",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "surface-card p-4 shadow-2 border-round w-full lg:w-6",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-center mb-5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/demo/images/blocks/logos/hyper.svg",
                                        alt: "hyper",
                                        height: 50,
                                        className: "mb-3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-900 text-3xl font-medium mb-3",
                                        children: "Welcome Back"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-600 font-medium line-height-3",
                                        children: "Do not have an account?"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "font-medium no-underline ml-2 text-blue-500 cursor-pointer",
                                        children: "Create today!"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "email",
                                        className: "block text-900 font-medium mb-2",
                                        children: "Email"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                        id: "email",
                                        type: "text",
                                        placeholder: "Email address",
                                        className: "w-full mb-3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        htmlFor: "password",
                                        className: "block text-900 font-medium mb-2",
                                        children: "Password"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(inputtext_cjs.InputText, {
                                        id: "password",
                                        type: "password",
                                        placeholder: "Password",
                                        className: "w-full mb-3"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex align-items-center justify-content-between mb-6",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex align-items-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(checkbox_cjs/* Checkbox */.X, {
                                                        id: "rememberme",
                                                        onChange: (e)=>setChecked(e.checked ?? false),
                                                        checked: checked,
                                                        className: "mr-2"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        htmlFor: "rememberme",
                                                        className: "text-900",
                                                        children: "Remember me"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                className: "font-medium no-underline ml-2 text-blue-500 text-right cursor-pointer",
                                                children: "Forgot your password?"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                        label: "Sign In",
                                        icon: "pi pi-user",
                                        className: "w-full"
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Description List",
                code: block9,
                containerClassName: "surface-0 px-4 py-8 md:px-6 lg:px-8",
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "surface-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "font-medium text-3xl text-900 mb-3",
                            children: "Movie Information"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-500 mb-5",
                            children: "Morbi tristique blandit turpis. In viverra ligula id nulla hendrerit rutrum."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "list-none p-0 m-0",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-500 w-6 md:w-2 font-medium",
                                            children: "Title"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 w-full md:w-8 md:flex-order-0 flex-order-1",
                                            children: "Heat"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-6 md:w-2 flex justify-content-end",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                label: "Edit",
                                                icon: "pi pi-pencil",
                                                text: true
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-500 w-6 md:w-2 font-medium",
                                            children: "Genre"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "text-900 w-full md:w-8 md:flex-order-0 flex-order-1",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(chip_cjs/* Chip */.A, {
                                                    label: "Crime",
                                                    className: "mr-2"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(chip_cjs/* Chip */.A, {
                                                    label: "Drama",
                                                    className: "mr-2"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(chip_cjs/* Chip */.A, {
                                                    label: "Thriller"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-6 md:w-2 flex justify-content-end",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                label: "Edit",
                                                icon: "pi pi-pencil",
                                                text: true
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-500 w-6 md:w-2 font-medium",
                                            children: "Director"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 w-full md:w-8 md:flex-order-0 flex-order-1",
                                            children: "Michael Mann"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-6 md:w-2 flex justify-content-end",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                label: "Edit",
                                                icon: "pi pi-pencil",
                                                text: true
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-500 w-6 md:w-2 font-medium",
                                            children: "Actors"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 w-full md:w-8 md:flex-order-0 flex-order-1",
                                            children: "Robert De Niro, Al Pacino"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-6 md:w-2 flex justify-content-end",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                label: "Edit",
                                                icon: "pi pi-pencil",
                                                text: true
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "flex align-items-center py-3 px-2 border-top-1 border-bottom-1 border-300 flex-wrap",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-500 w-6 md:w-2 font-medium",
                                            children: "Plot"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-900 w-full md:w-8 md:flex-order-0 flex-order-1 line-height-3",
                                            children: "A group of professional bank robbers start to feel the heat from police when they unknowingly leave a clue at their latest heist."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-6 md:w-2 flex justify-content-end",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                                label: "Edit",
                                                icon: "pi pi-pencil",
                                                text: true
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_BlockViewer, {
                header: "Card",
                code: block10,
                containerClassName: "px-4 py-8 md:px-6 lg:px-8",
                free: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "surface-0 p-4 shadow-2 border-round",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "text-3xl font-medium text-900 mb-3",
                            children: "Card Title"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "font-medium text-500 mb-3",
                            children: "Vivamus id nisl interdum, blandit augue sit amet, eleifend mi."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                height: "150px"
                            },
                            className: "border-2 border-dashed border-300"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const page = (BlocksDemo);


/***/ }),

/***/ 80911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\blocks\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3763,1864,1663,984,1785,5767,6903,7636,9842,6065,2547,4972], () => (__webpack_exec__(75218)));
module.exports = __webpack_exports__;

})();