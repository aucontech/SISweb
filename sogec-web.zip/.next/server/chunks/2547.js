"use strict";
exports.id = 2547;
exports.ids = [2547];
exports.modules = {

/***/ 92547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90284);
/* harmony import */ var primereact_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18176);
/* harmony import */ var primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63579);
/* harmony import */ var primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23064);
/* harmony import */ var primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63862);
/* harmony import */ var primereact_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7666);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6538);
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AppConfig = (props)=>{
    const { layoutConfig, setLayoutConfig, layoutState, setLayoutState, isSlim, isSlimPlus, isHorizontal } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_layoutcontext__WEBPACK_IMPORTED_MODULE_2__/* .LayoutContext */ .V);
    const { changeTheme } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(primereact_api__WEBPACK_IMPORTED_MODULE_3__.PrimeReactContext);
    const scales = [
        12,
        13,
        14,
        15,
        16
    ];
    const componentThemes = [
        {
            name: "indigo",
            color: "#6366F1"
        },
        {
            name: "blue",
            color: "#3B82F6"
        },
        {
            name: "purple",
            color: "#8B5CF6"
        },
        {
            name: "teal",
            color: "#14B8A6"
        },
        {
            name: "cyan",
            color: "#06b6d4"
        },
        {
            name: "green",
            color: "#10b981"
        },
        {
            name: "orange",
            color: "#f59e0b"
        },
        {
            name: "pink",
            color: "#d946ef"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isSlim() || isSlimPlus() || isHorizontal()) {
            setLayoutState((prevState)=>({
                    ...prevState,
                    resetMenu: true
                }));
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.menuMode
    ]);
    const onConfigButtonClick = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: true
            }));
    };
    const onConfigSidebarHide = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                configSidebarVisible: false
            }));
    };
    const changeInputStyle = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                inputStyle: e.value
            }));
    };
    const changeRipple = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                ripple: e.value
            }));
    };
    const changeMenuMode = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuMode: e.value
            }));
    };
    const changeMenuTheme = (e)=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                menuTheme: e.value
            }));
    };
    const changeColorScheme = (colorScheme)=>{
        changeTheme?.(layoutConfig.colorScheme, colorScheme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    colorScheme
                }));
        });
    };
    const _changeTheme = (theme)=>{
        changeTheme?.(layoutConfig.theme, theme, "theme-link", ()=>{
            setLayoutConfig((prevState)=>({
                    ...prevState,
                    theme
                }));
        });
    };
    const decrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale - 1
            }));
    };
    const incrementScale = ()=>{
        setLayoutConfig((prevState)=>({
                ...prevState,
                scale: prevState.scale + 1
            }));
    };
    const applyScale = ()=>{
        document.documentElement.style.fontSize = layoutConfig.scale + "px";
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        applyScale();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        layoutConfig.scale
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "layout-config-button config-link",
                type: "button",
                onClick: onConfigButtonClick,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                    className: "pi pi-cog"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(primereact_sidebar__WEBPACK_IMPORTED_MODULE_4__/* .Sidebar */ .Y, {
                visible: layoutState.configSidebarVisible,
                onHide: onConfigSidebarHide,
                position: "right",
                className: "layout-config-sidebar w-18rem",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Themes"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap row-gap-3",
                        children: componentThemes.map((theme, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    type: "button",
                                    className: "cursor-pointer p-link w-2rem h-2rem border-circle flex-shrink-0 flex align-items-center justify-content-center",
                                    onClick: ()=>_changeTheme(theme.name),
                                    style: {
                                        backgroundColor: theme.color
                                    },
                                    children: theme.name == layoutConfig.theme && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "pi pi-check text-white"
                                    })
                                })
                            }, i);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Scale"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex align-items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-minus",
                                type: "button",
                                onClick: decrementScale,
                                className: "w-2rem h-2rem mr-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[0]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex gap-2 align-items-center",
                                children: scales.map((s, i)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: (0,primereact_utils__WEBPACK_IMPORTED_MODULE_6__.classNames)("pi pi-circle-fill text-300", {
                                            "text-primary-500": s === layoutConfig.scale
                                        })
                                    }, i);
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_button__WEBPACK_IMPORTED_MODULE_5__.Button, {
                                icon: "pi pi-plus",
                                type: "button",
                                onClick: incrementScale,
                                className: "w-2rem h-2rem ml-2",
                                rounded: true,
                                text: true,
                                disabled: layoutConfig.scale === scales[scales.length - 1]
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Type"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap row-gap-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "static",
                                                checked: layoutConfig.menuMode === "static",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode1"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode1",
                                                children: "Static"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "overlay",
                                                checked: layoutConfig.menuMode === "overlay",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode2"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode2",
                                                children: "Overlay"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim",
                                                checked: layoutConfig.menuMode === "slim",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode3"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode3",
                                                children: "Slim"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "slim-plus",
                                                checked: layoutConfig.menuMode === "slim-plus",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode4"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode4",
                                                children: "Slim +"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "drawer",
                                                checked: layoutConfig.menuMode === "drawer",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode7"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode7",
                                                children: "Drawer"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "reveal",
                                                checked: layoutConfig.menuMode === "reveal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode6",
                                                children: "Reveal"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex align-items-center gap-2 w-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "menuMode",
                                                value: "horizontal",
                                                checked: layoutConfig.menuMode === "horizontal",
                                                onChange: (e)=>changeMenuMode(e),
                                                inputId: "mode5"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "mode5",
                                                children: "Horizontal"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Menu Theme"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "colorScheme",
                                        checked: layoutConfig.menuTheme === "colorScheme",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-colorscheme"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-colorscheme",
                                        children: "Color Scheme"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "primaryColor",
                                        checked: layoutConfig.menuTheme === "primaryColor",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-primarycolor"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-primarycolor",
                                        children: "Primary Color"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "field-radiobutton",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                        name: "menuTheme",
                                        value: "transparent",
                                        checked: layoutConfig.menuTheme === "transparent",
                                        onChange: (e)=>changeMenuTheme(e),
                                        inputId: "menutheme-transparent"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        htmlFor: "menutheme-transparent",
                                        children: "Transparent"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                        children: "Color Scheme"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "light",
                                checked: layoutConfig.colorScheme === "light",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-light"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-light",
                                children: "Light"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dim",
                                checked: layoutConfig.colorScheme === "dim",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dim"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dim",
                                children: "Dim"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "field-radiobutton",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                name: "colorScheme",
                                value: "dark",
                                checked: layoutConfig.colorScheme === "dark",
                                onChange: (e)=>changeColorScheme(e.value),
                                inputId: "mode-dark"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                htmlFor: "mode-dark",
                                children: "Dark"
                            })
                        ]
                    }),
                    !props.minimal && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Input Style"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "outlined",
                                                checked: layoutConfig.inputStyle === "outlined",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "outlined_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "outlined_input",
                                                children: "Outlined"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "field-radiobutton flex-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_radiobutton__WEBPACK_IMPORTED_MODULE_7__/* .RadioButton */ .E, {
                                                name: "inputStyle",
                                                value: "filled",
                                                checked: layoutConfig.inputStyle === "filled",
                                                onChange: (e)=>changeInputStyle(e),
                                                inputId: "filled_input"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "filled_input",
                                                children: "Filled"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: "Ripple Effect"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_inputswitch__WEBPACK_IMPORTED_MODULE_8__/* .InputSwitch */ .Q, {
                                checked: layoutConfig.ripple,
                                onChange: changeRipple
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppConfig);


/***/ })

};
;