"use strict";
exports.id = 5377;
exports.ids = [5377];
exports.modules = {

/***/ 95377:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   M: () => (/* binding */ ProductService)
/* harmony export */ });
const ProductService = {
    getProductsSmall () {
        return fetch("/demo/data/products-small.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getProducts () {
        return fetch("/demo/data/products.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getProductsMixed () {
        return fetch("/demo/data/products-mixed.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getProductsWithOrdersSmall () {
        return fetch("/demo/data/products-orders-small.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    },
    getProductsWithOrdersLarge () {
        return fetch("/demo/data/products-orders.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    }
};


/***/ })

};
;