exports.id = 9999;
exports.ids = [9999];
exports.modules = {

/***/ 44742:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

'use client';
'use strict';

Object.defineProperty(exports, "__esModule", ({ value: true }));

var React = __webpack_require__(18038);
var iconbase = __webpack_require__(76817);

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  }
  n["default"] = e;
  return Object.freeze(n);
}

var React__namespace = /*#__PURE__*/_interopNamespace(React);

function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}

var AngleDoubleDownIcon = /*#__PURE__*/React__namespace.memo( /*#__PURE__*/React__namespace.forwardRef(function (inProps, ref) {
  var pti = iconbase.IconBase.getPTI(inProps);
  return /*#__PURE__*/React__namespace.createElement("svg", _extends({
    ref: ref,
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, pti), /*#__PURE__*/React__namespace.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M6.70786 6.59831C6.80043 6.63674 6.89974 6.65629 6.99997 6.65581C7.19621 6.64081 7.37877 6.54953 7.50853 6.40153L11.0685 2.8416C11.1364 2.69925 11.1586 2.53932 11.132 2.38384C11.1053 2.22837 11.0311 2.08498 10.9195 1.97343C10.808 1.86188 10.6646 1.78766 10.5091 1.76099C10.3536 1.73431 10.1937 1.75649 10.0513 1.82448L6.99997 4.87585L3.9486 1.82448C3.80625 1.75649 3.64632 1.73431 3.49084 1.76099C3.33536 1.78766 3.19197 1.86188 3.08043 1.97343C2.96888 2.08498 2.89466 2.22837 2.86798 2.38384C2.84131 2.53932 2.86349 2.69925 2.93147 2.8416L6.46089 6.43205C6.53132 6.50336 6.61528 6.55989 6.70786 6.59831ZM6.70786 12.1925C6.80043 12.2309 6.89974 12.2505 6.99997 12.25C7.10241 12.2465 7.20306 12.2222 7.29575 12.1785C7.38845 12.1348 7.47124 12.0726 7.53905 11.9957L11.0685 8.46629C11.1614 8.32292 11.2036 8.15249 11.1881 7.98233C11.1727 7.81216 11.1005 7.6521 10.9833 7.52781C10.866 7.40353 10.7104 7.3222 10.5415 7.29688C10.3725 7.27155 10.1999 7.30369 10.0513 7.38814L6.99997 10.4395L3.9486 7.38814C3.80006 7.30369 3.62747 7.27155 3.45849 7.29688C3.28951 7.3222 3.13393 7.40353 3.01667 7.52781C2.89942 7.6521 2.82729 7.81216 2.81184 7.98233C2.79639 8.15249 2.83852 8.32292 2.93148 8.46629L6.4609 12.0262C6.53133 12.0975 6.61529 12.1541 6.70786 12.1925Z",
    fill: "currentColor"
  }));
}));
AngleDoubleDownIcon.displayName = 'AngleDoubleDownIcon';

exports.AngleDoubleDownIcon = AngleDoubleDownIcon;


/***/ }),

/***/ 1322:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

'use client';
'use strict';

Object.defineProperty(exports, "__esModule", ({ value: true }));

var React = __webpack_require__(18038);
var iconbase = __webpack_require__(76817);

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  }
  n["default"] = e;
  return Object.freeze(n);
}

var React__namespace = /*#__PURE__*/_interopNamespace(React);

function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}

var AngleDoubleUpIcon = /*#__PURE__*/React__namespace.memo( /*#__PURE__*/React__namespace.forwardRef(function (inProps, ref) {
  var pti = iconbase.IconBase.getPTI(inProps);
  return /*#__PURE__*/React__namespace.createElement("svg", _extends({
    ref: ref,
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, pti), /*#__PURE__*/React__namespace.createElement("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M10.1504 6.67719C10.2417 6.71508 10.3396 6.73436 10.4385 6.73389C10.6338 6.74289 10.8249 6.67441 10.97 6.54334C11.1109 6.4023 11.19 6.21112 11.19 6.01178C11.19 5.81245 11.1109 5.62127 10.97 5.48023L7.45977 1.96998C7.31873 1.82912 7.12755 1.75 6.92821 1.75C6.72888 1.75 6.5377 1.82912 6.39666 1.96998L2.9165 5.45014C2.83353 5.58905 2.79755 5.751 2.81392 5.91196C2.83028 6.07293 2.89811 6.22433 3.00734 6.34369C3.11656 6.46306 3.26137 6.54402 3.42025 6.57456C3.57914 6.60511 3.74364 6.5836 3.88934 6.51325L6.89813 3.50446L9.90691 6.51325C9.97636 6.58357 10.0592 6.6393 10.1504 6.67719ZM9.93702 11.9993C10.065 12.1452 10.245 12.2352 10.4385 12.25C10.632 12.2352 10.812 12.1452 10.9399 11.9993C11.0633 11.8614 11.1315 11.6828 11.1315 11.4978C11.1315 11.3128 11.0633 11.1342 10.9399 10.9963L7.48987 7.48609C7.34883 7.34523 7.15765 7.26611 6.95832 7.26611C6.75899 7.26611 6.5678 7.34523 6.42677 7.48609L2.91652 10.9963C2.84948 11.1367 2.82761 11.2944 2.85391 11.4477C2.88022 11.601 2.9534 11.7424 3.06339 11.8524C3.17338 11.9624 3.31477 12.0356 3.46808 12.0619C3.62139 12.0882 3.77908 12.0663 3.91945 11.9993L6.92823 8.99048L9.93702 11.9993Z",
    fill: "currentColor"
  }));
}));
AngleDoubleUpIcon.displayName = 'AngleDoubleUpIcon';

exports.AngleDoubleUpIcon = AngleDoubleUpIcon;


/***/ }),

/***/ 21485:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
'use client';
'use strict';

__webpack_unused_export__ = ({ value: true });

var React = __webpack_require__(18038);
var PrimeReact = __webpack_require__(90284);
var componentbase = __webpack_require__(87095);
var hooks = __webpack_require__(85215);
var utils = __webpack_require__(7666);
var button = __webpack_require__(18176);
var angledoubledown = __webpack_require__(44742);
var angledoubleup = __webpack_require__(1322);
var angledown = __webpack_require__(77933);
var angleup = __webpack_require__(52232);
var search = __webpack_require__(85583);
var ripple = __webpack_require__(26412);

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  }
  n["default"] = e;
  return Object.freeze(n);
}

var React__namespace = /*#__PURE__*/_interopNamespace(React);
var PrimeReact__default = /*#__PURE__*/_interopDefaultLegacy(PrimeReact);

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
  return arr2;
}

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = !0,
      o = !1;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = !0, n = r;
    } finally {
      try {
        if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

var classes = {
  root: 'p-orderlist p-component',
  controls: 'p-orderlist-controls',
  droppoint: 'p-orderlist-droppoint',
  header: 'p-orderlist-header',
  list: 'p-orderlist-list',
  icon: 'p-orderlist-filter',
  filter: 'p-orderlist-filter',
  filterInput: 'p-orderlist-filter-input p-inputtext p-component',
  filterIcon: 'p-orderlist-filter-icon',
  filterContainer: 'p-orderlist-filter-container',
  container: 'p-orderlist-list-container',
  item: function item(_ref) {
    var _item = _ref.item,
      isSelected = _ref.isSelected;
    return utils.classNames('p-orderlist-item', {
      'p-highlight': isSelected(_item)
    });
  }
};
var styles = "\n@layer primereact {\n    .p-orderlist {\n        display: flex;\n    }\n    \n    .p-orderlist-controls {\n        display: flex;\n        flex-direction: column;\n        justify-content: center;\n    }\n    \n    .p-orderlist-list-container {\n        flex: 1 1 auto;\n    }\n    \n    .p-orderlist-list {\n        list-style-type: none;\n        margin: 0;\n        padding: 0;\n        overflow: auto;\n        min-height: 12rem;\n        max-height: 24rem;\n    }\n    \n    .p-orderlist-item {\n        cursor: pointer;\n        overflow: hidden;\n        position: relative;\n    }\n    \n    .p-orderlist-filter {\n        position: relative;\n    }\n    \n    .p-orderlist-filter-icon {\n        position: absolute;\n        top: 50%;\n        margin-top: -.5rem;\n    }\n    \n    .p-orderlist-filter-input {\n        width: 100%;\n    }\n    \n    .p-orderlist.p-state-disabled .p-orderlist-item,\n    .p-orderlist.p-state-disabled .p-button {\n        cursor: default;\n    }\n    \n    .p-orderlist.p-state-disabled .p-orderlist-list {\n        overflow: hidden;\n    }\n    \n    .p-orderlist .p-orderlist-droppoint {\n        height: 0.5rem;\n    }\n    \n    .p-orderlist .p-orderlist-droppoint.p-orderlist-droppoint-highlight {\n        background: var(--primary-color);\n    }\n}\n";
var OrderListBase = componentbase.ComponentBase.extend({
  defaultProps: {
    __TYPE: 'OrderList',
    id: null,
    value: null,
    header: null,
    style: null,
    className: null,
    listStyle: null,
    dragdrop: false,
    tabIndex: 0,
    filterIcon: null,
    moveUpIcon: null,
    moveTopIcon: null,
    moveDownIcon: null,
    moveBottomIcon: null,
    dataKey: null,
    breakpoint: '960px',
    onChange: null,
    itemTemplate: null,
    filter: false,
    filterBy: null,
    filterMatchMode: 'contains',
    filterLocale: undefined,
    filterPlaceholder: null,
    filterTemplate: null,
    onFilter: null,
    children: undefined
  },
  css: {
    classes: classes,
    styles: styles
  }
});

function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}

var OrderListControls = /*#__PURE__*/React__namespace.memo(function (props) {
  var moveUpIcon = props.moveUpIcon || /*#__PURE__*/React__namespace.createElement(angleup.AngleUpIcon, null);
  var moveTopIcon = props.moveTopIcon || /*#__PURE__*/React__namespace.createElement(angledoubleup.AngleDoubleUpIcon, null);
  var moveDownIcon = props.moveDownIcon || /*#__PURE__*/React__namespace.createElement(angledown.AngleDownIcon, null);
  var moveBottomIcon = props.moveBottomIcon || /*#__PURE__*/React__namespace.createElement(angledoubledown.AngleDoubleDownIcon, null);
  var ptm = props.ptm,
    cx = props.cx,
    unstyled = props.unstyled;
  var moveUp = function moveUp(event) {
    if (props.selection) {
      var value = _toConsumableArray(props.value);
      for (var i = 0; i < props.selection.length; i++) {
        var selectedItem = props.selection[i];
        var selectedItemIndex = utils.ObjectUtils.findIndexInList(selectedItem, value, props.dataKey);
        if (selectedItemIndex !== 0) {
          var movedItem = value[selectedItemIndex];
          var temp = value[selectedItemIndex - 1];
          value[selectedItemIndex - 1] = movedItem;
          value[selectedItemIndex] = temp;
        } else {
          break;
        }
      }
      if (props.onReorder) {
        props.onReorder({
          originalEvent: event,
          value: value,
          direction: 'up'
        });
      }
    }
  };
  var moveTop = function moveTop(event) {
    if (props.selection) {
      var value = _toConsumableArray(props.value);
      for (var i = props.selection.length - 1; i >= 0; i--) {
        var selectedItem = props.selection[i];
        var selectedItemIndex = utils.ObjectUtils.findIndexInList(selectedItem, value, props.dataKey);
        if (selectedItemIndex !== 0) {
          var movedItem = value.splice(selectedItemIndex, 1)[0];
          value.unshift(movedItem);
        } else {
          break;
        }
      }
      if (props.onReorder) {
        props.onReorder({
          originalEvent: event,
          value: value,
          direction: 'top'
        });
      }
    }
  };
  var moveDown = function moveDown(event) {
    if (props.selection) {
      var value = _toConsumableArray(props.value);
      for (var i = props.selection.length - 1; i >= 0; i--) {
        var selectedItem = props.selection[i];
        var selectedItemIndex = utils.ObjectUtils.findIndexInList(selectedItem, value, props.dataKey);
        if (selectedItemIndex !== value.length - 1) {
          var movedItem = value[selectedItemIndex];
          var temp = value[selectedItemIndex + 1];
          value[selectedItemIndex + 1] = movedItem;
          value[selectedItemIndex] = temp;
        } else {
          break;
        }
      }
      if (props.onReorder) {
        props.onReorder({
          originalEvent: event,
          value: value,
          direction: 'down'
        });
      }
    }
  };
  var moveBottom = function moveBottom(event) {
    if (props.selection) {
      var value = _toConsumableArray(props.value);
      for (var i = 0; i < props.selection.length; i++) {
        var selectedItem = props.selection[i];
        var selectedItemIndex = utils.ObjectUtils.findIndexInList(selectedItem, value, props.dataKey);
        if (selectedItemIndex !== value.length - 1) {
          var movedItem = value.splice(selectedItemIndex, 1)[0];
          value.push(movedItem);
        } else {
          break;
        }
      }
      if (props.onReorder) {
        props.onReorder({
          originalEvent: event,
          value: value,
          direction: 'bottom'
        });
      }
    }
  };
  var controlsProps = utils.mergeProps({
    className: cx('controls')
  }, ptm('controls', {
    hostName: props.hostName
  }));
  var moveUpButtonProps = utils.mergeProps({
    type: 'button',
    unstyled: unstyled,
    icon: moveUpIcon,
    onClick: moveUp,
    'aria-label': PrimeReact.ariaLabel('moveUp'),
    __parentMetadata: {
      parent: props.metaData
    }
  }, ptm('moveUpButton'));
  var moveTopButtonProps = utils.mergeProps({
    type: 'button',
    unstyled: unstyled,
    icon: moveTopIcon,
    onClick: moveTop,
    'aria-label': PrimeReact.ariaLabel('moveTop'),
    __parentMetadata: {
      parent: props.metaData
    }
  }, ptm('moveTopButton'));
  var moveDownButtonProps = utils.mergeProps({
    type: 'button',
    unstyled: unstyled,
    icon: moveDownIcon,
    onClick: moveDown,
    'aria-label': PrimeReact.ariaLabel('moveDown'),
    __parentMetadata: {
      parent: props.metaData
    }
  }, ptm('moveDownButton'));
  var moveBottomButtonProps = utils.mergeProps({
    type: 'button',
    unstyled: unstyled,
    icon: moveBottomIcon,
    onClick: moveBottom,
    'aria-label': PrimeReact.ariaLabel('moveBottom'),
    __parentMetadata: {
      parent: props.metaData
    }
  }, ptm('moveBottomButton'));
  return /*#__PURE__*/React__namespace.createElement("div", controlsProps, /*#__PURE__*/React__namespace.createElement(button.Button, _extends({
    pt: ptm('moveUpButton')
  }, moveUpButtonProps)), /*#__PURE__*/React__namespace.createElement(button.Button, _extends({
    pt: ptm('moveTopButton')
  }, moveTopButtonProps)), /*#__PURE__*/React__namespace.createElement(button.Button, _extends({
    pt: ptm('moveDownButton')
  }, moveDownButtonProps)), /*#__PURE__*/React__namespace.createElement(button.Button, _extends({
    pt: ptm('moveBottomButton')
  }, moveBottomButtonProps)));
});
OrderListControls.displayName = 'OrderListControls';

function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}

function _toPrimitive(input, hint) {
  if (_typeof(input) !== "object" || input === null) return input;
  var prim = input[Symbol.toPrimitive];
  if (prim !== undefined) {
    var res = prim.call(input, hint || "default");
    if (_typeof(res) !== "object") return res;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (hint === "string" ? String : Number)(input);
}

function _toPropertyKey(arg) {
  var key = _toPrimitive(arg, "string");
  return _typeof(key) === "symbol" ? key : String(key);
}

function _defineProperty(obj, key, value) {
  key = _toPropertyKey(key);
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}

function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var OrderListSubList = /*#__PURE__*/React__namespace.memo(function (props) {
  var ptm = props.ptm,
    cx = props.cx;
  var _ptm = function _ptm(key, options) {
    return ptm(key, _objectSpread({
      hostName: props.hostName
    }, options));
  };
  var getPTOptions = function getPTOptions(item, key) {
    return _ptm(key, {
      context: {
        selected: isSelected(item)
      }
    });
  };
  var dragging = React__namespace.useRef(null);
  var draggedItemIndex = React__namespace.useRef(null);
  var dragOverItemIndex = React__namespace.useRef(null);
  var listElementRef = React__namespace.useRef(null);
  var filterOptions = {
    filter: function filter(e) {
      return props.onFilterInputChange(e);
    },
    reset: function reset() {
      return props.resetFilter();
    }
  };
  var isSelected = function isSelected(item) {
    return utils.ObjectUtils.findIndexInList(item, props.selection, props.dataKey) !== -1;
  };
  var _onDragStart = function onDragStart(event, index) {
    event.dataTransfer.setData('text', 'orderlist');
    dragging.current = true;
    draggedItemIndex.current = index;
  };
  var _onDragOver = function onDragOver(event, index) {
    if (draggedItemIndex.current !== index && draggedItemIndex.current + 1 !== index) {
      dragOverItemIndex.current = index;
      !props.isUnstyled() && utils.DomHandler.addClass(event.target, 'p-orderlist-droppoint-highlight');
      event.target.setAttribute('data-p-orderlist-droppoint-highlight', true);
      event.preventDefault();
    }
  };
  var onDragLeave = function onDragLeave(event) {
    dragOverItemIndex.current = null;
    !props.isUnstyled() && utils.DomHandler.removeClass(event.target, 'p-orderlist-droppoint-highlight');
    event.target.setAttribute('data-p-orderlist-droppoint-highlight', false);
  };
  var onDrop = function onDrop(event) {
    var dropIndex = draggedItemIndex.current > dragOverItemIndex.current ? dragOverItemIndex.current : dragOverItemIndex.current === 0 ? 0 : dragOverItemIndex.current - 1;
    var value = _toConsumableArray(props.value);
    utils.ObjectUtils.reorderArray(value, draggedItemIndex.current, dropIndex);
    dragOverItemIndex.current = null;
    !props.isUnstyled() && utils.DomHandler.removeClass(event.target, 'p-orderlist-droppoint-highlight');
    event.target.setAttribute('data-p-orderlist-droppoint-highlight', false);
    if (props.onChange) {
      props.onChange({
        originalEvent: event,
        value: value
      });
    }
  };
  var onDragEnd = function onDragEnd(event) {
    dragging.current = false;
  };
  var onListMouseMove = function onListMouseMove(event) {
    if (dragging.current) {
      var offsetY = listElementRef.current.getBoundingClientRect().top + utils.DomHandler.getWindowScrollTop();
      var bottomDiff = offsetY + listElementRef.current.clientHeight - event.pageY;
      var topDiff = event.pageY - offsetY;
      if (bottomDiff < 25 && bottomDiff > 0) listElementRef.current.scrollTop += 15;else if (topDiff < 25 && topDiff > 0) listElementRef.current.scrollTop -= 15;
    }
  };
  var onFilterInputKeyDown = function onFilterInputKeyDown(event) {
    //enter
    if (event.which === 13) {
      event.preventDefault();
    }
  };
  var createDropPoint = function createDropPoint(index, key) {
    var droppointProps = utils.mergeProps({
      className: cx('droppoint'),
      onDragOver: function onDragOver(e) {
        return _onDragOver(e, index + 1);
      },
      onDragLeave: onDragLeave,
      onDrop: onDrop
    }, _ptm('droppoint'));
    return /*#__PURE__*/React__namespace.createElement("li", _extends({
      key: key
    }, droppointProps));
  };
  var createHeader = function createHeader() {
    var headerProps = utils.mergeProps({
      className: cx('header')
    }, _ptm('header'));
    return props.header ? /*#__PURE__*/React__namespace.createElement("div", headerProps, props.header) : null;
  };
  var createItems = function createItems() {
    if (props.value) {
      return props.value.map(function (item, i) {
        var content = props.itemTemplate ? props.itemTemplate(item) : item;
        var key = JSON.stringify(item);
        if (props.dragdrop) {
          var itemProps = utils.mergeProps({
            className: utils.classNames(props.className, cx('item', {
              item: item,
              isSelected: isSelected
            })),
            onClick: function onClick(e) {
              return props.onItemClick({
                originalEvent: e,
                value: item,
                index: i
              });
            },
            onKeyDown: function onKeyDown(e) {
              return props.onItemKeyDown({
                originalEvent: e,
                value: item,
                index: i
              });
            },
            role: 'option',
            'aria-selected': isSelected(item),
            draggable: 'true',
            onDragStart: function onDragStart(e) {
              return _onDragStart(e, i);
            },
            onDragEnd: onDragEnd,
            tabIndex: props.tabIndex,
            'data-p-highlight': isSelected(item)
          }, getPTOptions(item, 'item'));
          var items = [];
          if (i === 0) {
            items.push(createDropPoint(item, i));
          }
          items.push( /*#__PURE__*/React__namespace.createElement("li", _extends({
            key: key
          }, itemProps), content));
          items.push(createDropPoint(i, key + '_droppoint'));
          return items;
        } else {
          var _itemProps = utils.mergeProps({
            role: 'option',
            tabIndex: props.tabIndex,
            className: utils.classNames(props.className, cx('item', {
              item: item,
              isSelected: isSelected
            })),
            onClick: function onClick(e) {
              return props.onItemClick({
                originalEvent: e,
                value: item,
                index: i
              });
            },
            onKeyDown: function onKeyDown(e) {
              return props.onItemKeyDown({
                originalEvent: e,
                value: item,
                index: i
              });
            },
            'aria-selected': isSelected(item),
            'data-p-highlight': isSelected(item)
          }, getPTOptions(item, 'item'));
          return /*#__PURE__*/React__namespace.createElement("li", _extends({
            key: key
          }, _itemProps), content, /*#__PURE__*/React__namespace.createElement(ripple.Ripple, null));
        }
      });
    }
    return null;
  };
  var createList = function createList() {
    var items = createItems();
    var listProps = utils.mergeProps({
      ref: listElementRef,
      className: cx('list'),
      style: props.listStyle,
      onDragOver: onListMouseMove,
      role: 'listbox',
      'aria-multiselectable': true
    }, _ptm('list'));
    return /*#__PURE__*/React__namespace.createElement("ul", listProps, items);
  };
  var createFilter = function createFilter() {
    var searchIconProps = utils.mergeProps({
      className: cx('icon')
    }, _ptm('icon'));
    var icon = props.filterIcon || /*#__PURE__*/React__namespace.createElement(search.SearchIcon, searchIconProps);
    var filterIcon = utils.IconUtils.getJSXIcon(icon, _objectSpread({}, searchIconProps), {
      props: props
    });
    if (props.filter) {
      var filterProps = utils.mergeProps({
        className: cx('filter')
      }, _ptm('filter'));
      var filterInputProps = utils.mergeProps({
        type: 'text',
        value: props.filterValue,
        onChange: props.onFilter,
        onKeyDown: onFilterInputKeyDown,
        placeholder: props.placeholder,
        className: cx('filterInput')
      }, _ptm('filterInput'));
      var filterIconProps = utils.mergeProps({
        className: cx('filterIcon')
      }, _ptm('filterIcon'));
      var content = /*#__PURE__*/React__namespace.createElement("div", filterProps, /*#__PURE__*/React__namespace.createElement("input", filterInputProps), /*#__PURE__*/React__namespace.createElement("span", filterIconProps, filterIcon));
      if (props.filterTemplate) {
        var defaultContentOptions = {
          className: 'p-orderlist-filter',
          inputProps: {
            inputClassName: 'p-orderlist-filter-input p-inputtext p-component',
            onChange: props.onFilter,
            onKeyDown: onFilterInputKeyDown
          },
          filterOptions: filterOptions,
          iconClassName: 'p-orderlist-filter-icon',
          element: content,
          props: props
        };
        content = utils.ObjectUtils.getJSXElement(props.filterTemplate, defaultContentOptions);
      }
      var filterContainerProps = utils.mergeProps({
        className: cx('filterContainer')
      }, _ptm('filterContainer'));
      return /*#__PURE__*/React__namespace.createElement("div", filterContainerProps, content);
    }
    return null;
  };
  var header = createHeader();
  var filter = createFilter();
  var list = createList();
  var containerProps = utils.mergeProps({
    className: cx('container')
  }, _ptm('container'));
  return /*#__PURE__*/React__namespace.createElement("div", containerProps, header, filter, list);
});
OrderListSubList.displayName = 'OrderListSubList';

var OrderList = /*#__PURE__*/React__namespace.memo( /*#__PURE__*/React__namespace.forwardRef(function (inProps, ref) {
  var context = React__namespace.useContext(PrimeReact.PrimeReactContext);
  var props = OrderListBase.getProps(inProps, context);
  var _React$useState = React__namespace.useState([]),
    _React$useState2 = _slicedToArray(_React$useState, 2),
    selectionState = _React$useState2[0],
    setSelectionState = _React$useState2[1];
  var _React$useState3 = React__namespace.useState(''),
    _React$useState4 = _slicedToArray(_React$useState3, 2),
    filterValueState = _React$useState4[0],
    setFilterValueState = _React$useState4[1];
  var _React$useState5 = React__namespace.useState(null),
    _React$useState6 = _slicedToArray(_React$useState5, 2),
    attributeSelectorState = _React$useState6[0],
    setAttributeSelectorState = _React$useState6[1];
  var hasFilter = utils.ObjectUtils.isNotEmpty(filterValueState);
  var elementRef = React__namespace.useRef(null);
  var styleElementRef = React__namespace.useRef(null);
  var reorderDirection = React__namespace.useRef(null);
  var metaData = {
    props: props,
    state: {
      selection: selectionState,
      filterValue: filterValueState,
      attributeSelector: attributeSelectorState
    }
  };
  var _OrderListBase$setMet = OrderListBase.setMetaData(metaData),
    ptm = _OrderListBase$setMet.ptm,
    cx = _OrderListBase$setMet.cx,
    isUnstyled = _OrderListBase$setMet.isUnstyled;
  componentbase.useHandleStyle(OrderListBase.css.styles, isUnstyled, {
    name: 'orderlist'
  });
  var onItemClick = function onItemClick(event) {
    var metaKey = event.originalEvent.metaKey || event.originalEvent.ctrlKey;
    var index = utils.ObjectUtils.findIndexInList(event.value, selectionState, props.dataKey);
    var selected = index !== -1;
    var newSelection;
    if (selected) newSelection = metaKey ? selectionState.filter(function (_, i) {
      return i !== index;
    }) : [event.value];else newSelection = metaKey ? [].concat(_toConsumableArray(selectionState), [event.value]) : [event.value];
    setSelectionState(newSelection);
  };
  var onItemKeyDown = function onItemKeyDown(event) {
    var originalEvent = event.originalEvent;
    var listItem = originalEvent.currentTarget;
    switch (originalEvent.which) {
      //down
      case 40:
        var nextItem = findNextItem(listItem);
        nextItem && nextItem.focus();
        originalEvent.preventDefault();
        break;

      //up
      case 38:
        var prevItem = findPrevItem(listItem);
        prevItem && prevItem.focus();
        originalEvent.preventDefault();
        break;

      //enter
      case 13:
        onItemClick(event);
        originalEvent.preventDefault();
        break;
    }
  };
  var onFilter = function onFilter(event) {
    var _filterValue = event.target.value;
    setFilterValueState(_filterValue);
    if (props.onFilter) {
      props.onFilter({
        originalEvent: event,
        value: _filterValue
      });
    }
  };
  var resetFilter = function resetFilter() {
    setFilterValueState('');
    props.onFilter && props.onFilter({
      filter: ''
    });
  };
  var onFilterInputChange = function onFilterInputChange(event) {
    var filter = event.target.value;
    setFilterValueState(filter);
    if (props.onFilter) {
      props.onFilter({
        originalEvent: event,
        filter: filter
      });
    }
  };
  var getVisibleList = function getVisibleList() {
    if (hasFilter) {
      var filterValue = filterValueState.trim().toLocaleLowerCase(props.filterLocale);
      var searchFields = props.filterBy ? props.filterBy.split(',') : [];
      return PrimeReact.FilterService.filter(props.value, searchFields, filterValue, props.filterMatchMode, props.filterLocale);
    }
    return props.value;
  };
  var findNextItem = function findNextItem(item) {
    var nextItem = item.nextElementSibling;
    return nextItem ? !utils.DomHandler.getAttribute(nextItem, 'data-pc-section') === 'item' ? findNextItem(nextItem) : nextItem : null;
  };
  var findPrevItem = function findPrevItem(item) {
    var prevItem = item.previousElementSibling;
    return prevItem ? !utils.DomHandler.getAttribute(prevItem, 'data-pc-section') === 'item' ? findPrevItem(prevItem) : prevItem : null;
  };
  var onReorder = function onReorder(event) {
    if (props.onChange) {
      props.onChange({
        event: event.originalEvent,
        value: event.value
      });
    }
    reorderDirection.current = event.direction;
  };
  var updateListScroll = function updateListScroll() {
    var list = utils.DomHandler.findSingle(elementRef.current, '.p-orderlist-list');
    var listItems = utils.DomHandler.find(list, '.p-orderlist-item.p-highlight');
    if (listItems && listItems.length) {
      switch (reorderDirection.current) {
        case 'up':
          utils.DomHandler.scrollInView(list, listItems[0]);
          break;
        case 'top':
          list.scrollTop = 0;
          break;
        case 'down':
          utils.DomHandler.scrollInView(list, listItems[listItems.length - 1]);
          break;
        case 'bottom':
          /* TODO: improve this code block */
          setTimeout(function () {
            return list.scrollTop = list.scrollHeight;
          }, 100);
          break;
      }
    }
  };
  var createStyle = function createStyle() {
    if (!styleElementRef.current) {
      styleElementRef.current = utils.DomHandler.createInlineStyle(context && context.nonce || PrimeReact__default["default"].nonce);
      var innerHTML = "\n@media screen and (max-width: ".concat(props.breakpoint, ") {\n    .p-orderlist[").concat(attributeSelectorState, "] {\n        flex-direction: column;\n    }\n\n    .p-orderlist[").concat(attributeSelectorState, "] .p-orderlist-controls {\n        padding: var(--content-padding);\n        flex-direction: row;\n    }\n\n    .p-orderlist[").concat(attributeSelectorState, "] .p-orderlist-controls .p-button {\n        margin-right: var(--inline-spacing);\n        margin-bottom: 0;\n    }\n\n    .p-orderlist[").concat(attributeSelectorState, "] .p-orderlist-controls .p-button:last-child {\n        margin-right: 0;\n    }\n}\n");
      styleElementRef.current.innerHTML = innerHTML;
    }
  };
  var destroyStyle = function destroyStyle() {
    styleElementRef.current = utils.DomHandler.removeInlineStyle(styleElementRef.current);
  };
  React__namespace.useImperativeHandle(ref, function () {
    return {
      props: props,
      getElement: function getElement() {
        return elementRef.current;
      }
    };
  });
  hooks.useMountEffect(function () {
    !attributeSelectorState && setAttributeSelectorState(utils.UniqueComponentId());
  });
  hooks.useUpdateEffect(function () {
    if (attributeSelectorState) {
      elementRef.current.setAttribute(attributeSelectorState, '');
      createStyle();
    }
    return function () {
      destroyStyle();
    };
  }, [attributeSelectorState, props.breakpoint]);
  hooks.useUpdateEffect(function () {
    if (reorderDirection.current) {
      updateListScroll();
      reorderDirection.current = null;
    }
  });
  var visibleList = getVisibleList();
  var rootProps = utils.mergeProps({
    ref: elementRef,
    id: props.id,
    className: utils.classNames(props.className, cx('root')),
    style: props.style
  }, OrderListBase.getOtherProps(props), ptm('root'));
  return /*#__PURE__*/React__namespace.createElement("div", rootProps, /*#__PURE__*/React__namespace.createElement(OrderListControls, {
    hostName: "OrderList",
    value: visibleList,
    selection: selectionState,
    onReorder: onReorder,
    dataKey: props.dataKey,
    moveUpIcon: props.moveUpIcon,
    moveTopIcon: props.moveTopIcon,
    moveDownIcon: props.moveDownIcon,
    moveBottomIcon: props.moveBottomIcon,
    ptm: ptm,
    cx: cx,
    unstyled: props.unstyled,
    metaData: metaData
  }), /*#__PURE__*/React__namespace.createElement(OrderListSubList, {
    hostName: "OrderList",
    value: visibleList,
    selection: selectionState,
    onItemClick: onItemClick,
    onItemKeyDown: onItemKeyDown,
    onFilterInputChange: onFilterInputChange,
    itemTemplate: props.itemTemplate,
    filter: props.filter,
    onFilter: onFilter,
    resetFilter: resetFilter,
    filterTemplate: props.filterTemplate,
    header: props.header,
    listStyle: props.listStyle,
    dataKey: props.dataKey,
    dragdrop: props.dragdrop,
    onChange: props.onChange,
    tabIndex: props.tabIndex,
    filterIcon: props.filterIcon,
    isUnstyled: isUnstyled,
    ptm: ptm,
    cx: cx
  }));
}));
OrderList.displayName = 'OrderList';

exports.F = OrderList;


/***/ }),

/***/ 86756:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

var __webpack_unused_export__;
'use client';
'use strict';

__webpack_unused_export__ = ({ value: true });

var React = __webpack_require__(18038);
var PrimeReact = __webpack_require__(90284);
var componentbase = __webpack_require__(87095);
var hooks = __webpack_require__(85215);
var utils = __webpack_require__(7666);
var button = __webpack_require__(18176);
var angledoubledown = __webpack_require__(44742);
var angledoubleup = __webpack_require__(1322);
var angledown = __webpack_require__(77933);
var angleup = __webpack_require__(52232);
var search = __webpack_require__(85583);
var ripple = __webpack_require__(26412);
var angledoubleleft = __webpack_require__(37154);
var angledoubleright = __webpack_require__(95537);
var angleleft = __webpack_require__(10187);
var angleright = __webpack_require__(74524);

function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

function _interopNamespace(e) {
  if (e && e.__esModule) return e;
  var n = Object.create(null);
  if (e) {
    Object.keys(e).forEach(function (k) {
      if (k !== 'default') {
        var d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: function () { return e[k]; }
        });
      }
    });
  }
  n["default"] = e;
  return Object.freeze(n);
}

var React__namespace = /*#__PURE__*/_interopNamespace(React);
var PrimeReact__default = /*#__PURE__*/_interopDefaultLegacy(PrimeReact);

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

function _iterableToArrayLimit(r, l) {
  var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
  if (null != t) {
    var e,
      n,
      i,
      u,
      a = [],
      f = !0,
      o = !1;
    try {
      if (i = (t = t.call(r)).next, 0 === l) {
        if (Object(t) !== t) return;
        f = !1;
      } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
    } catch (r) {
      o = !0, n = r;
    } finally {
      try {
        if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
      } finally {
        if (o) throw n;
      }
    }
    return a;
  }
}

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;
  for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
  return arr2;
}

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _slicedToArray(arr, i) {
  return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}

var classes = {
  root: 'p-picklist p-component',
  buttons: 'p-picklist-buttons p-picklist-transfer-buttons',
  header: 'p-picklist-header',
  filterIcon: 'p-picklist-filter-icon',
  filter: 'p-picklist-filter',
  filterInput: 'p-picklist-filter-input p-inputtext p-component',
  filterContainer: 'p-picklist-filter-container',
  list: 'p-picklist-list',
  listWrapper: 'p-picklist-list-wrapper',
  listSourceWrapper: 'p-picklist-source-wrapper',
  listTargetWrapper: 'p-picklist-target-wrapper',
  listSource: 'p-picklist-source',
  listTarget: 'p-picklist-target',
  item: function item(_ref) {
    var subProps = _ref.subProps;
    return utils.classNames('p-picklist-item', {
      'p-highlight': subProps.selected
    });
  },
  sourceControls: 'p-picklist-source-controls p-picklist-buttons',
  targetControls: 'p-picklist-target-controls p-picklist-buttons'
};
var styles = "\n@layer primereact {\n    .p-picklist {\n        display: flex;\n    }\n    \n    .p-picklist-buttons {\n        display: flex;\n        flex-direction: column;\n        justify-content: center;\n    }\n    \n    .p-picklist-list-wrapper {\n        flex: 1 1 50%;\n    }\n    \n    .p-picklist-list {\n        list-style-type: none;\n        margin: 0;\n        padding: 0;\n        overflow: auto;\n        min-height: 12rem;\n        max-height: 24rem;\n    }\n    \n    .p-picklist-item {\n        cursor: pointer;\n        overflow: hidden;\n        position: relative;\n    }\n    \n    .p-picklist-filter {\n        position: relative;\n    }\n    \n    .p-picklist-filter-icon {\n        position: absolute;\n        top: 50%;\n        margin-top: -.5rem;\n    }\n    \n    .p-picklist-filter-input {\n        width: 100%;\n    }\n}\n";
var PickListBase = componentbase.ComponentBase.extend({
  defaultProps: {
    __TYPE: 'PickList',
    id: null,
    source: null,
    target: null,
    sourceHeader: null,
    targetHeader: null,
    style: null,
    className: null,
    sourceStyle: null,
    targetStyle: null,
    sourceSelection: null,
    targetSelection: null,
    showSourceControls: true,
    showTargetControls: true,
    metaKeySelection: true,
    filter: false,
    filterBy: null,
    filterMatchMode: 'contains',
    targetFilterIcon: null,
    sourceFilterIcon: null,
    moveAllToSourceIcon: null,
    moveToSourceIcon: null,
    moveAllToTargetIcon: null,
    moveToTargetIcon: null,
    moveBottomIcon: null,
    moveUpIcon: null,
    moveTopIcon: null,
    moveDownIcon: null,
    filterLocale: undefined,
    sourceFilterValue: null,
    targetFilterValue: null,
    showSourceFilter: true,
    showTargetFilter: true,
    sourceFilterPlaceholder: null,
    targetFilterPlaceholder: null,
    sourceFilterTemplate: null,
    targetFilterTemplate: null,
    tabIndex: 0,
    dataKey: null,
    breakpoint: '960px',
    itemTemplate: null,
    sourceItemTemplate: null,
    targetItemTemplate: null,
    onChange: null,
    onMoveToSource: null,
    onMoveAllToSource: null,
    onMoveToTarget: null,
    onMoveAllToTarget: null,
    onSourceSelectionChange: null,
    onTargetSelectionChange: null,
    onSourceFilterChange: null,
    onTargetFilterChange: null,
    children: undefined
  },
  css: {
    classes: classes,
    styles: styles
  }
});

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function _toConsumableArray(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}

var PickListControls = /*#__PURE__*/React__namespace.memo(function (props) {
  var ptm = props.ptm,
    cx = props.cx,
    unstyled = props.unstyled;
  var moveUpIcon = props.moveUpIcon || /*#__PURE__*/React__namespace.createElement(angleup.AngleUpIcon, null);
  var moveTopIcon = props.moveTopIcon || /*#__PURE__*/React__namespace.createElement(angledoubleup.AngleDoubleUpIcon, null);
  var moveDownIcon = props.moveDownIcon || /*#__PURE__*/React__namespace.createElement(angledown.AngleDownIcon, null);
  var moveBottomIcon = props.moveBottomIcon || /*#__PURE__*/React__namespace.createElement(angledoubledown.AngleDoubleDownIcon, null);
  var moveDisabled = !props.selection || !props.selection.length;
  var moveUp = function moveUp(event) {
    var selectedItems = props.selection;
    if (selectedItems && selectedItems.length) {
      var list = _toConsumableArray(props.list);
      for (var i = 0; i < selectedItems.length; i++) {
        var selectedItem = selectedItems[i];
        var selectedItemIndex = utils.ObjectUtils.findIndexInList(selectedItem, list, props.dataKey);
        if (selectedItemIndex !== 0) {
          var movedItem = list[selectedItemIndex];
          var temp = list[selectedItemIndex - 1];
          list[selectedItemIndex - 1] = movedItem;
          list[selectedItemIndex] = temp;
        } else {
          break;
        }
      }
      if (props.onReorder) {
        props.onReorder({
          originalEvent: event,
          value: list,
          direction: 'up'
        });
      }
    }
  };
  var moveTop = function moveTop(event) {
    var selectedItems = props.selection;
    if (selectedItems && selectedItems.length) {
      var list = _toConsumableArray(props.list);
      for (var i = 0; i < selectedItems.length; i++) {
        var selectedItem = selectedItems[i];
        var selectedItemIndex = utils.ObjectUtils.findIndexInList(selectedItem, list, props.dataKey);
        if (selectedItemIndex !== 0) {
          var movedItem = list.splice(selectedItemIndex, 1)[0];
          list.unshift(movedItem);
        } else {
          break;
        }
      }
      if (props.onReorder) {
        props.onReorder({
          originalEvent: event,
          value: list,
          direction: 'top'
        });
      }
    }
  };
  var moveDown = function moveDown(event) {
    var selectedItems = props.selection;
    if (selectedItems && selectedItems.length) {
      var list = _toConsumableArray(props.list);
      for (var i = selectedItems.length - 1; i >= 0; i--) {
        var selectedItem = selectedItems[i];
        var selectedItemIndex = utils.ObjectUtils.findIndexInList(selectedItem, list, props.dataKey);
        if (selectedItemIndex !== list.length - 1) {
          var movedItem = list[selectedItemIndex];
          var temp = list[selectedItemIndex + 1];
          list[selectedItemIndex + 1] = movedItem;
          list[selectedItemIndex] = temp;
        } else {
          break;
        }
      }
      if (props.onReorder) {
        props.onReorder({
          originalEvent: event,
          value: list,
          direction: 'down'
        });
      }
    }
  };
  var moveBottom = function moveBottom(event) {
    var selectedItems = props.selection;
    if (selectedItems && selectedItems.length) {
      var list = _toConsumableArray(props.list);
      for (var i = selectedItems.length - 1; i >= 0; i--) {
        var selectedItem = selectedItems[i];
        var selectedItemIndex = utils.ObjectUtils.findIndexInList(selectedItem, list, props.dataKey);
        if (selectedItemIndex !== list.length - 1) {
          var movedItem = list.splice(selectedItemIndex, 1)[0];
          list.push(movedItem);
        } else {
          break;
        }
      }
      if (props.onReorder) {
        props.onReorder({
          originalEvent: event,
          value: list,
          direction: 'bottom'
        });
      }
    }
  };
  var controlsProps = utils.mergeProps({
    className: utils.classNames(props.className, cx('controls'))
  }, ptm('controls', {
    hostName: props.hostName
  }));
  return /*#__PURE__*/React__namespace.createElement("div", controlsProps, /*#__PURE__*/React__namespace.createElement(button.Button, {
    disabled: moveDisabled,
    type: "button",
    icon: moveUpIcon,
    onClick: moveUp,
    pt: ptm('moveUpButton'),
    unstyled: unstyled,
    __parentMetadata: {
      parent: props.metaData
    }
  }), /*#__PURE__*/React__namespace.createElement(button.Button, {
    disabled: moveDisabled,
    type: "button",
    icon: moveTopIcon,
    onClick: moveTop,
    pt: ptm('moveTopButton'),
    unstyled: unstyled,
    __parentMetadata: {
      parent: props.metaData
    }
  }), /*#__PURE__*/React__namespace.createElement(button.Button, {
    disabled: moveDisabled,
    type: "button",
    icon: moveDownIcon,
    onClick: moveDown,
    pt: ptm('moveDownButton'),
    unstyled: unstyled,
    __parentMetadata: {
      parent: props.metaData
    }
  }), /*#__PURE__*/React__namespace.createElement(button.Button, {
    disabled: moveDisabled,
    type: "button",
    icon: moveBottomIcon,
    onClick: moveBottom,
    pt: ptm('moveBottomButton'),
    unstyled: unstyled,
    __parentMetadata: {
      parent: props.metaData
    }
  }));
});
PickListControls.displayName = 'PickListControls';

function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}

function _toPrimitive(input, hint) {
  if (_typeof(input) !== "object" || input === null) return input;
  var prim = input[Symbol.toPrimitive];
  if (prim !== undefined) {
    var res = prim.call(input, hint || "default");
    if (_typeof(res) !== "object") return res;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (hint === "string" ? String : Number)(input);
}

function _toPropertyKey(arg) {
  var key = _toPrimitive(arg, "string");
  return _typeof(key) === "symbol" ? key : String(key);
}

function _defineProperty(obj, key, value) {
  key = _toPropertyKey(key);
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}

var PickListItem = /*#__PURE__*/React__namespace.memo(function (props) {
  var ptm = props.ptm,
    cx = props.cx;
  var getPTOptions = function getPTOptions(key) {
    return ptm(key, {
      hostName: props.hostName,
      context: {
        selected: props.selected
      }
    });
  };
  var onClick = function onClick(event) {
    if (props.onClick) {
      props.onClick({
        originalEvent: event,
        value: props.value
      });
    }
  };
  var onKeyDown = function onKeyDown(event) {
    if (props.onKeyDown) {
      props.onKeyDown({
        originalEvent: event,
        value: props.value
      });
    }
  };
  var content = props.template ? props.template(props.value) : props.value;
  var itemProps = utils.mergeProps({
    className: utils.classNames(props.className, cx('item', {
      subProps: props
    })),
    onClick: onClick,
    onKeyDown: onKeyDown,
    tabIndex: props.tabIndex,
    role: 'option',
    'aria-selected': props.selected
  }, getPTOptions('item'));
  return /*#__PURE__*/React__namespace.createElement("li", itemProps, content, /*#__PURE__*/React__namespace.createElement(ripple.Ripple, null));
});
PickListItem.displayName = 'PickListItem';

function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
var PickListSubList = /*#__PURE__*/React__namespace.memo( /*#__PURE__*/React__namespace.forwardRef(function (props, ref) {
  var listElementRef = React__namespace.useRef(null);
  var ptm = props.ptm,
    cx = props.cx;
  var getPTOptions = function getPTOptions(key, options) {
    return ptm(key, _objectSpread({
      hostName: props.hostName
    }, options));
  };
  var onItemClick = function onItemClick(event) {
    var originalEvent = event.originalEvent;
    var item = event.value;
    var selection = _toConsumableArray(props.selection);
    var index = utils.ObjectUtils.findIndexInList(item, selection, props.dataKey);
    var selected = index !== -1;
    var metaSelection = props.metaKeySelection;
    if (metaSelection) {
      var metaKey = originalEvent.metaKey || originalEvent.ctrlKey;
      if (selected && metaKey) {
        selection.splice(index, 1);
      } else {
        if (!metaKey) {
          selection.length = 0;
        }
        selection.push(item);
      }
    } else {
      if (selected) selection.splice(index, 1);else selection.push(item);
    }
    if (props.onSelectionChange) {
      props.onSelectionChange({
        event: originalEvent,
        value: selection
      });
    }
  };
  var onItemKeyDown = function onItemKeyDown(event) {
    var originalEvent = event.originalEvent;
    var listItem = originalEvent.currentTarget;
    switch (originalEvent.which) {
      //down
      case 40:
        var nextItem = findNextItem(listItem);
        nextItem && nextItem.focus();
        originalEvent.preventDefault();
        break;

      //up
      case 38:
        var prevItem = findPrevItem(listItem);
        prevItem && prevItem.focus();
        originalEvent.preventDefault();
        break;

      //enter
      case 13:
        onItemClick(event);
        originalEvent.preventDefault();
        break;
    }
  };
  var findNextItem = function findNextItem(item) {
    var nextItem = item.nextElementSibling;
    return nextItem ? !utils.DomHandler.hasClass(nextItem, 'p-picklist-item') ? findNextItem(nextItem) : nextItem : null;
  };
  var findPrevItem = function findPrevItem(item) {
    var prevItem = item.previousElementSibling;
    return prevItem ? !utils.DomHandler.hasClass(prevItem, 'p-picklist-item') ? findPrevItem(prevItem) : prevItem : null;
  };
  var isSelected = function isSelected(item) {
    return utils.ObjectUtils.findIndexInList(item, props.selection, props.dataKey) !== -1;
  };
  var onFilter = function onFilter(event) {
    if (props.onFilter) {
      props.onFilter({
        originalEvent: event,
        value: event.target.value,
        type: props.type
      });
    }
  };
  var onFilterInputKeyDown = function onFilterInputKeyDown(event) {
    //enter
    if (event.which === 13) {
      event.preventDefault();
    }
  };
  React__namespace.useImperativeHandle(ref, function () {
    return {
      listElementRef: listElementRef
    };
  });
  var createHeader = function createHeader() {
    var headerProps = utils.mergeProps({
      className: cx('header')
    }, getPTOptions('header'));
    if (props.header) {
      return /*#__PURE__*/React__namespace.createElement("div", headerProps, utils.ObjectUtils.getJSXElement(props.header, props));
    }
    return null;
  };
  var createItems = function createItems() {
    if (props.list) {
      return props.list.map(function (item) {
        var key = JSON.stringify(item);
        var selected = isSelected(item);
        return /*#__PURE__*/React__namespace.createElement(PickListItem, {
          hostName: props.hostName,
          key: key,
          value: item,
          template: props.itemTemplate,
          selected: selected,
          onClick: onItemClick,
          onKeyDown: onItemKeyDown,
          tabIndex: props.tabIndex,
          ptm: ptm,
          cx: cx
        });
      });
    }
    return null;
  };
  var createFilter = function createFilter() {
    var iconClassName = 'p-picklist-filter-icon';
    var filterIconProps = utils.mergeProps({
      className: cx('filterIcon')
    }, getPTOptions('filterIcon'));
    var icon = props.type === 'source' ? props.sourceFilterIcon || /*#__PURE__*/React__namespace.createElement(search.SearchIcon, filterIconProps) : props.targetFilterIcon || /*#__PURE__*/React__namespace.createElement(search.SearchIcon, filterIconProps);
    var filterIcon = utils.IconUtils.getJSXIcon(icon, _objectSpread({}, filterIconProps), {
      props: props
    });
    if (props.showFilter) {
      var filterProps = utils.mergeProps({
        className: cx('filter')
      }, getPTOptions('filter'));
      var filterInputProps = utils.mergeProps({
        type: 'text',
        value: props.filterValue,
        onChange: onFilter,
        onKeyDown: onFilterInputKeyDown,
        placeholder: props.placeholder,
        className: cx('filterInput')
      }, getPTOptions('filterInput'));
      var content = /*#__PURE__*/React__namespace.createElement("div", filterProps, /*#__PURE__*/React__namespace.createElement("input", filterInputProps), /*#__PURE__*/React__namespace.createElement("span", null, " ", filterIcon, " "));
      if (props.filterTemplate) {
        var defaultContentOptions = {
          className: 'p-picklist-filter',
          inputProps: {
            className: 'p-picklist-filter-input p-inputtext p-component',
            onChange: onFilter,
            onKeyDown: onFilterInputKeyDown
          },
          iconClassName: iconClassName,
          element: content,
          props: props
        };
        content = utils.ObjectUtils.getJSXElement(props.filterTemplate, defaultContentOptions);
      }
      var filterContainerProps = utils.mergeProps({
        className: cx('filterContainer')
      }, getPTOptions('filterContainer'));
      return /*#__PURE__*/React__namespace.createElement("div", filterContainerProps, content);
    }
    return null;
  };
  var createList = function createList() {
    var items = createItems();
    var listProps = utils.mergeProps({
      className: utils.classNames(props.listClassName, cx('list')),
      role: 'listbox',
      'aria-multiselectable': true,
      style: props.style
    }, getPTOptions('list'));
    return /*#__PURE__*/React__namespace.createElement("ul", listProps, items);
  };
  var header = createHeader();
  var filter = createFilter();
  var list = createList();
  var listWrapperProps = utils.mergeProps({
    className: utils.classNames(props.className, cx('listWrapper')),
    ref: listElementRef
  }, getPTOptions('listWrapper'));
  return /*#__PURE__*/React__namespace.createElement("div", listWrapperProps, header, filter, list);
}));
PickListSubList.displayName = 'PickListSubList';

var PickListTransferControls = /*#__PURE__*/React__namespace.memo(function (props) {
  var viewChanged = hooks.useMatchMedia("(max-width: ".concat(props.breakpoint, ")"), props.breakpoint);
  var ptm = props.ptm,
    cx = props.cx,
    unstyled = props.unstyled;
  function getIconComponent(iconType) {
    switch (iconType) {
      case 'moveToTargetIcon':
        return props.moveToTargetIcon || viewChanged ? props.moveToTargetIcon || /*#__PURE__*/React__namespace.createElement(angledown.AngleDownIcon, null) : props.moveToTargetIcon || /*#__PURE__*/React__namespace.createElement(angleright.AngleRightIcon, null);
      case 'moveAllToTargetIcon':
        return props.moveAllToTargetIcon || viewChanged ? props.moveAllToTargetIcon || /*#__PURE__*/React__namespace.createElement(angledoubledown.AngleDoubleDownIcon, null) : props.moveAllToTargetIcon || /*#__PURE__*/React__namespace.createElement(angledoubleright.AngleDoubleRightIcon, null);
      case 'moveToSourceIcon':
        return props.moveToSourceIcon || viewChanged ? props.moveToSourceIcon || /*#__PURE__*/React__namespace.createElement(angleup.AngleUpIcon, null) : props.moveToSourceIcon || /*#__PURE__*/React__namespace.createElement(angleleft.AngleLeftIcon, null);
      case 'moveAllToSourceIcon':
        return props.moveAllToSourceIcon || viewChanged ? props.moveAllToSourceIcon || /*#__PURE__*/React__namespace.createElement(angledoubleup.AngleDoubleUpIcon, null) : props.moveAllToSourceIcon || /*#__PURE__*/React__namespace.createElement(angledoubleleft.AngleDoubleLeftIcon, null);
      default:
        return null;
    }
  }
  var moveToTargetIcon = utils.IconUtils.getJSXIcon(getIconComponent('moveToTargetIcon'), undefined, {
    props: props,
    viewChanged: viewChanged
  });
  var moveAllToTargetIcon = utils.IconUtils.getJSXIcon(getIconComponent('moveAllToTargetIcon'), undefined, {
    props: props,
    viewChanged: viewChanged
  });
  var moveToSourceIcon = utils.IconUtils.getJSXIcon(getIconComponent('moveToSourceIcon'), undefined, {
    props: props,
    viewChanged: viewChanged
  });
  var moveAllToSourceIcon = utils.IconUtils.getJSXIcon(getIconComponent('moveAllToSourceIcon'), undefined, {
    props: props,
    viewChanged: viewChanged
  });
  var moveRightDisabled = utils.ObjectUtils.isEmpty(props.sourceSelection) || utils.ObjectUtils.isEmpty(props.visibleSourceList);
  var moveLeftDisabled = utils.ObjectUtils.isEmpty(props.targetSelection) || utils.ObjectUtils.isEmpty(props.visibleTargetList);
  var moveAllRightDisabled = utils.ObjectUtils.isEmpty(props.visibleSourceList);
  var moveAllLeftDisabled = utils.ObjectUtils.isEmpty(props.visibleTargetList);
  var moveRight = function moveRight(event) {
    var selection = props.sourceSelection;
    if (utils.ObjectUtils.isNotEmpty(selection)) {
      var targetList = _toConsumableArray(props.target);
      var sourceList = _toConsumableArray(props.source);
      for (var i = 0; i < selection.length; i++) {
        var selectedItem = selection[i];
        if (utils.ObjectUtils.findIndexInList(selectedItem, targetList, props.dataKey) === -1) {
          targetList.push(sourceList.splice(utils.ObjectUtils.findIndexInList(selectedItem, sourceList, props.dataKey), 1)[0]);
        }
      }
      if (props.onTransfer) {
        props.onTransfer({
          originalEvent: event,
          source: sourceList,
          target: targetList,
          direction: 'toTarget'
        });
      }
    }
  };
  var moveAllRight = function moveAllRight(event) {
    if (props.source) {
      var targetList = [].concat(_toConsumableArray(props.target), _toConsumableArray(props.visibleSourceList));
      var sourceList = props.source.filter(function (s) {
        return !props.visibleSourceList.some(function (vs) {
          return vs === s;
        });
      });
      if (props.onTransfer) {
        props.onTransfer({
          originalEvent: event,
          source: sourceList,
          target: targetList,
          direction: 'allToTarget'
        });
      }
    }
  };
  var moveLeft = function moveLeft(event) {
    var selection = props.targetSelection;
    if (utils.ObjectUtils.isNotEmpty(selection)) {
      var targetList = _toConsumableArray(props.target);
      var sourceList = _toConsumableArray(props.source);
      for (var i = 0; i < selection.length; i++) {
        var selectedItem = selection[i];
        if (utils.ObjectUtils.findIndexInList(selectedItem, sourceList, props.dataKey) === -1) {
          sourceList.push(targetList.splice(utils.ObjectUtils.findIndexInList(selectedItem, targetList, props.dataKey), 1)[0]);
        }
      }
      if (props.onTransfer) {
        props.onTransfer({
          originalEvent: event,
          source: sourceList,
          target: targetList,
          direction: 'toSource'
        });
      }
    }
  };
  var moveAllLeft = function moveAllLeft(event) {
    if (props.source) {
      var sourceList = [].concat(_toConsumableArray(props.source), _toConsumableArray(props.visibleTargetList));
      var targetList = props.target.filter(function (t) {
        return !props.visibleTargetList.some(function (vt) {
          return vt === t;
        });
      });
      if (props.onTransfer) {
        props.onTransfer({
          originalEvent: event,
          source: sourceList,
          target: targetList,
          direction: 'allToSource'
        });
      }
    }
  };
  var buttonsProps = utils.mergeProps({
    className: utils.classNames(props.className, cx('buttons'))
  }, ptm('buttons', {
    hostName: props.hostName
  }));
  return /*#__PURE__*/React__namespace.createElement("div", buttonsProps, /*#__PURE__*/React__namespace.createElement(button.Button, {
    disabled: moveRightDisabled,
    type: "button",
    icon: moveToTargetIcon,
    onClick: moveRight,
    pt: ptm('moveToTargetButton'),
    unstyled: unstyled,
    __parentMetadata: {
      parent: props.metaData
    }
  }), /*#__PURE__*/React__namespace.createElement(button.Button, {
    disabled: moveAllRightDisabled,
    type: "button",
    icon: moveAllToTargetIcon,
    onClick: moveAllRight,
    pt: ptm('moveAllToTargetButton'),
    unstyled: unstyled,
    __parentMetadata: {
      parent: props.metaData
    }
  }), /*#__PURE__*/React__namespace.createElement(button.Button, {
    disabled: moveLeftDisabled,
    type: "button",
    icon: moveToSourceIcon,
    onClick: moveLeft,
    pt: ptm('moveToSourceButton'),
    unstyled: unstyled,
    __parentMetadata: {
      parent: props.metaData
    }
  }), /*#__PURE__*/React__namespace.createElement(button.Button, {
    disabled: moveAllLeftDisabled,
    type: "button",
    icon: moveAllToSourceIcon,
    onClick: moveAllLeft,
    pt: ptm('moveAllToSourceButton'),
    unstyled: unstyled,
    __parentMetadata: {
      parent: props.metaData
    }
  }));
});
PickListTransferControls.displayName = 'PickListTransferControls';

var PickList = /*#__PURE__*/React__namespace.memo( /*#__PURE__*/React__namespace.forwardRef(function (inProps, ref) {
  var context = React__namespace.useContext(PrimeReact.PrimeReactContext);
  var props = PickListBase.getProps(inProps, context);
  var _React$useState = React__namespace.useState([]),
    _React$useState2 = _slicedToArray(_React$useState, 2),
    sourceSelectionState = _React$useState2[0],
    setSourceSelectionState = _React$useState2[1];
  var _React$useState3 = React__namespace.useState([]),
    _React$useState4 = _slicedToArray(_React$useState3, 2),
    targetSelectionState = _React$useState4[0],
    setTargetSelectionState = _React$useState4[1];
  var _React$useState5 = React__namespace.useState(''),
    _React$useState6 = _slicedToArray(_React$useState5, 2),
    sourceFilterValueState = _React$useState6[0],
    setSourceFilterValueState = _React$useState6[1];
  var _React$useState7 = React__namespace.useState(''),
    _React$useState8 = _slicedToArray(_React$useState7, 2),
    targetFilterValueState = _React$useState8[0],
    setTargetFilterValueState = _React$useState8[1];
  var _React$useState9 = React__namespace.useState(null),
    _React$useState10 = _slicedToArray(_React$useState9, 2),
    attributeSelectorState = _React$useState10[0],
    setAttributeSelectorState = _React$useState10[1];
  var metaData = {
    props: props,
    state: {
      sourceSelection: sourceSelectionState,
      targetSelection: targetSelectionState,
      sourceFilterValue: sourceFilterValueState,
      targetFilterValue: targetFilterValueState,
      attributeSelector: attributeSelectorState
    }
  };
  var _PickListBase$setMeta = PickListBase.setMetaData(metaData),
    ptm = _PickListBase$setMeta.ptm,
    cx = _PickListBase$setMeta.cx,
    isUnstyled = _PickListBase$setMeta.isUnstyled;
  componentbase.useHandleStyle(PickListBase.css.styles, isUnstyled, {
    name: 'picklist'
  });
  var elementRef = React__namespace.useRef(null);
  var sourceListElementRef = React__namespace.useRef(null);
  var targetListElementRef = React__namespace.useRef(null);
  var reorderedListElementRef = React__namespace.useRef(null);
  var reorderDirection = React__namespace.useRef(null);
  var styleElementRef = React__namespace.useRef(null);
  var sourceSelection = props.sourceSelection ? props.sourceSelection : sourceSelectionState;
  var targetSelection = props.targetSelection ? props.targetSelection : targetSelectionState;
  var sourceFilteredValue = props.onSourceFilterChange ? props.sourceFilterValue : sourceFilterValueState;
  var targetFilteredValue = props.onTargetFilterChange ? props.targetFilterValue : targetFilterValueState;
  var hasFilterBy = utils.ObjectUtils.isNotEmpty(props.filterBy);
  var showSourceFilter = hasFilterBy && props.showSourceFilter;
  var showTargetFilter = hasFilterBy && props.showTargetFilter;
  var onSourceReorder = function onSourceReorder(event) {
    handleChange(event, event.value, props.target);
    reorderedListElementRef.current = sourceListElementRef.current.listElementRef.current;
    reorderDirection.current = event.direction;
  };
  var onTargetReorder = function onTargetReorder(event) {
    handleChange(event, props.source, event.value);
    reorderedListElementRef.current = targetListElementRef.current.listElementRef.current;
    reorderDirection.current = event.direction;
  };
  var handleScrollPosition = function handleScrollPosition(listElement, direction) {
    if (listElement) {
      var list = utils.DomHandler.findSingle(listElement, '[data-pc-section="list"]');
      switch (direction) {
        case 'up':
          scrollInView(list, -1);
          break;
        case 'top':
          list.scrollTop = 0;
          break;
        case 'down':
          scrollInView(list, 1);
          break;
        case 'bottom':
          /* TODO: improve this code block */
          setTimeout(function () {
            return list.scrollTop = list.scrollHeight;
          }, 100);
          break;
      }
    }
  };
  var handleChange = function handleChange(event, source, target) {
    if (props.onChange) {
      props.onChange({
        originalEvent: event.originalEvent,
        source: source,
        target: target
      });
    }
  };
  var onTransfer = function onTransfer(event) {
    var originalEvent = event.originalEvent,
      source = event.source,
      target = event.target,
      direction = event.direction;
    var selectedValue = [];
    switch (direction) {
      case 'toTarget':
        selectedValue = sourceSelection;
        if (props.onMoveToTarget) {
          props.onMoveToTarget({
            originalEvent: originalEvent,
            value: selectedValue
          });
        }
        break;
      case 'allToTarget':
        selectedValue = props.source;
        if (props.onMoveAllToTarget) {
          props.onMoveAllToTarget({
            originalEvent: originalEvent,
            value: selectedValue
          });
        }
        selectedValue = [];
        break;
      case 'toSource':
        selectedValue = targetSelection;
        if (props.onMoveToSource) {
          props.onMoveToSource({
            originalEvent: originalEvent,
            value: selectedValue
          });
        }
        break;
      case 'allToSource':
        selectedValue = props.target;
        if (props.onMoveAllToSource) {
          props.onMoveAllToSource({
            originalEvent: originalEvent,
            value: selectedValue
          });
        }
        selectedValue = [];
        break;
    }
    _onSelectionChange({
      originalEvent: originalEvent,
      value: selectedValue
    }, 'sourceSelection', props.onSourceSelectionChange);
    _onSelectionChange({
      originalEvent: originalEvent,
      value: selectedValue
    }, 'targetSelection', props.onTargetSelectionChange);
    handleChange(event, source, target);
  };
  var scrollInView = function scrollInView(listContainer) {
    var direction = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;
    var selectedItems = listContainer.getElementsByClassName('p-highlight');
    if (utils.ObjectUtils.isNotEmpty(selectedItems)) {
      utils.DomHandler.scrollInView(listContainer, direction === -1 ? selectedItems[0] : selectedItems[selectedItems.length - 1]);
    }
  };
  var _onSelectionChange = function onSelectionChange(e, stateKey, callback) {
    if (stateKey === 'sourceSelection') setSourceSelectionState(e.value);else setTargetSelectionState(e.value);
    if (callback) {
      callback(e);
    }
    if (utils.ObjectUtils.isNotEmpty(sourceSelection) && stateKey === 'targetSelection') {
      setSourceSelectionState([]);
    } else if (utils.ObjectUtils.isNotEmpty(targetSelection) && stateKey === 'sourceSelection') {
      setTargetSelectionState([]);
    }
  };
  var onFilter = function onFilter(event) {
    var originalEvent = event.originalEvent,
      value = event.value,
      type = event.type;
    var _ref = type === 'source' ? [setSourceFilterValueState, props.onSourceFilterChange] : [setTargetFilterValueState, props.onTargetFilterChange],
      _ref2 = _slicedToArray(_ref, 2),
      setFilterState = _ref2[0],
      onFilterChange = _ref2[1];
    if (onFilterChange) {
      onFilterChange({
        originalEvent: originalEvent,
        value: value
      });
    } else {
      setFilterState(value);
    }
  };
  var getVisibleList = function getVisibleList(list, type) {
    var _ref3 = type === 'source' ? [sourceFilteredValue, filterSource] : [targetFilteredValue, filterTarget],
      _ref4 = _slicedToArray(_ref3, 2),
      filteredValue = _ref4[0],
      filterCallback = _ref4[1];
    return hasFilterBy && utils.ObjectUtils.isNotEmpty(filteredValue) ? filterCallback(filteredValue) : list;
  };
  var filterSource = function filterSource() {
    var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    var filteredValue = value.trim().toLocaleLowerCase(props.filterLocale);
    return filter(props.source, filteredValue);
  };
  var filterTarget = function filterTarget() {
    var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
    var filteredValue = value.trim().toLocaleLowerCase(props.filterLocale);
    return filter(props.target, filteredValue);
  };
  var filter = function filter(list, filterValue) {
    var searchFields = hasFilterBy ? props.filterBy.split(',') : [];
    return PrimeReact.FilterService.filter(list, searchFields, filterValue, props.filterMatchMode, props.filterLocale);
  };
  var createStyle = function createStyle() {
    if (!styleElementRef.current) {
      styleElementRef.current = utils.DomHandler.createInlineStyle(context && context.nonce || PrimeReact__default["default"].nonce);
      var innerHTML = "\n@media screen and (max-width: ".concat(props.breakpoint, ") {\n    .p-picklist[").concat(attributeSelectorState, "] {\n        flex-direction: column;\n    }\n\n    .p-picklist[").concat(attributeSelectorState, "] .p-picklist-buttons {\n        padding: var(--content-padding);\n        flex-direction: row;\n    }\n\n    .p-picklist[").concat(attributeSelectorState, "] .p-picklist-buttons .p-button {\n        margin-right: var(--inline-spacing);\n        margin-bottom: 0;\n    }\n\n    .p-picklist[").concat(attributeSelectorState, "] .p-picklist-buttons .p-button:last-child {\n        margin-right: 0;\n    }\n}\n");
      styleElementRef.current.innerHTML = innerHTML;
    }
  };
  var destroyStyle = function destroyStyle() {
    styleElementRef.current = utils.DomHandler.removeInlineStyle(styleElementRef.current);
  };
  React__namespace.useImperativeHandle(ref, function () {
    return {
      props: props,
      getElement: function getElement() {
        return elementRef.current;
      }
    };
  });
  hooks.useMountEffect(function () {
    !attributeSelectorState && setAttributeSelectorState(utils.UniqueComponentId());
  });
  hooks.useUpdateEffect(function () {
    if (attributeSelectorState) {
      elementRef.current.setAttribute(attributeSelectorState, '');
      createStyle();
    }
    return function () {
      destroyStyle();
    };
  }, [attributeSelectorState, props.breakpoint]);
  hooks.useUpdateEffect(function () {
    if (reorderedListElementRef.current) {
      handleScrollPosition(reorderedListElementRef.current, reorderDirection.current);
      reorderedListElementRef.current = null;
      reorderDirection.current = null;
    }
  });
  var sourceItemTemplate = props.sourceItemTemplate ? props.sourceItemTemplate : props.itemTemplate;
  var targetItemTemplate = props.targetItemTemplate ? props.targetItemTemplate : props.itemTemplate;
  var sourceList = getVisibleList(props.source, 'source');
  var targetList = getVisibleList(props.target, 'target');
  var rootProps = utils.mergeProps({
    id: props.id,
    ref: elementRef,
    className: utils.classNames(props.className, cx('root')),
    style: props.style
  }, PickListBase.getOtherProps(props), ptm('root'));
  return /*#__PURE__*/React__namespace.createElement("div", rootProps, props.showSourceControls && /*#__PURE__*/React__namespace.createElement(PickListControls, {
    hostName: "PickList",
    list: props.source,
    selection: sourceSelection,
    onReorder: onSourceReorder,
    className: cx('sourceControls'),
    dataKey: props.dataKey,
    moveUpIcon: props.moveUpIcon,
    moveTopIcon: props.moveTopIcon,
    moveDownIcon: props.moveDownIcon,
    moveBottomIcon: props.moveBottomIcon,
    ptm: ptm,
    cx: cx,
    unstyled: props.unstyled,
    metaData: metaData
  }), /*#__PURE__*/React__namespace.createElement(PickListSubList, {
    hostName: "PickList",
    ref: sourceListElementRef,
    type: "source",
    list: sourceList,
    selection: sourceSelection,
    onSelectionChange: function onSelectionChange(e) {
      return _onSelectionChange(e, 'sourceSelection', props.onSourceSelectionChange);
    },
    itemTemplate: sourceItemTemplate,
    header: props.sourceHeader,
    style: props.sourceStyle,
    className: cx('listSourceWrapper'),
    listClassName: cx('listSource'),
    metaKeySelection: props.metaKeySelection,
    tabIndex: props.tabIndex,
    dataKey: props.dataKey,
    filterValue: sourceFilteredValue,
    onFilter: onFilter,
    showFilter: showSourceFilter,
    placeholder: props.sourceFilterPlaceholder,
    filterTemplate: props.sourceFilterTemplate,
    sourceFilterIcon: props.sourceFilterIcon,
    ptm: ptm,
    cx: cx
  }), /*#__PURE__*/React__namespace.createElement(PickListTransferControls, {
    hostName: "PickList",
    onTransfer: onTransfer,
    source: props.source,
    visibleSourceList: sourceList,
    target: props.target,
    breakpoint: props.breakpoint,
    visibleTargetList: targetList,
    sourceSelection: sourceSelection,
    targetSelection: targetSelection,
    dataKey: props.dataKey,
    moveToTargetIcon: props.moveToTargetIcon,
    moveAllToTargetIcon: props.moveAllToTargetIcon,
    moveToSourceIcon: props.moveToSourceIcon,
    moveAllToSourceIcon: props.moveAllToSourceIcon,
    ptm: ptm,
    cx: cx,
    unstyled: props.unstyled,
    metaData: metaData
  }), /*#__PURE__*/React__namespace.createElement(PickListSubList, {
    hostName: "PickList",
    ref: targetListElementRef,
    type: "target",
    list: targetList,
    selection: targetSelection,
    onSelectionChange: function onSelectionChange(e) {
      return _onSelectionChange(e, 'targetSelection', props.onTargetSelectionChange);
    },
    itemTemplate: targetItemTemplate,
    header: props.targetHeader,
    style: props.targetStyle,
    className: cx('listTargetWrapper'),
    listClassName: cx('listWrapper'),
    metaKeySelection: props.metaKeySelection,
    tabIndex: props.tabIndex,
    dataKey: props.dataKey,
    filterValue: targetFilteredValue,
    onFilter: onFilter,
    showFilter: showTargetFilter,
    placeholder: props.targetFilterPlaceholder,
    filterTemplate: props.targetFilterTemplate,
    targetFilterIcon: props.targetFilterIcon,
    ptm: ptm,
    cx: cx
  }), props.showTargetControls && /*#__PURE__*/React__namespace.createElement(PickListControls, {
    hostName: "PickList",
    list: props.target,
    selection: targetSelection,
    onReorder: onTargetReorder,
    className: cx('targetControls'),
    dataKey: props.dataKey,
    moveUpIcon: props.moveUpIcon,
    moveTopIcon: props.moveTopIcon,
    moveDownIcon: props.moveDownIcon,
    moveBottomIcon: props.moveBottomIcon,
    ptm: ptm,
    cx: cx,
    unstyled: props.unstyled,
    metaData: metaData
  }));
}));
PickList.displayName = 'PickList';

exports.G = PickList;


/***/ })

};
;