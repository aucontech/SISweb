exports.id = 1859;
exports.ids = [1859];
exports.modules = {

/***/ 23031:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 23667))

/***/ }),

/***/ 23667:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ AppLayout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/ripple/ripple.cjs.js
var ripple_cjs = __webpack_require__(26412);
// EXTERNAL MODULE: ./node_modules/primereact/utils/utils.cjs.js
var utils_cjs = __webpack_require__(7666);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./demo/components/apps/mail/context/mailcontext.tsx
var mailcontext = __webpack_require__(68496);
;// CONCATENATED MODULE: ./demo/components/apps/mail/AppMailSidebar.tsx







function AppMailSidebar() {
    const [items, setItems] = (0,react_.useState)([]);
    const router = (0,navigation.useRouter)();
    const pathname = (0,navigation.usePathname)();
    const { mails } = (0,react_.useContext)(mailcontext/* MailContext */.u);
    const navigate = (item)=>{
        if (item.to) {
            router.push(item.to);
        }
    };
    const getBadgeValues = (data)=>{
        let inbox = [], starred = [], spam = [], important = [], archived = [], trash = [], sent = [];
        for(let i = 0; i < data.length; i++){
            let mail = data[i];
            if (!mail.archived && !mail.trash && !mail.spam && !mail.hasOwnProperty("sent")) {
                inbox.push(mail);
            }
            if (mail.starred) {
                starred.push(mail);
            }
            if (mail.spam) {
                spam.push(mail);
            }
            if (mail.important) {
                important.push(mail);
            }
            if (mail.archived) {
                archived.push(mail);
            }
            if (mail.trash) {
                trash.push(mail);
            }
            if (mail.sent) {
                sent.push(mail);
            }
        }
        const badgeValues = {
            inbox: inbox.length,
            starred: starred.length,
            spam: spam.length,
            important: important.length,
            archived: archived.length,
            trash: trash.length,
            sent: sent.length
        };
        setItems([
            {
                label: "Inbox",
                icon: "pi pi-inbox",
                badge: badgeValues.inbox,
                to: "/apps/mail/inbox"
            },
            {
                label: "Starred",
                icon: "pi pi-star",
                badge: badgeValues.starred,
                to: "/apps/mail/starred"
            },
            {
                label: "Spam",
                icon: "pi pi-ban",
                badge: badgeValues.spam,
                to: "/apps/mail/spam"
            },
            {
                label: "Important",
                icon: "pi pi-bookmark",
                badge: badgeValues.important,
                to: "/apps/mail/important"
            },
            {
                label: "Sent",
                icon: "pi pi-send",
                badge: badgeValues.sent,
                to: "/apps/mail/sent"
            },
            {
                label: "Archived",
                icon: "pi pi-book",
                badge: badgeValues.archived,
                to: "/apps/mail/archived"
            },
            {
                label: "Trash",
                icon: "pi pi-trash",
                badge: badgeValues.trash,
                to: "/apps/mail/trash"
            }
        ]);
    };
    (0,react_.useEffect)(()=>{
        getBadgeValues(mails);
    }, [
        mails
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx((react_default()).Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                    label: "Compose New",
                    className: "mb-5 w-full",
                    outlined: true,
                    onClick: (e)=>router.push("/apps/mail/compose")
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "overflow-auto",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "flex flex-row md:flex-column gap-1 md:gap-2 list-none m-0 p-0 overflow-auto",
                        children: items.map((item, i)=>{
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: (0,utils_cjs.classNames)("p-ripple cursor-pointer select-none p-3 transition-duration-150 border-round flex align-items-center justify-content-center md:justify-content-start md:flex-1 flex-auto", {
                                    "bg-primary": pathname === item.to,
                                    "hover:surface-hover": pathname !== item.to
                                }),
                                onClick: ()=>navigate(item),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: (0,utils_cjs.classNames)("md:mr-3 text-600 transition-duration-150 text-lg", item.icon || "", {
                                            "text-primary-50": pathname === item.to
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: (0,utils_cjs.classNames)("text-900 font-medium hidden md:inline", {
                                            "text-primary-50": pathname === item.to
                                        }),
                                        children: item.label
                                    }),
                                    item.badge ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "ml-auto text-sm font-semibold bg-primary-50 text-primary-900 px-2 py-1 hidden md:inline",
                                        style: {
                                            borderRadius: "2rem"
                                        },
                                        children: item.badge
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "ml-auto text-sm font-semibold bg-primary-50 text-primary-900 px-2 py-1 hidden md:inline",
                                        style: {
                                            borderRadius: "2rem"
                                        },
                                        children: "0"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ripple_cjs.Ripple, {})
                                ]
                            }, i);
                        })
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const mail_AppMailSidebar = (AppMailSidebar);

;// CONCATENATED MODULE: ./demo/components/apps/mail/AppMailLayout.tsx



const AppMailLayout = ({ children })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(mailcontext/* MailProvider */.N, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "card",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-column md:flex-row gap-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-3 xl:w-2 xl:p-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(mail_AppMailSidebar, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "md:w-9 xl:w-10 xl:p-3",
                        children: children
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const mail_AppMailLayout = (AppMailLayout);

;// CONCATENATED MODULE: ./app/(main)/apps/(mail)/layout.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 

function AppLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(mail_AppMailLayout, {
        children: children
    });
}


/***/ }),

/***/ 68496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   N: () => (/* binding */ MailProvider),
/* harmony export */   u: () => (/* binding */ MailContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11459);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const MailContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext({});
const MailProvider = (props)=>{
    const [mails, setMails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const toastRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const getMails = ()=>{
        return fetch("/demo/data/mail.json", {
            headers: {
                "Cache-Control": "no-cache"
            }
        }).then((res)=>res.json()).then((d)=>d.data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getMails().then((data)=>setMails(data));
    }, []);
    const updateMails = (data)=>{
        setMails(data);
    };
    const clearMailActions = (mail)=>{
        Object.keys(mail).forEach((key)=>{
            if (mail[key] === true) {
                mail[key] = false;
            }
        });
    };
    const onStar = (id)=>{
        let _mails = mails.map((m)=>m.id === id ? {
                ...m,
                starred: !m.starred
            } : m);
        setMails(_mails);
    };
    const onArchive = (id)=>{
        let _mails = mails.map((m)=>m.id === id ? {
                ...m,
                archived: !m.archived
            } : m);
        setMails(_mails);
    };
    const onBookmark = (id)=>{
        let _mails = mails.map((m)=>m.id === id ? {
                ...m,
                important: !m.important
            } : m);
        setMails(_mails);
    };
    const onDelete = (id)=>{
        let _mails = mails.splice(mails.findIndex((m)=>m.id === id), 1);
        setMails(_mails);
    };
    const onDeleteMultiple = (mailArray)=>{
        const idArray = mailArray.map((m)=>Number(m.id));
        const updatedMails = mails.map((mail)=>{
            if (idArray.indexOf(mail.id) === -1) {
                return mail;
            } else {
                return {
                    ...mail,
                    trash: true
                };
            }
        });
        setMails(updatedMails);
    };
    const onArchiveMultiple = (mailArray)=>{
        const idArray = mailArray.map((m)=>m.id);
        const updatedMails = mails.map((mail)=>{
            if (idArray.indexOf(mail.id) !== -1) {
                return {
                    ...mail,
                    archived: true
                };
            } else {
                return mail;
            }
        });
        setMails(updatedMails);
    };
    const onSpamMultiple = (mailArray)=>{
        const idArray = mailArray.map((m)=>m.id);
        const updatedMails = mails.map((mail)=>{
            if (idArray.indexOf(mail.id) !== -1) {
                return {
                    ...mail,
                    spam: true,
                    important: false,
                    starred: false,
                    archived: false
                };
            } else {
                return mail;
            }
        });
        setMails(updatedMails);
    };
    const onTrash = (id)=>{
        let _mails = mails.map((m)=>m.id === id ? {
                ...m,
                trash: true,
                spam: false,
                important: false,
                starred: false,
                archived: false
            } : m);
        setMails(_mails);
    };
    const onSend = (mail)=>{
        let _mails = mails;
        if (!mail.title) {
            mail.title = "Untitled";
        }
        _mails.push(mail);
        setMails(_mails);
    };
    const value = {
        mails,
        toastRef,
        updateMails,
        clearMailActions,
        onStar,
        onArchive,
        onBookmark,
        onDelete,
        onDeleteMultiple,
        onArchiveMultiple,
        onSpamMultiple,
        onTrash,
        onSend
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_toast__WEBPACK_IMPORTED_MODULE_2__/* .Toast */ .F, {
                ref: toastRef
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MailContext.Provider, {
                value: value,
                children: props.children
            })
        ]
    });
};


/***/ }),

/***/ 77421:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\apps\(mail)\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;