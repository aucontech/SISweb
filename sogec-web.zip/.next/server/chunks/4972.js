exports.id = 4972;
exports.ids = [4972];
exports.modules = {

/***/ 92021:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 44016));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 78473));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 81905))

/***/ }),

/***/ 11520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   h6: () => (/* binding */ refreshTokenFun),
/* harmony export */   ts: () => (/* binding */ getCurrentUser),
/* harmony export */   x4: () => (/* binding */ login)
/* harmony export */ });
/* harmony import */ var _http_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(49213);

const login = (loginPayload)=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.post("/auth/login", {
        ...loginPayload
    });
};
const refreshTokenFun = (tokenPayload)=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.post("/auth/token", {
        ...tokenPayload
    });
};
const getCurrentUser = ()=>{
    return _http_api__WEBPACK_IMPORTED_MODULE_0__/* .httpApi */ .Y.get("/auth/user");
};


/***/ }),

/***/ 49213:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Y: () => (/* binding */ httpApi)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(53071);
/* harmony import */ var _service_localStorage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(40365);


const httpApi = axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.create({
    baseURL: `${"http://ewon-vpn.ddns.net:8200/api"}`,
    headers: {
        "Content-Type": "application/json"
    },
    timeout: 30000
});
console.log(httpApi);
httpApi.interceptors.request.use((config)=>{
    const token = (0,_service_localStorage__WEBPACK_IMPORTED_MODULE_1__/* .readToken */ .YG)();
    if (token) {
        config.headers["X-Authorization"] = `Bearer ${token}`;
    }
    return config;
}, (error)=>{
    return Promise.reject(error);
}); // httpApi.interceptors.response.use(
 //     (response) => {
 //         // If the response is successful, just return it
 //         return response;
 //     },
 //     async (error) => {
 //         const originalRequest = error.config;
 //         const router = useRouter();
 //         // Check if the error is due to a token expiration and we haven't already retried
 //         if (error.response.status === 401 && !originalRequest._retry) {
 //             originalRequest._retry = true; // Mark it so we don't try to refresh the token again
 //             const refreshToken: string | null = readRefreshToken();
 //             if (refreshToken) {
 //                 try {
 //                     const res = await refreshTokenFun({
 //                         refreshToken,
 //                     });
 //                     if (res) {
 //                         persistToken(res.token);
 //                         persistRefreshToken(res.refreshToken);
 //                         originalRequest.headers[
 //                             "X-Authorization"
 //                         ] = `Bearer ${res.token}`;
 //                     }
 //                     // Update the header of the original request
 //                     // Retry the request with the new token
 //                     return httpApi(originalRequest);
 //                 } catch (refreshError) {
 //                     console.log(refreshError);
 //                     //deleteToken();
 //                     return Promise.reject(refreshError); // If token refresh fails, reject the promise
 //                 }
 //             } else {
 //                 return Promise.reject(error);
 //             }
 //         }
 //         // If the error is not due to token expiration or another request, just return it
 //         return Promise.reject(error);
 //     }
 // );


/***/ }),

/***/ 44016:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var primereact_progressspinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(80994);
/* harmony import */ var _context_AuthProvider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78473);
/* __next_internal_client_entry_do_not_use__ default auto */ 

 // Đảm bảo rằng đây là cách đúng để import useRouter




const AppWrapper = ({ children })=>{
    const router = (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const pathname = (0,next_navigation__WEBPACK_IMPORTED_MODULE_2__.usePathname)();
    const authContext = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_AuthProvider__WEBPACK_IMPORTED_MODULE_3__.AuthContext);
    if (!authContext) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    const { isAuthenticated, setIsAuthenticated, isLoading } = authContext;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!isAuthenticated) {
            router.push("/login");
        } else {
            if (pathname === "/login") {
                router.push("/");
            } else {
                router.push(pathname);
            }
        }
    }, [
        isAuthenticated,
        pathname
    ]);
    const spinnerStyle = {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh"
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: spinnerStyle,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(primereact_progressspinner__WEBPACK_IMPORTED_MODULE_4__/* .ProgressSpinner */ .G, {
                style: {
                    width: "50px",
                    height: "50px"
                }
            })
        }) : children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppWrapper);


/***/ }),

/***/ 78473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthContext: () => (/* binding */ AuthContext),
/* harmony export */   AuthProvider: () => (/* binding */ AuthProvider),
/* harmony export */   useAuth: () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _service_localStorage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(40365);
/* harmony import */ var _api_auth_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(11520);
/* __next_internal_client_entry_do_not_use__ AuthContext,AuthProvider,useAuth auto */ 



// Tạo một Context với kiểu AuthContextType
const AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(null);
// Tạo AuthProvider component với TypeScript
const AuthProvider = ({ children })=>{
    const [isAuthenticated, setIsAuthenticated] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const authenticate = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        setIsLoading(()=>true);
        const token = (0,_service_localStorage__WEBPACK_IMPORTED_MODULE_3__/* .readToken */ .YG)();
        try {
            const resp = await (0,_api_auth_api__WEBPACK_IMPORTED_MODULE_2__/* .getCurrentUser */ .ts)();
            if (resp.status === 200) {
                setIsAuthenticated(()=>true);
            // setUser(resp.data.user);
            }
        } catch (error) {
            console.log(error);
            if (error.response.data.errorCode !== 11) {
                setIsAuthenticated(()=>false);
            }
        } finally{
            setIsLoading(()=>false);
        }
    }, []);
    const handleRefreshToken = async ()=>{
        try {
            const refreshToken = (0,_service_localStorage__WEBPACK_IMPORTED_MODULE_3__/* .readRefreshToken */ .so)();
            const newTokens = await (0,_api_auth_api__WEBPACK_IMPORTED_MODULE_2__/* .refreshTokenFun */ .h6)({
                refreshToken
            });
            (0,_service_localStorage__WEBPACK_IMPORTED_MODULE_3__/* .persistToken */ .s8)(newTokens?.data.token);
            (0,_service_localStorage__WEBPACK_IMPORTED_MODULE_3__/* .persistRefreshToken */ .uE)(newTokens?.data.refreshToken);
            setIsAuthenticated(()=>true);
        } catch (error) {
            setIsAuthenticated(()=>false);
        }
    };
    const _checkSession = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(async ()=>{
        try {
            const user = await (0,_api_auth_api__WEBPACK_IMPORTED_MODULE_2__/* .getCurrentUser */ .ts)();
            if (user) {} else {}
        } catch (error) {
            await handleRefreshToken();
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // _checkSession();
        const intervalId = setInterval(async ()=>{
            await _checkSession();
        }, 2000);
        return ()=>clearInterval(intervalId);
    }, [
        _checkSession
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        authenticate();
    }, [
        authenticate
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AuthContext.Provider, {
        value: {
            isAuthenticated,
            setIsAuthenticated,
            user,
            isLoading
        },
        children: children
    });
};
// Tạo một custom hook để sử dụng context
const useAuth = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(AuthContext);
    if (!context) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
};


/***/ }),

/***/ 81905:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: ./node_modules/primereact/api/api.cjs.js
var api_cjs = __webpack_require__(90284);
// EXTERNAL MODULE: ./node_modules/primereact/hooks/hooks.cjs.js
var hooks_cjs = __webpack_require__(85215);
// EXTERNAL MODULE: ./node_modules/primereact/utils/utils.cjs.js
var utils_cjs = __webpack_require__(7666);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./layout/context/layoutcontext.tsx
var layoutcontext = __webpack_require__(6538);
;// CONCATENATED MODULE: ./layout/AppBreadCrumb.tsx





const AppBreadcrumb = (props)=>{
    const pathname = (0,navigation.usePathname)();
    const [breadcrumb, setBreadcrumb] = (0,react_.useState)(null);
    const { breadcrumbs } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    (0,react_.useEffect)(()=>{
        const filteredBreadcrumbs = breadcrumbs?.find((crumb)=>{
            return crumb.to?.replace(/\/$/, "") === pathname.replace(/\/$/, "");
        });
        setBreadcrumb(filteredBreadcrumbs ?? null);
    }, [
        pathname,
        breadcrumbs
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: props.className,
        children: /*#__PURE__*/ jsx_runtime_.jsx("nav", {
            className: "layout-breadcrumb",
            children: /*#__PURE__*/ jsx_runtime_.jsx("ol", {
                children: utils_cjs.ObjectUtils.isNotEmpty(breadcrumb) && pathname !== "/" ? (breadcrumb?.labels?.map((label, index)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
                        children: [
                            index !== 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "layout-breadcrumb-chevron",
                                children: [
                                    " ",
                                    "/",
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: label
                            }, index)
                        ]
                    }, index);
                })) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        pathname === "/" && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: "Summary"
                        }, "home"),
                        pathname === "/dashboard-banking" && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            children: "Banking Dashboard"
                        }, "banking")
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const AppBreadCrumb = (AppBreadcrumb);

// EXTERNAL MODULE: ./layout/AppConfig.tsx
var AppConfig = __webpack_require__(92547);
// EXTERNAL MODULE: ./node_modules/primereact/badge/badge.cjs.js
var badge_cjs = __webpack_require__(41797);
// EXTERNAL MODULE: ./node_modules/primereact/sidebar/sidebar.cjs.js
var sidebar_cjs = __webpack_require__(63862);
;// CONCATENATED MODULE: ./layout/AppProfileSidebar.tsx





const AppProfileSidebar = ()=>{
    const { layoutState, setLayoutState } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const onProfileSidebarHide = ()=>{
        setLayoutState((prevState)=>({
                ...prevState,
                profileSidebarVisible: false
            }));
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(sidebar_cjs/* Sidebar */.Y, {
        visible: layoutState.profileSidebarVisible,
        onHide: onProfileSidebarHide,
        position: "right",
        className: "layout-profile-sidebar w-full sm:w-25rem",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-column mx-auto md:mx-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "mb-2 font-semibold",
                        children: "Welcome"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-color-secondary font-medium mb-5",
                        children: "Isabella Andolini"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-none m-0 p-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-user text-xl text-primary"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Profile"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "Lorem ipsum date visale"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-money-bill text-xl text-primary"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Billing"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "Amet mimin mıollit"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-cog text-xl text-primary"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Settings"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "Exercitation veniam"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-power-off text-xl text-primary"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Sign Out"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "Sed ut perspiciatis"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-column mt-5 mx-auto md:mx-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "mb-2 font-semibold",
                        children: "Notifications"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-color-secondary font-medium mb-5",
                        children: "You have 3 notifications"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-none m-0 p-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-comment text-xl text-primary"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Your post has new comments"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "5 min ago"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-trash text-xl text-primary"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Your post has been deleted"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "15min ago"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "pi pi-folder text-xl text-primary"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Post has been updated"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "3h ago"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-column mt-5 mx-auto md:mx-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "mb-2 font-semibold",
                        children: "Messages"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "text-color-secondary font-medium mb-5",
                        children: "You have new messages"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-none m-0 p-0",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/demo/images/avatar/circle/avatar-m-8.png",
                                                alt: "Avatar",
                                                className: "w-2rem h-2rem"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "James Robinson"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "10 min ago"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(badge_cjs/* Badge */.C, {
                                            value: "3",
                                            className: "ml-auto"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/demo/images/avatar/circle/avatar-f-8.png",
                                                alt: "Avatar",
                                                className: "w-2rem h-2rem"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Mary Watson"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "15min ago"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(badge_cjs/* Badge */.C, {
                                            value: "1",
                                            className: "ml-auto"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "cursor-pointer flex surface-border mb-3 p-3 align-items-center border-1 surface-border border-round hover:surface-hover transition-colors transition-duration-150",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/demo/images/avatar/circle/avatar-f-4.png",
                                                alt: "Avatar",
                                                className: "w-2rem h-2rem"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "ml-3",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "mb-2 font-semibold",
                                                    children: "Aisha Webb"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-color-secondary m-0",
                                                    children: "3h ago"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(badge_cjs/* Badge */.C, {
                                            value: "2",
                                            className: "ml-auto"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const layout_AppProfileSidebar = (AppProfileSidebar);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(31621);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/primereact/tooltip/tooltip.cjs.js
var tooltip_cjs = __webpack_require__(64935);
// EXTERNAL MODULE: ./node_modules/primereact/ripple/ripple.cjs.js
var ripple_cjs = __webpack_require__(26412);
;// CONCATENATED MODULE: ./layout/context/menucontext.tsx


const MenuContext = /*#__PURE__*/ (0,react_.createContext)({});
const MenuProvider = (props)=>{
    const [activeMenu, setActiveMenu] = (0,react_.useState)("");
    const value = {
        activeMenu,
        setActiveMenu
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(MenuContext.Provider, {
        value: value,
        children: props.children
    });
};

;// CONCATENATED MODULE: ./layout/hooks/useSubmenuOverlayPosition.ts





const useSubmenuOverlayPosition = ({ target, overlay, container, when })=>{
    const { isSlim, isSlimPlus, isHorizontal, setLayoutState } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const { activeMenu } = (0,react_.useContext)(MenuContext);
    const handleScroll = ()=>{
        setLayoutState((prevLayoutState)=>({
                ...prevLayoutState,
                overlayMenuActive: false,
                overlaySubmenuActive: false,
                staticMenuMobileActive: false,
                menuHoverActive: false,
                resetMenu: true
            }));
    };
    const [bindScrollListener, unbindScrollListener] = (0,hooks_cjs.useEventListener)({
        type: "scroll",
        target: container,
        listener: handleScroll
    });
    const calculatePosition = ()=>{
        if (overlay && target) {
            const { left, top } = target.getBoundingClientRect();
            const { width: vWidth, height: vHeight } = utils_cjs.DomHandler.getViewport();
            const [oWidth, oHeight] = [
                overlay.offsetWidth,
                overlay.offsetHeight
            ];
            const scrollbarWidth = utils_cjs.DomHandler.calculateScrollbarWidth(container);
            // reset
            overlay.style.top = overlay.style.left = "";
            if (isHorizontal()) {
                const width = left + oWidth + scrollbarWidth;
                overlay.style.left = vWidth < width ? `${left - (width - vWidth)}px` : `${left}px`;
            } else if (isSlim() || isSlimPlus()) {
                const height = top + oHeight;
                overlay.style.top = vHeight < height ? `${top - (height - vHeight)}px` : `${top}px`;
            }
        }
    };
    (0,react_.useEffect)(()=>{
        if (when) {
            bindScrollListener();
        }
        return ()=>{
            unbindScrollListener();
        };
    }, [
        when
    ]);
    (0,react_.useEffect)(()=>{
        if (when) {
            calculatePosition();
        }
    }, [
        when,
        activeMenu
    ]);
};

;// CONCATENATED MODULE: ./layout/AppMenuitem.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 








const AppMenuitem = (props)=>{
    const pathname = (0,navigation.usePathname)();
    const searchParams = (0,navigation.useSearchParams)();
    const { activeMenu, setActiveMenu } = (0,react_.useContext)(MenuContext);
    const { isSlim, isSlimPlus, isHorizontal, isDesktop, setLayoutState, layoutState, layoutConfig } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const submenuRef = (0,react_.useRef)(null);
    const menuitemRef = (0,react_.useRef)(null);
    const item = props.item;
    const key = props.parentKey ? props.parentKey + "-" + props.index : String(props.index);
    const isActiveRoute = item.to && pathname === item.to;
    const active = activeMenu === key || !!(activeMenu && activeMenu.startsWith(key + "-"));
    useSubmenuOverlayPosition({
        target: menuitemRef.current,
        overlay: submenuRef.current,
        container: menuitemRef.current && menuitemRef.current.closest(".layout-menu-container"),
        when: props.root && active && (isSlim() || isSlimPlus() || isHorizontal()) && isDesktop()
    });
    (0,react_.useEffect)(()=>{
        if (layoutState.resetMenu) {
            setActiveMenu("");
            setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    resetMenu: false
                }));
        }
    }, [
        layoutState.resetMenu
    ]);
    (0,react_.useEffect)(()=>{
        if (!(isSlim() || isSlimPlus() || isHorizontal()) && isActiveRoute) {
            setActiveMenu(key);
        }
        const url = pathname + searchParams.toString();
        const onRouteChange = ()=>{
            if (!(isSlim() || isHorizontal()) && item.to && item.to === url) {
                setActiveMenu(key);
            }
        };
        onRouteChange();
    }, [
        pathname,
        searchParams,
        layoutConfig
    ]);
    const itemClick = (event)=>{
        //avoid processing disabled items
        if (item.disabled) {
            event.preventDefault();
            return;
        }
        // navigate with hover
        if (props.root && (isSlim() || isHorizontal() || isSlimPlus())) {
            const isSubmenu = event.currentTarget.closest(".layout-root-menuitem.active-menuitem > ul") !== null;
            if (isSubmenu) setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    menuHoverActive: true
                }));
            else setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    menuHoverActive: !prevLayoutState.menuHoverActive
                }));
        }
        //execute command
        if (item?.command) {
            item?.command({
                originalEvent: event,
                item: item
            });
        }
        // toggle active state
        if (item?.items) {
            setActiveMenu(active ? props.parentKey : key);
            if (props.root && !active && (isSlim() || isHorizontal() || isSlimPlus())) {
                setLayoutState((prevLayoutState)=>({
                        ...prevLayoutState,
                        overlaySubmenuActive: true
                    }));
            }
        } else {
            if (!isDesktop()) {
                setLayoutState((prevLayoutState)=>({
                        ...prevLayoutState,
                        staticMenuMobileActive: !prevLayoutState.staticMenuMobileActive
                    }));
            }
            if (isSlim() || isSlimPlus() || isHorizontal()) {
                setLayoutState((prevLayoutState)=>({
                        ...prevLayoutState,
                        menuHoverActive: false
                    }));
            }
            setActiveMenu(key);
        }
    };
    const onMouseEnter = ()=>{
        // activate item on hover
        if (props.root && (isSlim() || isHorizontal() || isSlimPlus()) && isDesktop()) {
            if (!active && layoutState.menuHoverActive) {
                setActiveMenu(key);
            }
        }
    };
    const badge = item?.badge ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: (0,utils_cjs.classNames)("layout-menu-badge p-tag p-tag-rounded ml-2 uppercase", {
            [`${item?.badge}`]: true,
            "p-tag-success": item?.badge === "new",
            "p-tag-info": item?.badge === "updated"
        }),
        children: item?.badge
    }) : null;
    const subMenu = item?.items && item?.visible !== false ? /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        ref: submenuRef,
        children: item?.items.map((child, i)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx(AppMenuitem, {
                item: child,
                index: i,
                className: child.badgeClass,
                parentKey: key
            }, child.label);
        })
    }) : null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        ref: menuitemRef,
        className: (0,utils_cjs.classNames)({
            "layout-root-menuitem": props.root,
            "active-menuitem": active
        }),
        children: [
            props.root && item?.visible !== false && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "layout-menuitem-root-text",
                children: item?.label
            }),
            (!item?.to || item?.items) && item?.visible !== false ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    href: item?.url,
                    onClick: (e)=>itemClick(e),
                    className: (0,utils_cjs.classNames)(item?.class, "p-ripple tooltip-target"),
                    target: item?.target,
                    "data-pr-tooltip": item?.label,
                    "data-pr-disabled": !(isSlim() && props.root && !layoutState.menuHoverActive),
                    tabIndex: 0,
                    onMouseEnter: onMouseEnter,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: (0,utils_cjs.classNames)("layout-menuitem-icon", item?.icon)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "layout-menuitem-text",
                            children: item?.label
                        }),
                        item?.items && /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "pi pi-fw pi-angle-down layout-submenu-toggler"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ripple_cjs.Ripple, {})
                    ]
                })
            }) : null,
            item?.to && !item?.items && item?.visible !== false ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                    href: item?.to,
                    replace: item?.replaceUrl,
                    onClick: (e)=>itemClick(e),
                    className: (0,utils_cjs.classNames)(item?.class, "p-ripple ", {
                        "active-route": isActiveRoute
                    }),
                    tabIndex: 0,
                    onMouseEnter: onMouseEnter,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: (0,utils_cjs.classNames)("layout-menuitem-icon", item?.icon)
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "layout-menuitem-text",
                            children: item?.label
                        }),
                        badge,
                        item?.items && /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "pi pi-fw pi-angle-down layout-submenu-toggler"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ripple_cjs.Ripple, {})
                    ]
                })
            }) : null,
            subMenu
        ]
    });
};
/* harmony default export */ const layout_AppMenuitem = (AppMenuitem);

;// CONCATENATED MODULE: ./layout/AppSubMenu.tsx






const AppSubMenu = (props)=>{
    const { layoutState, setBreadcrumbs } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const tooltipRef = (0,react_.useRef)(null);
    (0,react_.useEffect)(()=>{
        if (tooltipRef.current) {
            tooltipRef.current.hide();
            tooltipRef.current.updateTargetEvents();
        }
    }, [
        layoutState.overlaySubmenuActive
    ]);
    (0,react_.useEffect)(()=>{
        generateBreadcrumbs(props.model);
    }, []);
    const generateBreadcrumbs = (model)=>{
        let breadcrumbs = [];
        const getBreadcrumb = (item, labels = [])=>{
            const { label, to, items } = item;
            label && labels.push(label);
            items && items.forEach((_item)=>{
                getBreadcrumb(_item, labels.slice());
            });
            to && breadcrumbs.push({
                labels,
                to
            });
        };
        model.forEach((item)=>{
            getBreadcrumb(item);
        });
        setBreadcrumbs(breadcrumbs);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MenuProvider, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                className: "layout-menu",
                children: props.model.map((item, i)=>{
                    return !item.seperator ? /*#__PURE__*/ jsx_runtime_.jsx(layout_AppMenuitem, {
                        item: item,
                        root: true,
                        index: i
                    }, item.label) : /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: "menu-separator"
                    });
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(tooltip_cjs.Tooltip, {
                ref: tooltipRef,
                target: "li:not(.active-menuitem)>.tooltip-target"
            })
        ]
    });
};
/* harmony default export */ const layout_AppSubMenu = (AppSubMenu);

;// CONCATENATED MODULE: ./layout/AppMenu.tsx


const AppMenu = ()=>{
    const model = [
        {
            label: "Dashboards",
            icon: "pi pi-home",
            items: [
                {
                    label: "Alarm History",
                    icon: "pi pi-fw pi-image",
                    to: "/alarmhistory"
                },
                // {
                //     label: "Realtime Monitoring",
                //     icon: "pi pi-fw pi-image",
                //     to: "/realtimemonitoring",
                // },
                {
                    label: "Notifications center",
                    icon: "pi pi-fw pi-image",
                    to: "/notifications"
                },
                {
                    label: "Devices",
                    icon: "pi pi-fw pi-image",
                    to: "/devices"
                },
                {
                    label: "Device Profiles",
                    icon: "pi pi-fw pi-image",
                    to: "/deviceprofiles"
                }
            ]
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(layout_AppSubMenu, {
        model: model
    });
};
/* harmony default export */ const layout_AppMenu = (AppMenu);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./layout/AppSidebar.tsx







const AppSidebar = ()=>{
    const { setLayoutState } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const anchor = ()=>{
        setLayoutState((prevLayoutState)=>({
                ...prevLayoutState,
                anchored: !prevLayoutState.anchored
            }));
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sidebar-header",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                        href: "/",
                        className: "app-logo",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/layout/imgGas/1sojitz.png",
                                width: 80,
                                height: 50,
                                alt: "Picture of the author"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/layout/imgGas/daigaslogo.png",
                                width: 80,
                                height: 40,
                                alt: "Picture of the author"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "layout-sidebar-anchor p-link z-2 mb-2",
                        type: "button",
                        onClick: anchor
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "layout-menu-container",
                children: /*#__PURE__*/ jsx_runtime_.jsx(MenuProvider, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(layout_AppMenu, {})
                })
            })
        ]
    });
};
/* harmony default export */ const layout_AppSidebar = (AppSidebar);

// EXTERNAL MODULE: ./node_modules/primereact/button/button.cjs.js
var button_cjs = __webpack_require__(18176);
// EXTERNAL MODULE: ./node_modules/primereact/overlaypanel/overlaypanel.cjs.js
var overlaypanel_cjs = __webpack_require__(98063);
// EXTERNAL MODULE: ./layout/AlarmBell/AlarmBell.module.css
var AlarmBell_module = __webpack_require__(22880);
var AlarmBell_module_default = /*#__PURE__*/__webpack_require__.n(AlarmBell_module);
;// CONCATENATED MODULE: ./layout/AlarmBell/Alarmbell.tsx








function Alarmbell() {
    let token = "";
    if (false) {}
    const url = `${"ws://ewon-vpn.ddns.net:8200/api/ws/plugins/notifications?token="}${token}`;
    const op = (0,react_.useRef)(null);
    const router = (0,navigation.useRouter)();
    const ws = (0,react_.useRef)(null);
    const [data, setData] = (0,react_.useState)([]);
    const [totalUnreadCount, setTotalUnreadCount] = (0,react_.useState)("");
    const [obj1Processed, setObj1Processed] = (0,react_.useState)(false);
    const [notifications, setNotifications] = (0,react_.useState)([]);
    (0,react_.useEffect)(()=>{
        ws.current = new WebSocket(url);
        const obj1 = {
            unreadCountSubCmd: {
                cmdId: 1
            }
        };
        ws.current.onopen = ()=>{
            console.log("WebSocket connection opened.");
            ws.current?.send(JSON.stringify(obj1));
        };
        ws.current.onclose = ()=>{
            console.log("WebSocket connection closed.");
        };
        return ()=>{
            console.log("Cleaning up WebSocket connection.");
            ws.current?.close();
        };
    }, [
        url
    ]);
    (0,react_.useEffect)(()=>{
        const obj3 = {
            unsubCmd: {
                cmdId: 1
            }
        };
        const obj2 = {
            unreadSubCmd: {
                limit: totalUnreadCount,
                cmdId: 1
            }
        };
        if (ws.current) {
            ws.current.onmessage = (evt)=>{
                const dataReceive = JSON.parse(evt.data);
                if (dataReceive.update !== null) {
                    setTotalUnreadCount(dataReceive.totalUnreadCount);
                    setData([
                        ...data,
                        dataReceive
                    ]);
                    setObj1Processed(true);
                } else if (dataReceive.cmdUpdateType === "NOTIFICATIONS" && dataReceive.notifications) {
                    setNotifications(dataReceive.notifications);
                }
            };
        }
        if (obj1Processed) {
            ws.current?.send(JSON.stringify(obj3));
            ws.current?.send(JSON.stringify(obj2));
        }
    }, [
        totalUnreadCount,
        obj1Processed
    ]);
    const dataAlarm = notifications.slice(0, 6).map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
            style: {
                padding: "0px 10px"
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: (AlarmBell_module_default()).subject,
                        children: item.subject
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: item.text
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                ]
            })
        }, index));
    const subjectCount = notifications.length;
    let totalSubjectDisplay = subjectCount;
    if (subjectCount > 99) {
        totalSubjectDisplay = "99+";
    }
    const totalCount = subjectCount > 0 ? {
        totalSubjects: totalSubjectDisplay
    } : null;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex",
                children: [
                    totalCount && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: (AlarmBell_module_default()).totalCount,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: (AlarmBell_module_default()).totalCount_p,
                            children: totalCount.totalSubjects
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "pi pi-bell",
                        style: {
                            fontSize: "1.5rem",
                            cursor: "pointer"
                        },
                        onClick: (e)=>op?.current?.toggle(e)
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(overlaypanel_cjs/* OverlayPanel */.T, {
                style: {
                    marginLeft: 10
                },
                ref: op,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (AlarmBell_module_default()).overlayPanel,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            style: {
                                padding: "10px 20px "
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    style: {
                                        fontSize: 20,
                                        fontWeight: 600
                                    },
                                    children: "Alarms"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("hr", {})
                            ]
                        }),
                        dataAlarm.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                overflowY: "auto",
                                maxHeight: 300
                            },
                            children: dataAlarm
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (AlarmBell_module_default()).alarmEmpty,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/demo/images/logoBell/bel.svg",
                                width: 200,
                                height: 200,
                                alt: "Picture of the author"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                padding: 20
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                onClick: ()=>router.push("/notifications"),
                                className: (AlarmBell_module_default()).buttonViewAll,
                                children: "View All"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                    ]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./layout/AppTopbar.tsx






const AppTopbar = /*#__PURE__*/ (0,react_.forwardRef)((props, ref)=>{
    const { onMenuToggle, showProfileSidebar, showConfigSidebar } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const menubuttonRef = (0,react_.useRef)(null);
    const onConfigButtonClick = ()=>{
        showConfigSidebar();
    };
    (0,react_.useImperativeHandle)(ref, ()=>({
            menubutton: menubuttonRef.current
        }));
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "layout-topbar",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "topbar-start",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        ref: menubuttonRef,
                        type: "button",
                        className: "topbar-menubutton p-link p-trigger",
                        onClick: onMenuToggle,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "pi pi-bars"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(AppBreadCrumb, {
                        className: "topbar-breadcrumb"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "topbar-end",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "topbar-menu",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "topbar-search",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Alarmbell, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "ml-3",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(button_cjs.Button, {
                                type: "button",
                                icon: "pi pi-cog",
                                text: true,
                                rounded: true,
                                severity: "secondary",
                                className: "flex-shrink-0",
                                onClick: onConfigButtonClick
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "topbar-profile",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                type: "button",
                                className: "p-link",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/layout/images/avatar/avatar.png",
                                    alt: "Profile"
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
});
AppTopbar.displayName = "AppTopbar";
/* harmony default export */ const layout_AppTopbar = (AppTopbar);

;// CONCATENATED MODULE: ./layout/layout.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 











const Layout = (props)=>{
    const { layoutConfig, layoutState, setLayoutState, isSlim, isSlimPlus, isHorizontal, isDesktop } = (0,react_.useContext)(layoutcontext/* LayoutContext */.V);
    const topbarRef = (0,react_.useRef)(null);
    const sidebarRef = (0,react_.useRef)(null);
    const pathname = (0,navigation.usePathname)();
    const searchParams = (0,navigation.useSearchParams)();
    const [bindMenuOutsideClickListener, unbindMenuOutsideClickListener] = (0,hooks_cjs.useEventListener)({
        type: "click",
        listener: (event)=>{
            const isOutsideClicked = !(sidebarRef.current?.isSameNode(event.target) || sidebarRef.current?.contains(event.target) || topbarRef.current?.menubutton?.isSameNode(event.target) || topbarRef.current?.menubutton?.contains(event.target));
            if (isOutsideClicked) {
                hideMenu();
            }
        }
    });
    const [bindDocumentResizeListener, unbindDocumentResizeListener] = (0,hooks_cjs.useResizeListener)({
        listener: ()=>{
            if (isDesktop() && !utils_cjs.DomHandler.isTouchDevice()) {
                hideMenu();
            }
        }
    });
    let timeout = null;
    const onMouseEnter = ()=>{
        if (!layoutState.anchored) {
            if (timeout) {
                clearTimeout(timeout);
                timeout = null;
            }
            setLayoutState((prevLayoutState)=>({
                    ...prevLayoutState,
                    sidebarActive: true
                }));
        }
    };
    const onMouseLeave = ()=>{
        if (!layoutState.anchored) {
            if (!timeout) {
                timeout = setTimeout(()=>setLayoutState((prevLayoutState)=>({
                            ...prevLayoutState,
                            sidebarActive: false
                        })), 300);
            }
        }
    };
    const hideMenu = (0,react_.useCallback)(()=>{
        setLayoutState((prevLayoutState)=>({
                ...prevLayoutState,
                overlayMenuActive: false,
                overlaySubmenuActive: false,
                staticMenuMobileActive: false,
                menuHoverActive: false,
                resetMenu: (isSlim() || isSlimPlus() || isHorizontal()) && isDesktop()
            }));
    }, [
        isSlim,
        isSlimPlus,
        isHorizontal,
        isDesktop,
        setLayoutState
    ]);
    const blockBodyScroll = ()=>{
        if (document.body.classList) {
            document.body.classList.add("blocked-scroll");
        } else {
            document.body.className += " blocked-scroll";
        }
    };
    const unblockBodyScroll = ()=>{
        if (document.body.classList) {
            document.body.classList.remove("blocked-scroll");
        } else {
            document.body.className = document.body.className.replace(new RegExp("(^|\\b)" + "blocked-scroll".split(" ").join("|") + "(\\b|$)", "gi"), " ");
        }
    };
    (0,hooks_cjs.useMountEffect)(()=>{
        api_cjs["default"].ripple = true;
    });
    (0,react_.useEffect)(()=>{
        if (layoutState.overlayMenuActive || layoutState.staticMenuMobileActive || layoutState.overlaySubmenuActive) {
            bindMenuOutsideClickListener();
        }
        if (layoutState.staticMenuMobileActive) {
            blockBodyScroll();
            (isSlim() || isSlimPlus() || isHorizontal()) && bindDocumentResizeListener();
        }
        return ()=>{
            unbindMenuOutsideClickListener();
            unbindDocumentResizeListener();
            unblockBodyScroll();
        };
    }, [
        layoutState.overlayMenuActive,
        layoutState.staticMenuMobileActive,
        layoutState.overlaySubmenuActive
    ]);
    (0,react_.useEffect)(()=>{
        const onRouteChange = ()=>{
            hideMenu();
        };
        onRouteChange();
    }, [
        pathname,
        searchParams
    ]);
    (0,hooks_cjs.useUnmountEffect)(()=>{
        unbindMenuOutsideClickListener();
    });
    const containerClass = (0,utils_cjs.classNames)({
        "layout-light": layoutConfig.colorScheme === "light",
        "layout-dim": layoutConfig.colorScheme === "dim",
        "layout-dark": layoutConfig.colorScheme === "dark",
        "layout-colorscheme-menu": layoutConfig.menuTheme === "colorScheme",
        "layout-primarycolor-menu": layoutConfig.menuTheme === "primaryColor",
        "layout-transparent-menu": layoutConfig.menuTheme === "transparent",
        "layout-overlay": layoutConfig.menuMode === "overlay",
        "layout-static": layoutConfig.menuMode === "static",
        "layout-slim": layoutConfig.menuMode === "slim",
        "layout-slim-plus": layoutConfig.menuMode === "slim-plus",
        "layout-horizontal": layoutConfig.menuMode === "horizontal",
        "layout-reveal": layoutConfig.menuMode === "reveal",
        "layout-drawer": layoutConfig.menuMode === "drawer",
        "layout-static-inactive": layoutState.staticMenuDesktopInactive && layoutConfig.menuMode === "static",
        "layout-overlay-active": layoutState.overlayMenuActive,
        "layout-mobile-active": layoutState.staticMenuMobileActive,
        "p-input-filled": layoutConfig.inputStyle === "filled",
        "p-ripple-disabled": !layoutConfig.ripple,
        "layout-sidebar-active": layoutState.sidebarActive,
        "layout-sidebar-anchored": layoutState.anchored
    });
    return /*#__PURE__*/ jsx_runtime_.jsx((react_default()).Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (0,utils_cjs.classNames)("layout-container", containerClass),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    ref: sidebarRef,
                    className: "layout-sidebar",
                    onMouseEnter: onMouseEnter,
                    onMouseLeave: onMouseLeave,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(layout_AppSidebar, {})
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "layout-content-wrapper",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(layout_AppTopbar, {
                            ref: topbarRef
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(AppBreadCrumb, {
                            className: "content-breadcrumb"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "layout-content",
                            children: props.children
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(layout_AppProfileSidebar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx(AppConfig["default"], {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "layout-mask"
                })
            ]
        })
    });
};
/* harmony default export */ const layout = (Layout);


/***/ }),

/***/ 40365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   YG: () => (/* binding */ readToken),
/* harmony export */   s8: () => (/* binding */ persistToken),
/* harmony export */   so: () => (/* binding */ readRefreshToken),
/* harmony export */   uE: () => (/* binding */ persistRefreshToken)
/* harmony export */ });
/* unused harmony exports deleteToken, deleteUser */
const persistToken = (token)=>{
    localStorage.setItem("accessToken", token);
};
const readToken = ()=>{
    return localStorage.getItem("accessToken") || null;
};
const persistRefreshToken = (token)=>{
    localStorage.setItem("refreshToken", token);
};
const readRefreshToken = ()=>{
    return localStorage.getItem("refreshToken") || null;
};
// export const persistUser = (user: UserModel): void => {
//     localStorage.setItem("user", JSON.stringify(user));
// };
// export const readUser = (): UserModel | null => {
//     const userStr = localStorage.getItem("user");
//     return userStr ? JSON.parse(userStr) : testUser;
// };
const deleteToken = ()=>{
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
};
const deleteUser = ()=>localStorage.removeItem("user");


/***/ }),

/***/ 22880:
/***/ ((module) => {

// Exports
module.exports = {
	"buttonViewAll": "AlarmBell_buttonViewAll__bUzwm",
	"overlayPanel": "AlarmBell_overlayPanel__DMfKN",
	"alarmEmpty": "AlarmBell_alarmEmpty__R6QjY",
	"totalCount": "AlarmBell_totalCount__jZLIA",
	"totalCount_p": "AlarmBell_totalCount_p__3EGSz",
	"subject": "AlarmBell_subject__H8UO9"
};


/***/ }),

/***/ 23308:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MainLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./layout/layout.tsx
var layout = __webpack_require__(71522);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./app/(main)/AppWrapper.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`D:\sogec\sogec-web\app\(main)\AppWrapper.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const AppWrapper = (__default__);
;// CONCATENATED MODULE: ./context/AuthProvider.tsx

const AuthProvider_proxy = (0,module_proxy.createProxy)(String.raw`D:\sogec\sogec-web\context\AuthProvider.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: AuthProvider_esModule, $$typeof: AuthProvider_$$typeof } = AuthProvider_proxy;
const AuthProvider_default_ = AuthProvider_proxy.default;

const e0 = AuthProvider_proxy["AuthContext"];

const e1 = AuthProvider_proxy["AuthProvider"];

const e2 = AuthProvider_proxy["useAuth"];

;// CONCATENATED MODULE: ./app/(main)/layout.tsx




const metadata = {
    title: "SOGEC",
    description: "Dashboard IOT Application",
    robots: {
        index: false,
        follow: false
    },
    viewport: {
        initialScale: 1,
        width: "device-width"
    },
    openGraph: {
        type: "website",
        title: "SOGEC",
        url: "https://www.primefaces.org/apollo-react",
        description: "The ultimate collection of design-agnostic, flexible and accessible React UI Components.",
        images: [
            "https://www.primefaces.org/static/social/apollo-react.png"
        ],
        ttl: 604800
    },
    icons: {
        icon: "/favicon.ico"
    }
};
function MainLayout({ children }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(e1, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(AppWrapper, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(layout/* default */.ZP, {
                children: children
            })
        })
    });
}


/***/ }),

/***/ 71522:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`D:\sogec\sogec-web\layout\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ })

};
;