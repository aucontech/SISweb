"use strict";
exports.id = 1130;
exports.ids = [1130];
exports.modules = {

/***/ 31130:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   c: () => (/* binding */ Utils),
/* harmony export */   e: () => (/* binding */ UIUtils)
/* harmony export */ });
/* harmony import */ var date_fns_format__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4230);

const showError = ({ error, summary, detail, toast, severity, sticky })=>{
    summary = summary || "Error";
    severity = severity || "error";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    if (error) {
        toast.show({
            severity,
            summary,
            detail: error,
            sticky,
            life
        });
        return;
    }
    return;
};
const showInfo = ({ summary, detail, toast, sticky })=>{
    let severity = "info";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    summary = summary || "Information";
    if (toast) {
        toast.show({
            severity,
            summary,
            detail,
            life,
            sticky
        });
    }
};
const showWarning = ({ summary, detail, toast, sticky })=>{
    let severity = "warn";
    let life = 7000;
    sticky = sticky === undefined ? false : sticky;
    summary = summary || "Warning";
    if (toast) {
        toast.show({
            severity,
            summary,
            detail,
            life,
            sticky
        });
    }
};
const getUnixTimeMilliseconds = ()=>new Date().getTime();
const getUnixTimeMillisecondsGMT7 = ()=>{
    const currentTime = new Date().getTime();
    const offset = 7 * 3600000; // 7 hours * 3600 seconds/hour * 1000 milliseconds/second
    const timeInGMT7 = currentTime + offset;
    return timeInGMT7;
};
const formatUnixTimeToString = (unixTime, fmt)=>{
    const date = new Date(unixTime);
    if (fmt) {
        return (0,date_fns_format__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)(date, fmt);
    }
    fmt = "dd-MM-yyyy HH:mm:ss";
    return (0,date_fns_format__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)(date, fmt);
};
const formatDurationWithWords = (duration)=>{
    let seconds = Math.floor(duration / 1000 % 60);
    let minutes = Math.floor(duration / (1000 * 60) % 60);
    let hours = Math.floor(duration / (1000 * 60 * 60));
    const hoursText = hours > 0 ? `${hours} hours` : "";
    const minutesText = minutes > 0 ? `${minutes} minutes` : "";
    const secondsText = seconds > 0 ? `${seconds} seconds` : "";
    return [
        hoursText,
        minutesText,
        secondsText
    ].filter(Boolean).join(", ");
};
const calculateDurationFromUnixWithWords = (startTime, endTime)=>{
    const start = new Date(startTime);
    const end = new Date(endTime);
    const duration = end - start; // Khoảng thời gian tính bằng miligiây
    return formatDurationWithWords(duration);
};
const UIUtils = {
    showError,
    showInfo,
    showWarning
};
const Utils = {
    formatUnixTimeToString,
    getUnixTimeMilliseconds,
    getUnixTimeMillisecondsGMT7,
    calculateDurationFromUnixWithWords
};



/***/ })

};
;